/**
 * Module 11: Demo Mode & 1-Click Test Scenarios Runner
 * Team: The Code Burner | Maharana Pratap Institute of Technology, Gorakhpur
 */

import { db } from './db.js';

export function runDemoScenario(scenarioId) {
  switch (scenarioId) {
    case 'demo-specialists':
      // Test 1: Search for dermatologist, eye hospital, orthopedic, nutritionist
      window.navigateTo?.('specialists');
      window.showToast?.('Demo 1 Active: Browsing Gorakhpur Specialists (Dr. Naveen Verma, Raj Eye, Dr. Aggarwal, Dr. Rinky Gupta)', 'info');
      break;

    case 'demo-prescription-schedule':
      // Test 2 & 3: Create prescription & add medicine reminders, mark taken
      window.navigateTo?.('prescriptions');
      db.updateReminderStatus('rem_02', 'Taken');
      window.showToast?.('Demo 2 Active: 8 AM/2 PM/8 PM Medicine Schedule loaded. 2:00 PM dose marked as Taken (Adherence increased)!', 'success');
      break;

    case 'demo-emergency-blood':
      // Test 4 & 5: Submit an O+ blood request for 2 units in Gorakhpur & search matching blood-banks/donors
      window.navigateTo?.('bloodFinder');
      const req = db.createBloodRequest({
        patientName: 'Ramesh Chandra (Ref #9821)',
        requiredBloodGroup: 'O+',
        unitsRequired: 2,
        currentLocation: 'Gorakhpur',
        hospitalName: 'BRD Medical College Emergency Wing',
        urgency: 'Emergency',
        contactPhone: '+91 98765 44332',
        additionalNotes: 'Urgent surgery scheduled at trauma ICU. 2 units PRBC needed.'
      });
      window.showToast?.('Demo 3 Active: Emergency O+ (2 Units) requested in Gorakhpur! Compatible blood banks & donors ranked.', 'emergency');
      break;

    case 'demo-register-donor':
      // Test 6 & 7: Register donor and submit donation request, update request status
      window.navigateTo?.('donorNetwork');
      const don = db.addDonor({
        name: 'Siddharth Rao (Demo Volunteer)',
        bloodGroup: 'O+',
        locality: 'Mohaddipur, Gorakhpur',
        preferredContact: 'In-App Request',
        availabilityStatus: 'Available',
        lastDonationDate: '2026-06-01'
      });
      db.respondToDonationRequest('don_req_01', 'Accepted');
      window.showToast?.(`Demo 4 Active: Registered donor ${don.displayName} & accepted incoming donation request!`, 'success');
      break;

    case 'demo-bloodbank-staff':
      // Test Staff mode: updates inventory
      db.setCurrentRole('Blood Bank Staff');
      window.updateRoleSelectorUI?.('Blood Bank Staff');
      db.updateBloodBankInventory('bb_brd_01', 'O+', 26);
      window.navigateTo?.('bloodBanks');
      window.showToast?.('Demo 5 Active: Switched to Blood Bank Staff role! Updated BRD Medical College O+ inventory to 26 units.', 'success');
      break;

    case 'demo-map-view':
      // Test 8: View blood resources on the map
      window.navigateTo?.('map');
      window.showToast?.('Demo 6 Active: Interactive Leaflet Map loaded with Gorakhpur centers & radius filter!', 'info');
      break;

    case 'demo-health-passport':
      // Test 9: Access prescriptions and reports from Medical Health Passport
      window.navigateTo?.('passport');
      window.showToast?.('Demo 7 Active: Medical Health Passport opened with documents, timeline, and paramedic QR!', 'info');
      break;

    case 'reset-database':
      if (confirm('Reset database back to initial Gorakhpur hackathon seed records?')) {
        db.resetToDefaults();
        window.location.reload();
      }
      break;

    default:
      console.warn('Unknown demo scenario', scenarioId);
  }
}

export function showDemoGuideModal() {
  const content = `
    <div class="space-y-4 text-xs">
      <div class="p-3 bg-teal-50 border border-teal-200 rounded-xl text-teal-950">
        <strong>Team The Code Burner • Hackathon Evaluator Guide</strong>
        <p class="mt-1 text-[11px] text-teal-800">
          This system contains complete functional business logic, database persistence in LocalStorage, clinical compatibility calculations, Leaflet map overlays, and medical passport storage.
        </p>
      </div>

      <div class="space-y-2">
        <div class="font-bold text-slate-800 text-sm">Quick 1-Click Evaluator Scenarios:</div>

        <div class="p-3 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-between cursor-pointer transition-colors" onclick="window.runDemoScenario('demo-specialists'); window.closeModal();">
          <div>
            <div class="font-bold text-slate-900">1. Doctors & Specialists Directory</div>
            <div class="text-[11px] text-slate-500">Dr. Naveen Verma, Raj Eye Hospital, Dr. Aggarwal, Dr. Rinky Gupta</div>
          </div>
          <span class="px-2.5 py-1 bg-teal-600 text-white rounded text-[11px] font-bold">Run Test</span>
        </div>

        <div class="p-3 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-between cursor-pointer transition-colors" onclick="window.runDemoScenario('demo-emergency-blood'); window.closeModal();">
          <div>
            <div class="font-bold text-slate-900">2. Emergency O+ Blood Request (Gorakhpur)</div>
            <div class="text-[11px] text-slate-500">Broadcast 2 units at BRD Medical College & calculate ABO compatibility</div>
          </div>
          <span class="px-2.5 py-1 bg-red-600 text-white rounded text-[11px] font-bold">Run Test</span>
        </div>

        <div class="p-3 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-between cursor-pointer transition-colors" onclick="window.runDemoScenario('demo-prescription-schedule'); window.closeModal();">
          <div>
            <div class="font-bold text-slate-900">3. Prescription Organizer & Medicine Reminders</div>
            <div class="text-[11px] text-slate-500">8 AM / 2 PM / 8 PM schedule, OCR draft preview & adherence ring</div>
          </div>
          <span class="px-2.5 py-1 bg-teal-600 text-white rounded text-[11px] font-bold">Run Test</span>
        </div>

        <div class="p-3 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-between cursor-pointer transition-colors" onclick="window.runDemoScenario('demo-register-donor'); window.closeModal();">
          <div>
            <div class="font-bold text-slate-900">4. Donor Network & Consent Workflow</div>
            <div class="text-[11px] text-slate-500">Register donor, privacy shielding, and accept incoming request</div>
          </div>
          <span class="px-2.5 py-1 bg-orange-600 text-white rounded text-[11px] font-bold">Run Test</span>
        </div>

        <div class="p-3 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-between cursor-pointer transition-colors" onclick="window.runDemoScenario('demo-bloodbank-staff'); window.closeModal();">
          <div>
            <div class="font-bold text-slate-900">5. Blood Bank Staff Mode & Inventory Updates</div>
            <div class="text-[11px] text-slate-500">Authorized staff mode modifying PRBC reserves for BRD Medical College</div>
          </div>
          <span class="px-2.5 py-1 bg-teal-700 text-white rounded text-[11px] font-bold">Run Test</span>
        </div>

        <div class="p-3 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-between cursor-pointer transition-colors" onclick="window.runDemoScenario('demo-map-view'); window.closeModal();">
          <div>
            <div class="font-bold text-slate-900">6. Interactive Leaflet Map & Radius Radar</div>
            <div class="text-[11px] text-slate-500">Map markers for Gorakhpur blood banks, hospitals, and consented donors</div>
          </div>
          <span class="px-2.5 py-1 bg-blue-600 text-white rounded text-[11px] font-bold">Run Test</span>
        </div>

        <div class="p-3 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-between cursor-pointer transition-colors" onclick="window.runDemoScenario('demo-health-passport'); window.closeModal();">
          <div>
            <div class="font-bold text-slate-900">7. Medical Health Passport & Paramedic QR</div>
            <div class="text-[11px] text-slate-500">Unified health timeline, document vault, and emergency paramedic QR</div>
          </div>
          <span class="px-2.5 py-1 bg-slate-800 text-white rounded text-[11px] font-bold">Run Test</span>
        </div>
      </div>

      <div class="pt-3 border-t border-slate-100 flex items-center justify-between">
        <button onclick="window.runDemoScenario('reset-database')" class="text-rose-600 font-semibold hover:underline text-[11px]">
          Reset Database to Initial Defaults
        </button>
        <button onclick="window.closeModal()" class="px-3 py-1.5 bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold">
          Close
        </button>
      </div>
    </div>
  `;

  window.openModal?.('Mediscan AI Pro • Hackathon Testing Console', content, []);
}
