/**
 * Mediscan AI Pro – Master Application Orchestrator
 * Team: The Code Burner | Maharana Pratap Institute of Technology, Gorakhpur
 */

import { db } from './db.js';
import { renderDashboardModule } from './modules/dashboard.js';
import { renderSpecialistsModule } from './modules/specialists.js';
import { renderPrescriptionsModule } from './modules/prescriptions.js';
import { renderBloodFinderModule } from './modules/bloodFinder.js';
import { renderDonorNetworkModule } from './modules/donorNetwork.js';
import { renderBloodBanksModule } from './modules/bloodBanks.js';
import { renderMapViewModule } from './modules/mapView.js';
import { renderPassportModule } from './modules/passport.js';
import { runDemoScenario, showDemoGuideModal } from './demoPresets.js';

class MediscanApp {
  constructor() {
    this.currentRoute = 'dashboard';
    this.initGlobals();
    this.initUI();
    this.navigateTo(this.currentRoute);
  }

  initGlobals() {
    window.navigateTo = (route) => this.navigateTo(route);
    window.showToast = (msg, type) => this.showToast(msg, type);
    window.openModal = (title, body, actions) => this.openModal(title, body, actions);
    window.closeModal = () => this.closeModal();
    window.runDemoScenario = (scenario) => runDemoScenario(scenario);
    window.openDemoModal = () => showDemoGuideModal();
    window.updateRoleSelectorUI = (role) => this.updateRoleSelectorUI(role);
  }

  initUI() {
    // Role switcher listener
    const roleSelector = document.getElementById('user-role-select');
    if (roleSelector) {
      roleSelector.value = db.getCurrentUser().role;
      roleSelector.addEventListener('change', (e) => {
        const newRole = e.target.value;
        db.setCurrentRole(newRole);
        this.showToast(`Switched active persona to: ${newRole}`, 'info');
        this.navigateTo(this.currentRoute); // re-render current view with new role
      });
    }

    // Top Demo Bar Triggers
    const demoBtn = document.getElementById('top-demo-guide-btn');
    if (demoBtn) {
      demoBtn.addEventListener('click', () => showDemoGuideModal());
    }

    // Quick SOS Button
    const sosBtn = document.getElementById('top-emergency-sos-btn');
    if (sosBtn) {
      sosBtn.addEventListener('click', () => {
        this.navigateTo('bloodFinder');
        this.showToast('🚨 Emergency Blood Dispatch Activated!', 'emergency');
      });
    }

    // Navigation Tabs in Sidebar / Header
    document.querySelectorAll('[data-nav-target]').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const target = link.dataset.navTarget;
        this.navigateTo(target);
      });
    });

    // Mobile hamburger menu toggle
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu-drawer');
    if (mobileMenuBtn && mobileMenu) {
      mobileMenuBtn.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
      });
    }

    // Notifications Dropdown
    const notifBtn = document.getElementById('notif-bell-btn');
    const notifDropdown = document.getElementById('notif-dropdown-panel');
    if (notifBtn && notifDropdown) {
      notifBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        notifDropdown.classList.toggle('hidden');
        this.renderNotificationsList();
      });

      document.addEventListener('click', () => {
        if (!notifDropdown.classList.contains('hidden')) {
          notifDropdown.classList.add('hidden');
        }
      });
    }

    // Modal Close Backdrop Click
    const modal = document.getElementById('global-modal');
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) this.closeModal();
      });
    }
  }

  updateRoleSelectorUI(role) {
    const roleSelector = document.getElementById('user-role-select');
    if (roleSelector) roleSelector.value = role;
  }

  navigateTo(route) {
    this.currentRoute = route;
    const contentArea = document.getElementById('main-content-area');
    if (!contentArea) return;

    // Update active state on navigation tabs
    document.querySelectorAll('[data-nav-target]').forEach(link => {
      if (link.dataset.navTarget === route) {
        link.classList.add('nav-tab-active');
        link.classList.remove('text-slate-300', 'hover:bg-slate-800');
      } else {
        link.classList.remove('nav-tab-active');
        link.classList.add('text-slate-300', 'hover:bg-slate-800');
      }
    });

    // Hide mobile menu if open
    const mobileMenu = document.getElementById('mobile-menu-drawer');
    if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
      mobileMenu.classList.add('hidden');
    }

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Render corresponding module
    switch (route) {
      case 'dashboard':
        renderDashboardModule(contentArea);
        break;
      case 'specialists':
        renderSpecialistsModule(contentArea);
        break;
      case 'prescriptions':
        renderPrescriptionsModule(contentArea);
        break;
      case 'bloodFinder':
        renderBloodFinderModule(contentArea);
        break;
      case 'donorNetwork':
        renderDonorNetworkModule(contentArea);
        break;
      case 'bloodBanks':
        renderBloodBanksModule(contentArea);
        break;
      case 'map':
        renderMapViewModule(contentArea);
        break;
      case 'passport':
        renderPassportModule(contentArea);
        break;
      default:
        renderDashboardModule(contentArea);
    }
  }

  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `p-3.5 rounded-xl shadow-lg border text-xs font-semibold flex items-center gap-2.5 transition-all transform duration-300 translate-y-2 opacity-0 ${
      type === 'emergency' ? 'bg-red-600 text-white border-red-700 shadow-emergency' :
      type === 'success' ? 'bg-emerald-600 text-white border-emerald-700' :
      type === 'warning' ? 'bg-amber-500 text-white border-amber-600' :
      'bg-slate-900 text-white border-slate-800'
    }`;

    let icon = 'ℹ️';
    if (type === 'emergency') icon = '🚨';
    if (type === 'success') icon = '✅';
    if (type === 'warning') icon = '⚠️';

    toast.innerHTML = `<span>${icon}</span><span class="flex-1">${message}</span>`;
    container.appendChild(toast);

    // Animate in
    setTimeout(() => {
      toast.classList.remove('translate-y-2', 'opacity-0');
    }, 10);

    // Auto remove
    setTimeout(() => {
      toast.classList.add('opacity-0', 'translate-y-2');
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  openModal(title, bodyHtml, actions = []) {
    const modal = document.getElementById('global-modal');
    const modalTitle = document.getElementById('global-modal-title');
    const modalBody = document.getElementById('global-modal-body');
    const modalActions = document.getElementById('global-modal-actions');

    if (!modal || !modalTitle || !modalBody || !modalActions) return;

    modalTitle.textContent = title;
    modalBody.innerHTML = bodyHtml;
    modalActions.innerHTML = '';

    actions.forEach(act => {
      const btn = document.createElement('button');
      btn.className = `px-4 py-2 rounded-xl text-xs font-bold transition-colors ${act.className || 'bg-slate-200 text-slate-700'}`;
      btn.textContent = act.label;
      btn.addEventListener('click', (e) => {
        if (act.action === 'close') {
          this.closeModal();
        } else if (typeof act.action === 'function') {
          act.action(e);
        }
      });
      modalActions.appendChild(btn);
    });

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }

  closeModal() {
    const modal = document.getElementById('global-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  }

  renderNotificationsList() {
    const notifPanel = document.getElementById('notif-dropdown-content');
    if (!notifPanel) return;

    const notifs = db.getNotifications();
    if (!notifs.length) {
      notifPanel.innerHTML = `<div class="p-4 text-center text-xs text-slate-400">No new notifications</div>`;
      return;
    }

    notifPanel.innerHTML = notifs.slice(0, 6).map(n => `
      <div class="p-3 border-b border-slate-100 hover:bg-slate-50 transition-colors text-xs">
        <div class="flex items-center justify-between gap-1 mb-0.5">
          <span class="font-bold text-slate-800">${n.title}</span>
          <span class="text-[10px] text-slate-400">${new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
        <p class="text-slate-600 text-[11px] leading-relaxed">${n.message}</p>
      </div>
    `).join('');
  }
}

// Initialize Application when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  window.mediscanApp = new MediscanApp();
});
