/**
 * Mediscan AI Pro – Persistent Database & Business Logic Engine
 * Team: The Code Burner | Maharana Pratap Institute of Technology, Gorakhpur
 * 
 * Implements 14 entities:
 * 1. User
 * 2. PatientProfile
 * 3. MedicalDocument
 * 4. Prescription
 * 5. Medicine
 * 6. MedicineReminder
 * 7. Doctor
 * 8. Hospital
 * 9. BloodBank
 * 10. BloodInventory
 * 11. DonorProfile
 * 12. BloodRequest
 * 13. DonationRequest
 * 14. AppointmentRequest
 * 15. Notification
 */

const DB_KEY = 'mediscan_ai_pro_db_v1';

// Blood Compatibility Engine Rules
export const BLOOD_COMPATIBILITY = {
  'O-':  { canReceiveFrom: ['O-'], canDonateTo: ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'] },
  'O+':  { canReceiveFrom: ['O-', 'O+'], canDonateTo: ['O+', 'A+', 'B+', 'AB+'] },
  'A-':  { canReceiveFrom: ['O-', 'A-'], canDonateTo: ['A-', 'A+', 'AB-', 'AB+'] },
  'A+':  { canReceiveFrom: ['O-', 'O+', 'A-', 'A+'], canDonateTo: ['A+', 'AB+'] },
  'B-':  { canReceiveFrom: ['O-', 'B-'], canDonateTo: ['B-', 'B+', 'AB-', 'AB+'] },
  'B+':  { canReceiveFrom: ['O-', 'O+', 'B-', 'B+'], canDonateTo: ['B+', 'AB+'] },
  'AB-': { canReceiveFrom: ['O-', 'A-', 'B-', 'AB-'], canDonateTo: ['AB-', 'AB+'] },
  'AB+': { canReceiveFrom: ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'], canDonateTo: ['AB+'] }
};

export function isBloodCompatible(donorGroup, recipientGroup) {
  if (!donorGroup || !recipientGroup) return false;
  const rules = BLOOD_COMPATIBILITY[recipientGroup];
  return rules ? rules.canReceiveFrom.includes(donorGroup) : false;
}

// Distance helper (Haversine formula in KM)
export function calculateDistance(lat1, lon1, lat2, lon2) {
  if (!lat1 || !lon1 || !lat2 || !lon2) return 3.5; // fallback
  const R = 6371; // km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return parseFloat((R * c).toFixed(1));
}

// Default Seed Data
function getInitialSeedData() {
  const now = new Date().toISOString();

  return {
    currentUser: {
      id: 'usr_patient_01',
      name: 'Rajesh Sharma',
      email: 'rajesh.sharma@example.com',
      role: 'Patient / Requester', // 'Patient / Requester' | 'Donor' | 'Blood Bank Staff' | 'Admin'
      activeDonorId: 'don_gor_001',
      activeBloodBankId: 'bb_brd_01'
    },
    patientProfile: {
      id: 'pat_01',
      userId: 'usr_patient_01',
      fullName: 'Rajesh Sharma',
      age: 34,
      gender: 'Male',
      bloodGroup: 'O+',
      phone: '+91 98765 12345',
      address: 'Near Golghar Chowk, Gorakhpur, UP',
      coordinates: { lat: 26.7588, lng: 83.3697 },
      allergies: ['Penicillin', 'Sulfa Drugs'],
      chronicConditions: ['Mild Hypertension'],
      emergencyContacts: [
        { name: 'Suman Sharma', relation: 'Spouse', phone: '+91 98765 99991' },
        { name: 'Dr. V.K. Mishra', relation: 'Family Physician', phone: '+91 94150 11223' }
      ],
      abhaId: '91-4521-8890-1234'
    },
    doctors: [
      {
        id: 'doc_01',
        name: 'Dr. Naveen Verma',
        type: 'Doctor',
        specialty: 'Dermatology / Skin',
        category: 'Dermatologist',
        location: 'Gorakhpur',
        address: 'Medical Enclave, Gorakhpur',
        coordinates: { lat: 26.7621, lng: 83.3762 },
        experience: '12 years',
        badge: 'Demo listing — verification required',
        isVerified: false,
        bio: 'Consultant Dermatologist specializing in skin allergies, dermatosurgery, and cosmetic dermatology.',
        availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        contactPlaceholder: 'Contact available upon demo appointment request'
      },
      {
        id: 'doc_02',
        name: 'Raj Eye Hospital',
        type: 'Hospital / Clinic',
        specialty: 'Eye Care',
        category: 'Ophthalmologist',
        location: 'Gorakhpur',
        address: 'Civil Lines Road, Gorakhpur',
        coordinates: { lat: 26.7544, lng: 83.3739 },
        experience: '20+ years facility',
        badge: 'Demo listing — verification required',
        isVerified: false,
        bio: 'Comprehensive eye care facility providing cataract, laser surgery, retina and glaucoma evaluation.',
        availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        contactPlaceholder: 'Hospital reception available during OPD hours'
      },
      {
        id: 'doc_03',
        name: 'Dr. Aggarwal',
        type: 'Doctor',
        specialty: 'Orthopedics / Bone Care',
        category: 'Orthopedic',
        location: 'Buxipur, Gorakhpur',
        address: 'Buxipur Main Road, Gorakhpur',
        coordinates: { lat: 26.7512, lng: 83.3645 },
        experience: '16 years',
        badge: 'Demo listing — verification required',
        isVerified: false,
        bio: 'Senior Orthopedic Surgeon treating bone fractures, joint pain, arthritis and sports injuries.',
        availableDays: ['Mon', 'Wed', 'Fri', 'Sat'],
        contactPlaceholder: 'Demo appointment booking only'
      },
      {
        id: 'doc_04',
        name: 'Dr. Rinky Gupta',
        type: 'Doctor',
        specialty: 'Nutrition and Diet Consultation',
        category: 'Nutritionist',
        location: 'Sadar, Gorakhpur',
        address: 'Sadar Executive Suites Area, Gorakhpur',
        coordinates: { lat: 26.7489, lng: 83.3821 },
        experience: '9 years',
        badge: 'Demo listing — verification required',
        isVerified: false,
        bio: 'Clinical Nutritionist offering therapeutic medical diets, diabetic nutritional planning and wellness guidance.',
        availableDays: ['Tue', 'Thu', 'Sat'],
        contactPlaceholder: 'Clinic slot booking via portal'
      },
      {
        id: 'doc_05',
        name: 'Dr. Anand Srivastava',
        type: 'Doctor',
        specialty: 'Cardiology / Heart Care',
        category: 'Cardiologist',
        location: 'Golghar, Gorakhpur',
        address: 'Park Road, Golghar, Gorakhpur',
        coordinates: { lat: 26.7601, lng: 83.3712 },
        experience: '18 years',
        badge: 'Demo listing — verification required',
        isVerified: false,
        bio: 'Consultant Interventional Cardiologist specializing in preventive heart health and ECG evaluation.',
        availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        contactPlaceholder: 'Heart center helpline available'
      },
      {
        id: 'doc_06',
        name: 'Dr. Priya Pandey',
        type: 'Doctor',
        specialty: 'General Medicine & Family Health',
        category: 'General Physician',
        location: 'Medical College Road, Gorakhpur',
        address: 'Near Asuran Chowk, Gorakhpur',
        coordinates: { lat: 26.7725, lng: 83.3842 },
        experience: '11 years',
        badge: 'Demo listing — verification required',
        isVerified: false,
        bio: 'Primary care physician for seasonal fever, viral infections, lifestyle disorders, and health checkups.',
        availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        contactPlaceholder: 'Family health OPD'
      },
      {
        id: 'doc_07',
        name: 'Dr. K.K. Rai',
        type: 'Doctor',
        specialty: 'Pediatrics & Child Care',
        category: 'Pediatrician',
        location: 'Mohaddipur, Gorakhpur',
        address: 'Charphatak Road, Mohaddipur, Gorakhpur',
        coordinates: { lat: 26.7465, lng: 83.3951 },
        experience: '15 years',
        badge: 'Demo listing — verification required',
        isVerified: false,
        bio: 'Child health specialist focusing on infant nutrition, immunization, and pediatric infections.',
        availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        contactPlaceholder: 'Children clinic inquiry'
      }
    ],
    bloodBanks: [
      {
        id: 'bb_brd_01',
        name: 'BRD Medical College Blood Center',
        facilityType: 'Government Medical College Hospital',
        location: 'Medical College Campus, Gorakhpur',
        address: 'BRD Medical College, Asuran, Gorakhpur, UP 273013',
        coordinates: { lat: 26.7915, lng: 83.3978 },
        contactPhone: '+91 551 2310100 (Ext 24)',
        emergencyHelpline: '108 / 102',
        badge: 'Demo listing — verification required',
        lastUpdated: now,
        distanceKm: 4.8,
        inventory: {
          'A+': 14,
          'A-': 4,
          'B+': 18,
          'B-': 5,
          'AB+': 8,
          'AB-': 2,
          'O+': 22,
          'O-': 6
        }
      },
      {
        id: 'bb_dist_02',
        name: 'District Hospital Blood Bank',
        facilityType: 'District Govt Hospital',
        location: 'Golghar, Gorakhpur',
        address: 'Near Town Hall, Golghar, Gorakhpur, UP 273001',
        coordinates: { lat: 26.7579, lng: 83.3705 },
        contactPhone: '+91 551 2334455',
        emergencyHelpline: '108',
        badge: 'Demo listing — verification required',
        lastUpdated: now,
        distanceKm: 1.2,
        inventory: {
          'A+': 9,
          'A-': 2,
          'B+': 12,
          'B-': 3,
          'AB+': 6,
          'AB-': 1,
          'O+': 15,
          'O-': 4
        }
      },
      {
        id: 'bb_redcross_03',
        name: 'Indian Red Cross Society Blood Bank',
        facilityType: 'Charitable Regional Center',
        location: 'Civil Lines, Gorakhpur',
        address: 'Near Park Road, Civil Lines, Gorakhpur, UP',
        coordinates: { lat: 26.7538, lng: 83.3764 },
        contactPhone: '+91 551 2200112',
        emergencyHelpline: 'Emergency Desk Available',
        badge: 'Demo listing — verification required',
        lastUpdated: now,
        distanceKm: 2.1,
        inventory: {
          'A+': 7,
          'A-': 3,
          'B+': 11,
          'B-': 2,
          'AB+': 5,
          'AB-': 2,
          'O+': 10,
          'O-': 3
        }
      },
      {
        id: 'bb_aiims_04',
        name: 'AIIMS Gorakhpur Blood Transfusion Center',
        facilityType: 'Apex Institute Hospital',
        location: 'Kunraghat, Gorakhpur',
        address: 'AIIMS Gorakhpur Campus, Kunraghat, UP 273008',
        coordinates: { lat: 26.7362, lng: 83.4215 },
        contactPhone: '+91 551 2207777',
        emergencyHelpline: 'Emergency Trauma Wing',
        badge: 'Demo listing — verification required',
        lastUpdated: now,
        distanceKm: 6.4,
        inventory: {
          'A+': 16,
          'A-': 5,
          'B+': 20,
          'B-': 6,
          'AB+': 9,
          'AB-': 3,
          'O+': 25,
          'O-': 7
        }
      }
    ],
    donors: [
      {
        id: 'don_gor_001',
        displayName: 'Amit K. (DON-801)',
        bloodGroup: 'O+',
        locality: 'Mohaddipur, Gorakhpur',
        coordinates: { lat: 26.7460, lng: 83.3930 },
        preferredContact: 'In-App Request',
        availabilityStatus: 'Available', // 'Available' | 'Busy' | 'Cooldown'
        lastDonationDate: '2026-06-10',
        consentNotifications: true,
        consentPrivacy: true,
        totalDonations: 4,
        lastUpdated: now
      },
      {
        id: 'don_gor_002',
        displayName: 'Pooja S. (DON-802)',
        bloodGroup: 'A+',
        locality: 'Betiahata, Gorakhpur',
        coordinates: { lat: 26.7495, lng: 83.3710 },
        preferredContact: 'SMS / In-App',
        availabilityStatus: 'Available',
        lastDonationDate: '2026-05-18',
        consentNotifications: true,
        consentPrivacy: true,
        totalDonations: 2,
        lastUpdated: now
      },
      {
        id: 'don_gor_003',
        displayName: 'Vikas Y. (DON-803)',
        bloodGroup: 'B+',
        locality: 'Golghar, Gorakhpur',
        coordinates: { lat: 26.7592, lng: 83.3725 },
        preferredContact: 'In-App Request',
        availabilityStatus: 'Available',
        lastDonationDate: '2026-04-12',
        consentNotifications: true,
        consentPrivacy: true,
        totalDonations: 6,
        lastUpdated: now
      },
      {
        id: 'don_gor_004',
        displayName: 'Anjali S. (DON-804)',
        bloodGroup: 'O-',
        locality: 'Rapti Nagar, Gorakhpur',
        coordinates: { lat: 26.7780, lng: 83.3760 },
        preferredContact: 'In-App Request',
        availabilityStatus: 'Available', // Universal Donor!
        lastDonationDate: '2026-07-02',
        consentNotifications: true,
        consentPrivacy: true,
        totalDonations: 5,
        lastUpdated: now
      },
      {
        id: 'don_gor_005',
        displayName: 'Rahul T. (DON-805)',
        bloodGroup: 'AB+',
        locality: 'Medical College Road, Gorakhpur',
        coordinates: { lat: 26.7710, lng: 83.3850 },
        preferredContact: 'In-App Request',
        availabilityStatus: 'Available',
        lastDonationDate: '2026-03-20',
        consentNotifications: true,
        consentPrivacy: true,
        totalDonations: 3,
        lastUpdated: now
      },
      {
        id: 'don_gor_006',
        displayName: 'Praveen M. (DON-806)',
        bloodGroup: 'O+',
        locality: 'Buxipur, Gorakhpur',
        coordinates: { lat: 26.7510, lng: 83.3650 },
        preferredContact: 'In-App Request',
        availabilityStatus: 'Available',
        lastDonationDate: '2026-05-30',
        consentNotifications: true,
        consentPrivacy: true,
        totalDonations: 3,
        lastUpdated: now
      }
    ],
    prescriptions: [
      {
        id: 'rx_01',
        title: 'Physician Consultation Prescription',
        doctorName: 'Dr. Priya Pandey',
        clinicName: 'Gorakhpur Family Care',
        date: '2026-09-10',
        fileType: 'image/png',
        fileName: 'prescription_dr_pandey_sep10.png',
        fileData: null, // Simulated file URL
        ocrExtractedDraft: 'R/x:\n1. Paracetamol 650mg - 1 tab SOS / after food\n2. Amoxicillin 500mg - 1 cap twice daily (8 AM - 8 PM)\n3. Pantoprazole 40mg - 1 tab before breakfast\nReview after 5 days.',
        verificationNotice: 'Draft extracted text — user verification required. Never assume OCR medicine names or dosages are correct.',
        status: 'Active'
      }
    ],
    medicines: [
      {
        id: 'med_01',
        prescriptionId: 'rx_01',
        name: 'Medicine A (Amoxicillin 500mg)',
        dosage: '1 Capsule (500mg)',
        frequency: 'Twice daily',
        startDate: '2026-09-10',
        endDate: '2026-09-17',
        reminderTimes: ['08:00', '20:00'], // 8:00 AM and 8:00 PM
        instructions: 'After meal with plenty of water',
        notes: 'Complete full 7-day antibiotic course without interruption.'
      },
      {
        id: 'med_02',
        prescriptionId: 'rx_01',
        name: 'Medicine B (Multivitamin & Zinc)',
        dosage: '1 Tablet',
        frequency: 'Once daily',
        startDate: '2026-09-10',
        endDate: '2026-09-24',
        reminderTimes: ['14:00'], // 2:00 PM
        instructions: 'After lunch',
        notes: 'Immunity booster supplementation.'
      }
    ],
    medicineReminders: [
      {
        id: 'rem_01',
        medicineId: 'med_01',
        medicineName: 'Medicine A (Amoxicillin 500mg)',
        timeSlot: '08:00 AM',
        date: '2026-09-12',
        status: 'Taken', // 'Taken' | 'Skipped' | 'Missed' | 'Pending'
        loggedAt: '2026-09-12T08:05:00.000Z'
      },
      {
        id: 'rem_02',
        medicineId: 'med_02',
        medicineName: 'Medicine B (Multivitamin & Zinc)',
        timeSlot: '02:00 PM',
        date: '2026-09-12',
        status: 'Pending',
        loggedAt: null
      },
      {
        id: 'rem_03',
        medicineId: 'med_01',
        medicineName: 'Medicine A (Amoxicillin 500mg)',
        timeSlot: '08:00 PM',
        date: '2026-09-12',
        status: 'Pending',
        loggedAt: null
      }
    ],
    medicalDocuments: [
      {
        id: 'doc_vault_01',
        title: 'Prescription - Dr. Priya Pandey',
        category: 'Prescription',
        date: '2026-09-10',
        facility: 'Gorakhpur Family Care',
        summary: 'Amoxicillin & Multivitamin prescription for upper respiratory symptoms.',
        isPrivate: true,
        referenceId: 'rx_01'
      },
      {
        id: 'doc_vault_02',
        title: 'Complete Blood Count (CBC) Lab Report',
        category: 'Lab Report',
        date: '2026-08-25',
        facility: 'City Diagnostics, Golghar',
        summary: 'Hemoglobin: 14.2 g/dL, WBC: 7,400, Platelets: 2.8 Lakhs. Normal profile.',
        isPrivate: true,
        referenceId: null
      },
      {
        id: 'doc_vault_03',
        title: 'COVID-19 Vaccination Certificate (Booster)',
        category: 'Immunization',
        date: '2023-01-15',
        facility: 'District Hospital Gorakhpur',
        summary: 'Fully vaccinated with Precautionary Dose.',
        isPrivate: true,
        referenceId: null
      }
    ],
    bloodRequests: [
      {
        id: 'req_bld_001',
        patientName: 'Ramesh Chandra (Ref #9821)',
        requiredBloodGroup: 'O+',
        unitsRequired: 2,
        currentLocation: 'Gorakhpur',
        hospitalName: 'BRD Medical College Emergency Wing',
        urgency: 'Emergency', // 'Normal' | 'Urgent' | 'Emergency'
        contactPhone: '+91 98765 44332',
        additionalNotes: 'Urgent surgery scheduled at trauma ICU. 2 units PRBC needed.',
        status: 'Searching', // Submitted -> Searching -> Contacted -> Provider Confirmation Pending -> Confirmed by Provider -> Completed / Cancelled
        createdAt: now,
        history: [
          { status: 'Submitted', timestamp: now, note: 'Emergency request registered in system.' },
          { status: 'Searching', timestamp: now, note: 'Broadcasting to compatible O+, O- blood banks & registered donors.' }
        ]
      }
    ],
    donationRequests: [
      {
        id: 'don_req_01',
        bloodRequestId: 'req_bld_001',
        donorId: 'don_gor_001',
        donorName: 'Amit K. (DON-801)',
        patientName: 'Ramesh Chandra',
        bloodGroup: 'O+',
        units: 1,
        hospital: 'BRD Medical College Emergency Wing',
        status: 'Pending', // 'Pending' | 'Accepted' | 'Declined'
        createdAt: now
      }
    ],
    appointmentRequests: [
      {
        id: 'apt_01',
        doctorId: 'doc_01',
        doctorName: 'Dr. Naveen Verma',
        specialty: 'Dermatology / Skin',
        patientName: 'Rajesh Sharma',
        patientPhone: '+91 98765 12345',
        preferredDate: '2026-09-15',
        preferredTime: '11:00 AM',
        symptoms: 'Recurring allergic skin rash and itching on arms.',
        status: 'Accepted', // 'Requested' | 'Accepted' | 'Declined' | 'Completed' | 'Cancelled'
        createdAt: '2026-09-11T10:00:00.000Z'
      }
    ],
    notifications: [
      {
        id: 'notif_01',
        title: 'Medicine Dose Scheduled',
        message: 'Upcoming: Medicine B (Multivitamin) scheduled for 2:00 PM today.',
        type: 'reminder',
        timestamp: now,
        isRead: false
      },
      {
        id: 'notif_02',
        title: 'Emergency Blood Search Active',
        message: 'Searching matching blood banks & donors for O+ blood in Gorakhpur.',
        type: 'emergency',
        timestamp: now,
        isRead: false
      }
    ]
  };
}

// Database Engine Class
class DatabaseService {
  constructor() {
    this.data = this.load();
  }

  load() {
    try {
      const stored = localStorage.getItem(DB_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Could not read from localStorage, using initial seed data', e);
    }
    const initial = getInitialSeedData();
    this.save(initial);
    return initial;
  }

  save(data = this.data) {
    try {
      localStorage.setItem(DB_KEY, JSON.stringify(data));
      this.data = data;
    } catch (e) {
      console.error('Failed to save to localStorage', e);
    }
  }

  resetToDefaults() {
    localStorage.removeItem(DB_KEY);
    this.data = getInitialSeedData();
    this.save(this.data);
    return this.data;
  }

  // Current User & Role Management
  getCurrentUser() {
    return this.data.currentUser;
  }

  setCurrentRole(role) {
    this.data.currentUser.role = role;
    this.save();
    return this.data.currentUser;
  }

  // Patient Profile
  getPatientProfile() {
    return this.data.patientProfile;
  }

  updatePatientProfile(profileData) {
    this.data.patientProfile = { ...this.data.patientProfile, ...profileData };
    this.save();
    return this.data.patientProfile;
  }

  // Doctors / Specialists
  getDoctors(filters = {}) {
    let list = [...this.data.doctors];
    if (filters.category && filters.category !== 'All') {
      list = list.filter(d => d.category.toLowerCase() === filters.category.toLowerCase());
    }
    if (filters.query) {
      const q = filters.query.toLowerCase();
      list = list.filter(d => 
        d.name.toLowerCase().includes(q) ||
        d.specialty.toLowerCase().includes(q) ||
        d.location.toLowerCase().includes(q)
      );
    }
    if (filters.location && filters.location !== 'All') {
      const loc = filters.location.toLowerCase();
      list = list.filter(d => d.location.toLowerCase().includes(loc));
    }
    return list;
  }

  getDoctorById(id) {
    return this.data.doctors.find(d => d.id === id);
  }

  // Appointments
  getAppointments() {
    return this.data.appointmentRequests || [];
  }

  createAppointment(appointmentData) {
    const newApt = {
      id: 'apt_' + Date.now(),
      doctorId: appointmentData.doctorId,
      doctorName: appointmentData.doctorName,
      specialty: appointmentData.specialty,
      patientName: appointmentData.patientName,
      patientPhone: appointmentData.patientPhone,
      preferredDate: appointmentData.preferredDate,
      preferredTime: appointmentData.preferredTime,
      symptoms: appointmentData.symptoms,
      status: 'Requested', // Requested -> Accepted / Declined -> Completed / Cancelled
      createdAt: new Date().toISOString()
    };
    this.data.appointmentRequests.unshift(newApt);
    this.addNotification({
      title: 'Appointment Request Sent',
      message: `Appointment requested with ${newApt.doctorName} for ${newApt.preferredDate}.`,
      type: 'appointment'
    });
    this.save();
    return newApt;
  }

  updateAppointmentStatus(id, newStatus) {
    const apt = this.data.appointmentRequests.find(a => a.id === id);
    if (apt) {
      apt.status = newStatus;
      this.save();
      this.addNotification({
        title: 'Appointment Status Updated',
        message: `Appointment with ${apt.doctorName} is now: ${newStatus}`,
        type: 'appointment'
      });
    }
    return apt;
  }

  // Prescriptions & Medicines
  getPrescriptions() {
    return this.data.prescriptions || [];
  }

  addPrescription(prescription) {
    const newRx = {
      id: 'rx_' + Date.now(),
      title: prescription.title || 'Uploaded Prescription',
      doctorName: prescription.doctorName || 'Consulting Physician',
      clinicName: prescription.clinicName || 'Gorakhpur Clinic',
      date: prescription.date || new Date().toISOString().split('T')[0],
      fileType: prescription.fileType || 'image/png',
      fileName: prescription.fileName || 'prescription_upload.png',
      fileData: prescription.fileData || null,
      ocrExtractedDraft: prescription.ocrExtractedDraft || '',
      verificationNotice: 'Draft extracted text — user verification required. Never assume OCR medicine names or dosages are correct.',
      status: 'Active'
    };
    this.data.prescriptions.unshift(newRx);

    // Also auto-save to Patient Medical Health Passport document vault
    this.data.medicalDocuments.unshift({
      id: 'doc_vault_' + Date.now(),
      title: newRx.title,
      category: 'Prescription',
      date: newRx.date,
      facility: newRx.clinicName,
      summary: `Uploaded prescription doc: ${newRx.fileName}`,
      isPrivate: true,
      referenceId: newRx.id
    });

    this.save();
    return newRx;
  }

  getMedicines() {
    return this.data.medicines || [];
  }

  addMedicine(medicineData) {
    const newMed = {
      id: 'med_' + Date.now(),
      prescriptionId: medicineData.prescriptionId || null,
      name: medicineData.name,
      dosage: medicineData.dosage,
      frequency: medicineData.frequency,
      startDate: medicineData.startDate,
      endDate: medicineData.endDate,
      reminderTimes: Array.isArray(medicineData.reminderTimes) ? medicineData.reminderTimes : [medicineData.reminderTimes],
      instructions: medicineData.instructions || 'As directed by physician',
      notes: medicineData.notes || ''
    };
    this.data.medicines.push(newMed);

    // Auto-generate reminders for today based on times
    const todayStr = new Date().toISOString().split('T')[0];
    newMed.reminderTimes.forEach(time => {
      let formattedTime = time;
      const [h, m] = time.split(':');
      const hour = parseInt(h);
      const ampm = hour >= 12 ? 'PM' : 'AM';
      const h12 = hour % 12 || 12;
      formattedTime = `${h12.toString().padStart(2, '0')}:${m} ${ampm}`;

      this.data.medicineReminders.push({
        id: 'rem_' + Date.now() + Math.floor(Math.random() * 1000),
        medicineId: newMed.id,
        medicineName: newMed.name,
        timeSlot: formattedTime,
        date: todayStr,
        status: 'Pending',
        loggedAt: null
      });
    });

    this.save();
    return newMed;
  }

  deleteMedicine(id) {
    this.data.medicines = this.data.medicines.filter(m => m.id !== id);
    this.data.medicineReminders = this.data.medicineReminders.filter(r => r.medicineId !== id);
    this.save();
  }

  getRemindersForToday() {
    const todayStr = new Date().toISOString().split('T')[0];
    return this.data.medicineReminders.filter(r => r.date === todayStr);
  }

  updateReminderStatus(id, newStatus) {
    const rem = this.data.medicineReminders.find(r => r.id === id);
    if (rem) {
      rem.status = newStatus; // 'Taken' | 'Skipped' | 'Missed'
      rem.loggedAt = new Date().toISOString();
      this.save();
    }
    return rem;
  }

  calculateDailyAdherence() {
    const reminders = this.getRemindersForToday();
    if (!reminders.length) return 100;
    const takenCount = reminders.filter(r => r.status === 'Taken').length;
    return Math.round((takenCount / reminders.length) * 100);
  }

  // Blood Finder & Requests
  getBloodBanks(filters = {}) {
    let list = [...this.data.bloodBanks];
    if (filters.bloodGroup && filters.bloodGroup !== 'All') {
      // Sort or filter by inventory
      list = list.map(bb => ({
        ...bb,
        availableUnitsForGroup: bb.inventory[filters.bloodGroup] || 0
      }));
    }
    return list;
  }

  getDonors(filters = {}) {
    let list = [...this.data.donors];
    if (filters.bloodGroup && filters.bloodGroup !== 'All') {
      list = list.filter(d => d.bloodGroup === filters.bloodGroup);
    }
    if (filters.availability && filters.availability !== 'All') {
      list = list.filter(d => d.availabilityStatus === filters.availability);
    }
    return list;
  }

  addDonor(donorData) {
    const id = 'don_gor_' + (this.data.donors.length + 101);
    const newDonor = {
      id: id,
      displayName: donorData.displayName || `${donorData.name.split(' ')[0]} (DON-${Math.floor(Math.random() * 899 + 100)})`,
      bloodGroup: donorData.bloodGroup,
      locality: donorData.locality || 'Gorakhpur',
      coordinates: donorData.coordinates || { lat: 26.7580 + (Math.random() * 0.02 - 0.01), lng: 83.3730 + (Math.random() * 0.02 - 0.01) },
      preferredContact: donorData.preferredContact || 'In-App Request',
      availabilityStatus: donorData.availabilityStatus || 'Available',
      lastDonationDate: donorData.lastDonationDate || '',
      consentNotifications: true,
      consentPrivacy: true,
      totalDonations: 0,
      lastUpdated: new Date().toISOString()
    };
    this.data.donors.unshift(newDonor);
    this.save();
    return newDonor;
  }

  updateDonorAvailability(donorId, status) {
    const donor = this.data.donors.find(d => d.id === donorId);
    if (donor) {
      donor.availabilityStatus = status;
      donor.lastUpdated = new Date().toISOString();
      this.save();
    }
    return donor;
  }

  // Emergency Blood Requests
  getBloodRequests() {
    return this.data.bloodRequests || [];
  }

  createBloodRequest(requestData) {
    const now = new Date().toISOString();
    const newReq = {
      id: 'req_bld_' + Date.now(),
      patientName: requestData.patientName,
      requiredBloodGroup: requestData.requiredBloodGroup,
      unitsRequired: parseInt(requestData.unitsRequired) || 1,
      currentLocation: requestData.currentLocation || 'Gorakhpur',
      hospitalName: requestData.hospitalName,
      urgency: requestData.urgency || 'Urgent', // Normal | Urgent | Emergency
      contactPhone: requestData.contactPhone,
      additionalNotes: requestData.additionalNotes || '',
      status: 'Submitted', // Submitted -> Searching -> Contacted -> Provider Confirmation Pending -> Confirmed by Provider -> Completed
      createdAt: now,
      history: [
        { status: 'Submitted', timestamp: now, note: 'Request initiated by patient/requester.' }
      ]
    };
    this.data.bloodRequests.unshift(newReq);

    // Generate matched donation requests for compatible Gorakhpur donors
    const compatibleDonors = this.data.donors.filter(d => 
      isBloodCompatible(d.bloodGroup, newReq.requiredBloodGroup) && 
      d.availabilityStatus === 'Available'
    );

    compatibleDonors.slice(0, 3).forEach(d => {
      this.data.donationRequests.unshift({
        id: 'don_req_' + Date.now() + Math.floor(Math.random() * 100),
        bloodRequestId: newReq.id,
        donorId: d.id,
        donorName: d.displayName,
        patientName: newReq.patientName,
        bloodGroup: newReq.requiredBloodGroup,
        units: 1,
        hospital: newReq.hospitalName,
        status: 'Pending',
        createdAt: now
      });
    });

    this.addNotification({
      title: 'Emergency Blood Request Active',
      message: `Emergency search initiated for ${newReq.unitsRequired} units of ${newReq.requiredBloodGroup} at ${newReq.hospitalName}.`,
      type: 'emergency'
    });

    this.save();
    return newReq;
  }

  updateBloodRequestStatus(id, newStatus, note = '') {
    const req = this.data.bloodRequests.find(r => r.id === id);
    if (req) {
      req.status = newStatus;
      req.history.push({
        status: newStatus,
        timestamp: new Date().toISOString(),
        note: note || `Status updated to ${newStatus}`
      });
      this.save();
      this.addNotification({
        title: 'Blood Request Update',
        message: `Request for ${req.patientName} (${req.requiredBloodGroup}) is now: ${newStatus}`,
        type: 'emergency'
      });
    }
    return req;
  }

  getDonationRequests(donorId = null) {
    if (donorId) {
      return this.data.donationRequests.filter(r => r.donorId === donorId);
    }
    return this.data.donationRequests;
  }

  respondToDonationRequest(requestId, responseStatus) { // 'Accepted' | 'Declined'
    const donReq = this.data.donationRequests.find(r => r.id === requestId);
    if (donReq) {
      donReq.status = responseStatus;
      
      // Update parent blood request status if accepted
      const bloodReq = this.data.bloodRequests.find(b => b.id === donReq.bloodRequestId);
      if (bloodReq && responseStatus === 'Accepted') {
        bloodReq.status = 'Provider Confirmation Pending';
        bloodReq.history.push({
          status: 'Provider Confirmation Pending',
          timestamp: new Date().toISOString(),
          note: `Donor ${donReq.donorName} accepted donation request. Awaiting hospital confirmation.`
        });
      }
      this.save();
    }
    return donReq;
  }

  // Blood Bank Inventory Management (Staff mode)
  updateBloodBankInventory(bankId, bloodGroup, units) {
    const bank = this.data.bloodBanks.find(b => b.id === bankId);
    if (bank && bank.inventory) {
      bank.inventory[bloodGroup] = Math.max(0, parseInt(units) || 0);
      bank.lastUpdated = new Date().toISOString();
      this.save();
    }
    return bank;
  }

  // Medical Passport & Document Vault
  getMedicalDocuments() {
    return this.data.medicalDocuments || [];
  }

  addMedicalDocument(doc) {
    const newDoc = {
      id: 'doc_vault_' + Date.now(),
      title: doc.title,
      category: doc.category || 'General Document',
      date: doc.date || new Date().toISOString().split('T')[0],
      facility: doc.facility || 'Healthcare Facility, Gorakhpur',
      summary: doc.summary || '',
      isPrivate: true,
      referenceId: doc.referenceId || null
    };
    this.data.medicalDocuments.unshift(newDoc);
    this.save();
    return newDoc;
  }

  // Notifications
  getNotifications() {
    return this.data.notifications || [];
  }

  addNotification({ title, message, type = 'general' }) {
    const notif = {
      id: 'notif_' + Date.now(),
      title,
      message,
      type,
      timestamp: new Date().toISOString(),
      isRead: false
    };
    this.data.notifications.unshift(notif);
    this.save();
    return notif;
  }

  markAllNotificationsRead() {
    this.data.notifications.forEach(n => n.isRead = true);
    this.save();
  }
}

export const db = new DatabaseService();
