/**
 * Module 3: Blood Finder – Main Emergency Feature (Mission Control Edition)
 * Team: The Code Burner | Maharana Pratap Institute of Technology, Gorakhpur
 */

import { db, isBloodCompatible, BLOOD_COMPATIBILITY, calculateDistance } from '../db.js';

export function renderBloodFinderModule(container) {
  let selectedBloodGroup = 'O+';
  let activeTab = 'emergency-search'; // 'emergency-search' | 'active-requests' | 'compatibility-matrix'

  function getRankedMatches(reqBloodGroup, userLocationCoords = { lat: 26.7588, lng: 83.3697 }) {
    const bloodBanks = db.getBloodBanks();
    const donors = db.getDonors();

    const rankedBanks = bloodBanks.map(bank => {
      let compatibleUnits = 0;
      let exactUnits = bank.inventory[reqBloodGroup] || 0;
      
      const compatibleGroups = BLOOD_COMPATIBILITY[reqBloodGroup]?.canReceiveFrom || [reqBloodGroup];
      compatibleGroups.forEach(grp => {
        compatibleUnits += (bank.inventory[grp] || 0);
      });

      const dist = calculateDistance(
        userLocationCoords.lat, userLocationCoords.lng,
        bank.coordinates.lat, bank.coordinates.lng
      );

      let score = (exactUnits * 10) + (compatibleUnits * 4) - (dist * 2);

      return {
        type: 'Blood Bank',
        id: bank.id,
        name: bank.name,
        facilityType: bank.facilityType,
        location: bank.location,
        address: bank.address,
        phone: bank.contactPhone,
        helpline: bank.emergencyHelpline,
        coordinates: bank.coordinates,
        distanceKm: dist,
        reportedUnitsExact: exactUnits,
        reportedUnitsCompatible: compatibleUnits,
        lastUpdated: bank.lastUpdated,
        badge: bank.badge,
        score: score,
        compatibleGroups: compatibleGroups
      };
    }).sort((a, b) => b.score - a.score);

    const rankedDonors = donors.filter(d => {
      return isBloodCompatible(d.bloodGroup, reqBloodGroup) && d.availabilityStatus === 'Available';
    }).map(donor => {
      const dist = calculateDistance(
        userLocationCoords.lat, userLocationCoords.lng,
        donor.coordinates.lat, donor.coordinates.lng
      );
      const isExact = donor.bloodGroup === reqBloodGroup;
      let score = (isExact ? 60 : 35) - (dist * 2);

      return {
        type: 'Registered Donor',
        id: donor.id,
        displayName: donor.displayName,
        bloodGroup: donor.bloodGroup,
        isExact: isExact,
        locality: donor.locality,
        coordinates: donor.coordinates,
        distanceKm: dist,
        availability: donor.availabilityStatus,
        lastDonationDate: donor.lastDonationDate,
        totalDonations: donor.totalDonations,
        preferredContact: donor.preferredContact,
        lastUpdated: donor.lastUpdated,
        score: score
      };
    }).sort((a, b) => b.score - a.score);

    return { rankedBanks, rankedDonors };
  }

  function render() {
    const bloodRequests = db.getBloodRequests();
    const { rankedBanks, rankedDonors } = getRankedMatches(selectedBloodGroup);

    container.innerHTML = `
      <div class="space-y-8 animate-fade-in text-slate-100">
        
        <!-- Emergency Page Header -->
        <div class="glass-panel p-6 md:p-8 relative overflow-hidden border border-red-500/30">
          <div class="absolute -right-16 -top-16 w-80 h-80 bg-red-600/15 rounded-full blur-3xl pointer-events-none"></div>
          
          <div class="relative z-10 max-w-3xl space-y-2">
            <div class="flex items-center gap-3 flex-wrap">
              <span class="badge-emergency">
                <span class="w-2 h-2 rounded-full bg-red-400 animate-ping"></span>
                Emergency Rapid Response Locator
              </span>
              <span class="badge-demo">Gorakhpur Region</span>
            </div>
            
            <h1 class="text-2xl md:text-4xl font-black tracking-tight text-white">
              Emergency Blood Finder & Regional Radar
            </h1>
            
            <p class="text-slate-300 text-xs md:text-sm leading-relaxed max-w-2xl font-normal">
              Broadcast emergency blood requests, rank compatible blood banks and consented donors using ABO/Rh clinical rules, reported stock, and live Haversine distance calculations.
            </p>
          </div>
        </div>

        <!-- Mandatory Critical Safety Protocol Alert -->
        <div class="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-xs text-red-200 flex items-start gap-3 shadow-lg">
          <svg class="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
          <div class="space-y-1 leading-relaxed">
            <p class="font-extrabold text-white">Mandatory Clinical Transfusion Protocol:</p>
            <p class="text-red-300">
              "Blood availability shown in this prototype is illustrative. Always confirm availability and compatibility with the hospital or blood bank. Actual donor eligibility, mandatory pathogen screening, cross-matching, and suitability must be confirmed strictly by treating physicians."
            </p>
          </div>
        </div>

        <!-- Navigation Subtabs -->
        <div class="flex border-b border-white/10 gap-6 text-xs font-black">
          <button data-tab="emergency-search" class="pb-3 ${activeTab === 'emergency-search' ? 'text-red-400 border-b-2 border-red-500' : 'text-slate-400 hover:text-slate-200'} transition-colors flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            Broadcast New Request & Search Matches
          </button>
          <button data-tab="active-requests" class="pb-3 ${activeTab === 'active-requests' ? 'text-red-400 border-b-2 border-red-500' : 'text-slate-400 hover:text-slate-200'} transition-colors flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
            Live Emergency Pipeline (${bloodRequests.length})
          </button>
          <button data-tab="compatibility-matrix" class="pb-3 ${activeTab === 'compatibility-matrix' ? 'text-red-400 border-b-2 border-red-500' : 'text-slate-400 hover:text-slate-200'} transition-colors flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
            ABO/Rh Clinical Compatibility Matrix
          </button>
        </div>

        ${activeTab === 'emergency-search' ? `
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <!-- Left: Request Submission Form -->
            <div class="lg:col-span-5 glass-panel p-6 space-y-4">
              <div class="flex items-center justify-between pb-3 border-b border-white/5">
                <h3 class="text-sm font-black text-white flex items-center gap-2">
                  <span class="w-3 h-3 bg-red-500 rounded-full animate-pulse"></span>
                  Submit Emergency Blood Request
                </h3>
                <button id="fill-sample-request-btn" class="text-xs text-red-400 font-bold hover:underline">
                  Auto-fill O+ Emergency
                </button>
              </div>

              <form id="emergency-blood-form" class="space-y-3.5 text-xs text-slate-300">
                <div>
                  <label class="block font-bold text-white mb-1">Patient Name / Reference ID *</label>
                  <input type="text" id="req-patient-name" value="Ramesh Chandra (Ref #9821)" required class="w-full p-3 bg-slate-900/90 border border-white/10 rounded-xl text-white font-bold focus:ring-2 focus:ring-red-500" />
                </div>

                <div class="grid grid-cols-2 gap-3">
                  <div>
                    <label class="block font-bold text-white mb-1">Required Blood Group *</label>
                    <select id="req-blood-group" class="w-full p-3 bg-slate-900/90 border border-white/10 rounded-xl font-black text-red-400 focus:ring-2 focus:ring-red-500">
                      <option value="O+" ${selectedBloodGroup === 'O+' ? 'selected' : ''}>O+ (Positive)</option>
                      <option value="O-" ${selectedBloodGroup === 'O-' ? 'selected' : ''}>O- (Universal Donor)</option>
                      <option value="A+" ${selectedBloodGroup === 'A+' ? 'selected' : ''}>A+ (Positive)</option>
                      <option value="A-" ${selectedBloodGroup === 'A-' ? 'selected' : ''}>A- (Negative)</option>
                      <option value="B+" ${selectedBloodGroup === 'B+' ? 'selected' : ''}>B+ (Positive)</option>
                      <option value="B-" ${selectedBloodGroup === 'B-' ? 'selected' : ''}>B- (Negative)</option>
                      <option value="AB+" ${selectedBloodGroup === 'AB+' ? 'selected' : ''}>AB+ (Universal Recipient)</option>
                      <option value="AB-" ${selectedBloodGroup === 'AB-' ? 'selected' : ''}>AB- (Negative)</option>
                    </select>
                  </div>
                  <div>
                    <label class="block font-bold text-white mb-1">Units Required *</label>
                    <input type="number" id="req-units" min="1" max="10" value="2" required class="w-full p-3 bg-slate-900/90 border border-white/10 rounded-xl font-black text-white focus:ring-2 focus:ring-red-500" />
                  </div>
                </div>

                <div class="grid grid-cols-2 gap-3">
                  <div>
                    <label class="block font-bold text-white mb-1">Current Location *</label>
                    <input type="text" id="req-location" value="Gorakhpur" required class="w-full p-3 bg-slate-900/90 border border-white/10 rounded-xl font-bold text-white focus:ring-2 focus:ring-red-500" />
                  </div>
                  <div>
                    <label class="block font-bold text-white mb-1">Urgency Level *</label>
                    <select id="req-urgency" class="w-full p-3 bg-red-500/20 border border-red-500/40 rounded-xl font-black text-red-300 focus:ring-2 focus:ring-red-500">
                      <option value="Emergency" selected>🚨 Emergency (Immediate)</option>
                      <option value="Urgent">⚡ Urgent (Within 4 Hours)</option>
                      <option value="Normal">🗓️ Normal (Elective)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label class="block font-bold text-white mb-1">Hospital / Medical Center *</label>
                  <input type="text" id="req-hospital" value="BRD Medical College Emergency Wing" required class="w-full p-3 bg-slate-900/90 border border-white/10 rounded-xl font-bold text-white focus:ring-2 focus:ring-red-500" />
                </div>

                <div>
                  <label class="block font-bold text-white mb-1">Emergency Attendant Contact *</label>
                  <input type="tel" id="req-contact" value="+91 98765 44332" required class="w-full p-3 bg-slate-900/90 border border-white/10 rounded-xl font-bold text-white focus:ring-2 focus:ring-red-500" />
                </div>

                <div>
                  <label class="block font-bold text-white mb-1">Clinical Notes</label>
                  <textarea id="req-notes" rows="2" class="w-full p-3 bg-slate-900/90 border border-white/10 rounded-xl text-white font-mono text-xs">Urgent surgery scheduled at trauma ICU. 2 units PRBC needed immediately.</textarea>
                </div>

                <button type="submit" class="w-full py-3.5 btn-neon-crimson rounded-2xl text-xs font-black transition-all flex items-center justify-center gap-2">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>
                  Broadcast Emergency Blood Request
                </button>
              </form>
            </div>

            <!-- Right: Ranked Search Results -->
            <div class="lg:col-span-7 space-y-6">
              <div class="flex items-center justify-between">
                <div>
                  <h3 class="text-base font-black text-white flex items-center gap-2">
                    Ranked Availability For <span class="px-2.5 py-0.5 bg-red-600 text-white rounded-lg font-black text-xs">${selectedBloodGroup}</span>
                  </h3>
                  <p class="text-xs text-slate-400 font-medium">Sorted by: ABO Compatibility > Reported Stock > Proximity > Recency</p>
                </div>
                <button id="view-on-map-btn" class="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm">
                  <svg class="w-4 h-4 text-teal-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/></svg>
                  Radar Map View
                </button>
              </div>

              <!-- Matching Blood Banks Category -->
              <div class="space-y-3">
                <div class="text-xs font-extrabold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                  <span class="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse"></span>
                  Verified Regional Blood Banks (${rankedBanks.length})
                </div>

                <div class="space-y-3.5">
                  ${rankedBanks.map(bank => `
                    <div class="glass-panel p-5 hover:border-red-500/50 transition-all">
                      <div class="flex items-start justify-between gap-3">
                        <div>
                          <div class="flex items-center gap-2 mb-1">
                            <h4 class="text-sm font-black text-white">${bank.name}</h4>
                            <span class="badge-demo text-[10px]">Demo Stock</span>
                          </div>
                          <p class="text-xs text-slate-400 font-medium">${bank.facilityType} • ${bank.location}</p>
                          <div class="flex items-center gap-4 text-xs text-slate-300 mt-2.5">
                            <span class="flex items-center gap-1">📍 <strong>~${bank.distanceKm} km</strong> from location</span>
                            <span>⏱️ Live Sync: Today</span>
                          </div>
                        </div>

                        <div class="text-right flex-shrink-0">
                          <div class="text-[10px] text-slate-400 font-bold uppercase">Reported Units:</div>
                          <div class="text-2xl font-black ${bank.reportedUnitsExact > 5 ? 'text-emerald-400' : 'text-amber-400'}">
                            ${bank.reportedUnitsExact} Units
                          </div>
                          <div class="text-[10px] text-slate-400 font-medium">(${bank.reportedUnitsCompatible} Compatible)</div>
                        </div>
                      </div>

                      <div class="flex items-center justify-between pt-3.5 mt-3.5 border-t border-white/5">
                        <div class="text-xs text-slate-300">
                          Emergency Desk: <strong class="text-white font-mono">${bank.phone}</strong>
                        </div>
                        <div class="flex gap-2">
                          <button data-action="call-bloodbank" data-name="${bank.name}" data-phone="${bank.phone}" class="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all">
                            Call Desk
                          </button>
                          <button data-action="request-facility" data-id="${bank.id}" data-name="${bank.name}" class="btn-neon-crimson px-3.5 py-1.5 rounded-xl text-xs font-bold">
                            Requisition
                          </button>
                        </div>
                      </div>
                    </div>
                  `).join('')}
                </div>
              </div>

              <!-- Matching Consented Donors Category -->
              <div class="space-y-3 pt-2">
                <div class="text-xs font-extrabold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                  <span class="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
                  Consented Donors Available for Immediate Call (${rankedDonors.length})
                </div>

                ${rankedDonors.length === 0 ? `
                  <div class="glass-panel p-6 text-center text-xs text-slate-400">
                    No active consented donors available for ${selectedBloodGroup} right now.
                  </div>
                ` : `
                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    ${rankedDonors.map(d => `
                      <div class="glass-panel p-4 hover:border-amber-500/50 transition-all flex flex-col justify-between">
                        <div>
                          <div class="flex items-start justify-between mb-2">
                            <div>
                              <div class="text-xs font-black text-white">${d.displayName}</div>
                              <div class="text-[11px] text-slate-400 mt-0.5">📍 ${d.locality} (~${d.distanceKm} km)</div>
                            </div>
                            <span class="text-xs font-black px-2.5 py-0.5 rounded-lg ${d.isExact ? 'bg-red-500/20 text-red-300 border border-red-500/40' : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'}">
                              ${d.bloodGroup} ${d.isExact ? '(Exact)' : '(Compatible)'}
                            </span>
                          </div>
                          <div class="text-[11px] text-slate-400 mt-2">
                            Donated: ${d.totalDonations} Times • Contact: In-App Consent
                          </div>
                        </div>

                        <div class="pt-3 mt-3 border-t border-white/5 flex items-center justify-between">
                          <span class="text-[10px] text-emerald-400 font-bold">● Ready to Donate</span>
                          <button data-action="send-donor-request" data-id="${d.id}" data-name="${d.displayName}" class="px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-bold">
                            Send Request
                          </button>
                        </div>
                      </div>
                    `).join('')}
                  </div>
                `}
              </div>
            </div>
          </div>
        ` : ''}

        <!-- Tab 2: Live Emergency Pipeline -->
        ${activeTab === 'active-requests' ? `
          <div class="glass-panel p-6 space-y-6">
            <div class="flex items-center justify-between">
              <div>
                <h3 class="text-base font-black text-white">Emergency Blood Request Pipeline</h3>
                <p class="text-xs text-slate-400">Trace progression: Submitted ➔ Searching ➔ Contacted ➔ Provider Confirmation Pending ➔ Confirmed by Provider ➔ Completed</p>
              </div>
              <span class="badge-emergency">
                ${bloodRequests.length} Active Records
              </span>
            </div>

            <div class="space-y-4">
              ${bloodRequests.map(req => renderRequestPipelineCard(req)).join('')}
            </div>
          </div>
        ` : ''}

        <!-- Tab 3: Compatibility Engine Guide -->
        ${activeTab === 'compatibility-matrix' ? `
          <div class="glass-panel p-6 space-y-6">
            <div>
              <h3 class="text-base font-black text-white">ABO & Rh Clinical Compatibility Reference</h3>
              <p class="text-xs text-slate-400">Clinical cross-match logic used by the Mediscan ranking algorithm.</p>
            </div>

            <div class="overflow-x-auto">
              <table class="w-full text-xs text-left text-slate-300">
                <thead>
                  <tr class="bg-slate-900/90 text-slate-200 font-black uppercase text-[10px] tracking-wider border-b border-white/10">
                    <th class="py-3 px-4">Recipient Blood Group</th>
                    <th class="py-3 px-4">Can Receive From (Safe Donors)</th>
                    <th class="py-3 px-4">Can Donate To</th>
                    <th class="py-3 px-4">Classification</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-white/5">
                  <tr class="hover:bg-slate-800/40">
                    <td class="py-3 px-4 font-black text-red-400 text-sm">O-</td>
                    <td class="py-3 px-4 font-bold">O- only</td>
                    <td class="py-3 px-4 font-bold text-emerald-400">All (Universal Donor)</td>
                    <td class="py-3 px-4"><span class="badge-neon">Universal Donor</span></td>
                  </tr>
                  <tr class="hover:bg-slate-800/40">
                    <td class="py-3 px-4 font-black text-red-400 text-sm">O+</td>
                    <td class="py-3 px-4 font-bold">O+, O-</td>
                    <td class="py-3 px-4">O+, A+, B+, AB+</td>
                    <td class="py-3 px-4 text-slate-400">Most common Indian donor type</td>
                  </tr>
                  <tr class="hover:bg-slate-800/40">
                    <td class="py-3 px-4 font-black text-red-400 text-sm">A-</td>
                    <td class="py-3 px-4 font-bold">A-, O-</td>
                    <td class="py-3 px-4">A-, A+, AB-, AB+</td>
                    <td class="py-3 px-4 text-slate-400">Rh- recipient</td>
                  </tr>
                  <tr class="hover:bg-slate-800/40">
                    <td class="py-3 px-4 font-black text-red-400 text-sm">A+</td>
                    <td class="py-3 px-4 font-bold">A+, A-, O+, O-</td>
                    <td class="py-3 px-4">A+, AB+</td>
                    <td class="py-3 px-4 text-slate-400">Common group</td>
                  </tr>
                  <tr class="hover:bg-slate-800/40">
                    <td class="py-3 px-4 font-black text-red-400 text-sm">B-</td>
                    <td class="py-3 px-4 font-bold">B-, O-</td>
                    <td class="py-3 px-4">B-, B+, AB-, AB+</td>
                    <td class="py-3 px-4 text-slate-400">Rh- recipient</td>
                  </tr>
                  <tr class="hover:bg-slate-800/40">
                    <td class="py-3 px-4 font-black text-red-400 text-sm">B+</td>
                    <td class="py-3 px-4 font-bold">B+, B-, O+, O-</td>
                    <td class="py-3 px-4">B+, AB+</td>
                    <td class="py-3 px-4 text-slate-400">Common in Northern India</td>
                  </tr>
                  <tr class="hover:bg-slate-800/40">
                    <td class="py-3 px-4 font-black text-red-400 text-sm">AB-</td>
                    <td class="py-3 px-4 font-bold">AB-, A-, B-, O-</td>
                    <td class="py-3 px-4">AB-, AB+</td>
                    <td class="py-3 px-4 text-slate-400">Rare group</td>
                  </tr>
                  <tr class="hover:bg-slate-800/40">
                    <td class="py-3 px-4 font-black text-red-400 text-sm">AB+</td>
                    <td class="py-3 px-4 font-bold text-emerald-400">All (Universal Recipient)</td>
                    <td class="py-3 px-4">AB+ only</td>
                    <td class="py-3 px-4"><span class="badge-neon">Universal Recipient</span></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        ` : ''}
      </div>
    `;

    attachEvents();
  }

  function renderRequestPipelineCard(req) {
    const statuses = [
      'Submitted',
      'Searching',
      'Contacted',
      'Provider Confirmation Pending',
      'Confirmed by Provider',
      'Completed'
    ];

    const currentIdx = statuses.indexOf(req.status);

    return `
      <div class="glass-panel p-6 space-y-4 hover:border-red-500/50 transition-all">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div class="flex items-center gap-2">
              <h4 class="text-sm font-black text-white">${req.patientName}</h4>
              <span class="px-2.5 py-0.5 bg-red-600 text-white rounded-lg text-xs font-black">${req.requiredBloodGroup}</span>
              <span class="badge-emergency text-[10px]">${req.unitsRequired} Units Needed</span>
            </div>
            <p class="text-xs text-slate-400 mt-1">
              Hospital: <strong class="text-white">${req.hospitalName}</strong> • Location: ${req.currentLocation}
            </p>
          </div>

          <div class="flex items-center gap-2">
            <span class="status-pill status-${req.status.toLowerCase().replace(/\s+/g, '-')}">
              ${req.status}
            </span>
          </div>
        </div>

        <!-- Pipeline Step Indicator -->
        <div class="pt-2">
          <div class="grid grid-cols-6 gap-1.5 text-center">
            ${statuses.map((st, idx) => {
              const isPassed = currentIdx >= idx;
              const isCurrent = currentIdx === idx;
              return `
                <div class="flex flex-col items-center">
                  <div class="w-full h-2 rounded-full mb-1.5 transition-all ${
                    isPassed ? 'bg-red-500 shadow-sm shadow-red-500/50' : 'bg-slate-800'
                  } ${isCurrent ? 'ring-2 ring-red-400 animate-pulse' : ''}"></div>
                  <span class="text-[9px] font-bold line-clamp-1 ${isPassed ? 'text-white' : 'text-slate-500'}">
                    ${st}
                  </span>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        <!-- Timeline Log notes -->
        <div class="bg-slate-900/80 p-3.5 rounded-2xl border border-white/5 text-xs space-y-1 font-mono">
          <div class="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">Status History:</div>
          ${req.history.map(h => `
            <div class="flex items-start gap-2 text-slate-300 text-[11px]">
              <span class="text-teal-400 flex-shrink-0">${new Date(h.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}:</span>
              <span><strong>${h.status}:</strong> ${h.note}</span>
            </div>
          `).join('')}
        </div>

        <!-- Interactive State Advance buttons (for demo) -->
        <div class="flex flex-wrap items-center justify-between pt-2 border-t border-white/5 gap-2">
          <div class="text-[11px] text-slate-400 font-mono">
            Attendant Phone: ${req.contactPhone}
          </div>

          <div class="flex items-center gap-2">
            <span class="text-[10px] text-slate-400 font-bold">Demo Status Controls:</span>
            ${req.status === 'Submitted' ? `
              <button data-action="advance-status" data-id="${req.id}" data-status="Searching" class="px-2.5 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-bold">
                Start Search
              </button>
            ` : ''}
            ${req.status === 'Searching' ? `
              <button data-action="advance-status" data-id="${req.id}" data-status="Contacted" class="px-2.5 py-1 bg-purple-500/20 text-purple-300 border border-purple-500/40 rounded-xl text-xs font-bold">
                Contact Facilities
              </button>
            ` : ''}
            ${req.status === 'Contacted' ? `
              <button data-action="advance-status" data-id="${req.id}" data-status="Provider Confirmation Pending" class="px-2.5 py-1 bg-orange-500/20 text-orange-300 border border-orange-500/40 rounded-xl text-xs font-bold">
                Pending Provider
              </button>
            ` : ''}
            ${req.status === 'Provider Confirmation Pending' ? `
              <button data-action="advance-status" data-id="${req.id}" data-status="Confirmed by Provider" class="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-xl text-xs font-bold">
                Provider Confirmed
              </button>
            ` : ''}
            ${req.status === 'Confirmed by Provider' ? `
              <button data-action="advance-status" data-id="${req.id}" data-status="Completed" class="btn-neon-teal px-3 py-1 rounded-xl text-xs font-black">
                Mark Completed
              </button>
            ` : ''}
            ${req.status !== 'Completed' && req.status !== 'Cancelled' ? `
              <button data-action="advance-status" data-id="${req.id}" data-status="Cancelled" class="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded-xl text-xs font-medium">
                Cancel
              </button>
            ` : ''}
          </div>
        </div>
      </div>
    `;
  }

  function attachEvents() {
    container.querySelectorAll('[data-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        activeTab = btn.dataset.tab;
        render();
      });
    });

    const bgSelect = container.querySelector('#req-blood-group');
    if (bgSelect) {
      bgSelect.addEventListener('change', (e) => {
        selectedBloodGroup = e.target.value;
        render();
      });
    }

    const fillSampleBtn = container.querySelector('#fill-sample-request-btn');
    if (fillSampleBtn) {
      fillSampleBtn.addEventListener('click', () => {
        selectedBloodGroup = 'O+';
        const nameInp = container.querySelector('#req-patient-name');
        const unitsInp = container.querySelector('#req-units');
        const locInp = container.querySelector('#req-location');
        const hospInp = container.querySelector('#req-hospital');
        const urgencyInp = container.querySelector('#req-urgency');
        if (nameInp) nameInp.value = 'Ramesh Chandra (Ref #9821)';
        if (unitsInp) unitsInp.value = '2';
        if (locInp) locInp.value = 'Gorakhpur';
        if (hospInp) hospInp.value = 'BRD Medical College Emergency Wing';
        if (urgencyInp) urgencyInp.value = 'Emergency';
        render();
        window.showToast?.('Sample O+ 2 units emergency request loaded.', 'info');
      });
    }

    const form = container.querySelector('#emergency-blood-form');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const patientName = container.querySelector('#req-patient-name').value;
        const requiredBloodGroup = container.querySelector('#req-blood-group').value;
        const unitsRequired = container.querySelector('#req-units').value;
        const currentLocation = container.querySelector('#req-location').value;
        const hospitalName = container.querySelector('#req-hospital').value;
        const urgency = container.querySelector('#req-urgency').value;
        const contactPhone = container.querySelector('#req-contact').value;
        const additionalNotes = container.querySelector('#req-notes').value;

        const req = db.createBloodRequest({
          patientName,
          requiredBloodGroup,
          unitsRequired,
          currentLocation,
          hospitalName,
          urgency,
          contactPhone,
          additionalNotes
        });

        window.showToast?.(`Emergency request for ${unitsRequired} units of ${requiredBloodGroup} broadcasted!`, 'emergency');
        activeTab = 'active-requests';
        render();
      });
    }

    const mapBtn = container.querySelector('#view-on-map-btn');
    if (mapBtn) {
      mapBtn.addEventListener('click', () => {
        window.navigateTo?.('map');
      });
    }

    container.querySelectorAll('[data-action="advance-status"]').forEach(btn => {
      btn.addEventListener('click', () => {
        db.updateBloodRequestStatus(btn.dataset.id, btn.dataset.status);
        window.showToast?.(`Blood request updated to: ${btn.dataset.status}`, 'success');
        render();
      });
    });

    container.querySelectorAll('[data-action="call-bloodbank"]').forEach(btn => {
      btn.addEventListener('click', () => {
        window.openModal?.(`Contact ${btn.dataset.name}`, `
          <div class="space-y-3 text-slate-800">
            <p class="text-xs text-slate-600 font-medium">Direct emergency blood bank hotline desk:</p>
            <div class="p-4 bg-slate-100 rounded-2xl text-center">
              <div class="text-xs text-slate-500 font-bold uppercase">Desk Phone</div>
              <div class="text-xl font-mono font-black text-slate-900 mt-1">${btn.dataset.phone}</div>
            </div>
            <p class="text-[11px] text-amber-800 bg-amber-50 p-3 rounded-xl border border-amber-200 leading-relaxed font-medium">
              * Note: Please keep the patient ID and doctor's cross-match requisition slip ready.
            </p>
          </div>
        `, [{ label: 'Close', action: 'close', className: 'bg-slate-200 text-slate-700' }]);
      });
    });

    container.querySelectorAll('[data-action="request-facility"]').forEach(btn => {
      btn.addEventListener('click', () => {
        db.addNotification({
          title: 'Blood Bank Requisition Sent',
          message: `Requisition dispatched to ${btn.dataset.name} for ${selectedBloodGroup} blood units.`,
          type: 'emergency'
        });
        window.showToast?.(`Requisition sent to ${btn.dataset.name}!`, 'success');
      });
    });

    container.querySelectorAll('[data-action="send-donor-request"]').forEach(btn => {
      btn.addEventListener('click', () => {
        db.addNotification({
          title: 'Donation Request Dispatched',
          message: `Consent request dispatched to ${btn.dataset.name}.`,
          type: 'donor'
        });
        window.showToast?.(`Donation request sent to ${btn.dataset.name}!`, 'success');
      });
    });
  }

  // Initial render
  render();
}
