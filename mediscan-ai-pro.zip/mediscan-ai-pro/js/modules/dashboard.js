/**
 * Module 8: Patient Dashboard Command Center (High-Tech Medical Mission Control)
 * Team: The Code Burner | Maharana Pratap Institute of Technology, Gorakhpur
 */

import { db, BLOOD_COMPATIBILITY } from '../db.js';

export function renderDashboardModule(container) {
  let selectedCompatGroup = 'O+';

  function render() {
    const patient = db.getPatientProfile();
    const todayReminders = db.getRemindersForToday();
    const nextReminder = todayReminders.find(r => r.status === 'Pending') || todayReminders[0];
    const appointments = db.getAppointments();
    const bloodRequests = db.getBloodRequests();
    const adherence = db.calculateDailyAdherence();
    const latestBloodReq = bloodRequests[0];
    const bloodBanks = db.getBloodBanks();
    const totalUnitsInRegion = bloodBanks.reduce((acc, b) => {
      return acc + Object.values(b.inventory).reduce((x, y) => x + y, 0);
    }, 0);

    const compatInfo = BLOOD_COMPATIBILITY[selectedCompatGroup] || BLOOD_COMPATIBILITY['O+'];

    container.innerHTML = `
      <div class="space-y-8 animate-fade-in text-slate-100">
        
        <!-- Mission Control Header Banner -->
        <div class="glass-panel p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border border-teal-500/20">
          <div class="flex items-center gap-4">
            <div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-teal-500 via-teal-600 to-emerald-400 text-white flex items-center justify-center font-black text-xl shadow-lg shadow-teal-500/30 flex-shrink-0">
              MPIT
            </div>
            <div>
              <div class="flex items-center gap-2 flex-wrap">
                <h2 class="text-base font-extrabold text-white">Team The Code Burner</h2>
                <span class="badge-neon">Hackathon Pro Edition</span>
                <span class="badge-demo">Gorakhpur Region</span>
              </div>
              <p class="text-xs text-slate-400 mt-0.5">Maharana Pratap Institute of Technology, Gorakhpur • Mediscan AI Pro Command Center</p>
            </div>
          </div>

          <div class="flex items-center gap-3 w-full md:w-auto justify-end">
            <button id="open-demo-guide-btn" class="btn-neon-teal px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
              1-Click Evaluator Scenarios
            </button>
          </div>
        </div>

        <!-- Gorakhpur Live Telemetry Ticker (Animated Mission Stats) -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div class="glass-panel p-4 flex items-center gap-3.5 border-l-4 border-teal-500">
            <div class="w-10 h-10 rounded-xl bg-teal-500/15 text-teal-400 flex items-center justify-center font-bold text-lg flex-shrink-0">
              🩸
            </div>
            <div>
              <div class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Reported Reserves</div>
              <div class="text-xl font-black text-white">${totalUnitsInRegion} <span class="text-xs font-normal text-teal-400">PRBC Units</span></div>
              <div class="text-[10px] text-teal-400 font-semibold">Across 4 Gorakhpur Centers</div>
            </div>
          </div>

          <div class="glass-panel p-4 flex items-center gap-3.5 border-l-4 border-crimson-accent">
            <div class="w-10 h-10 rounded-xl bg-red-500/15 text-red-400 flex items-center justify-center font-bold text-lg flex-shrink-0">
              🚨
            </div>
            <div>
              <div class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Active SOS Requests</div>
              <div class="text-xl font-black text-red-400">${bloodRequests.length} <span class="text-xs font-normal text-slate-400">Broadcasting</span></div>
              <div class="text-[10px] text-slate-400 font-semibold">Live matching pipeline</div>
            </div>
          </div>

          <div class="glass-panel p-4 flex items-center gap-3.5 border-l-4 border-amber-500">
            <div class="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center font-bold text-lg flex-shrink-0">
              ❤️
            </div>
            <div>
              <div class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Consented Donors</div>
              <div class="text-xl font-black text-white">24 <span class="text-xs font-normal text-amber-400">Volunteers</span></div>
              <div class="text-[10px] text-slate-400 font-semibold">Ready in Gorakhpur</div>
            </div>
          </div>

          <div class="glass-panel p-4 flex items-center gap-3.5 border-l-4 border-emerald-500">
            <div class="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center font-bold text-lg flex-shrink-0">
              ⚡
            </div>
            <div>
              <div class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Avg Response Time</div>
              <div class="text-xl font-black text-emerald-400">3.8 <span class="text-xs font-normal text-slate-400">Mins</span></div>
              <div class="text-[10px] text-slate-400 font-semibold">Rapid Emergency Dispatch</div>
            </div>
          </div>
        </div>

        <!-- High-Impact Hero Command Section -->
        <div class="gradient-border-card">
          <div class="p-8 md:p-10 relative overflow-hidden">
            <!-- Background glow radial effects -->
            <div class="absolute -right-20 -top-20 w-96 h-96 bg-teal-500/20 rounded-full blur-3xl pointer-events-none"></div>
            <div class="absolute -left-20 -bottom-20 w-80 h-80 bg-red-600/15 rounded-full blur-3xl pointer-events-none"></div>

            <div class="relative z-10 max-w-3xl space-y-4">
              <div class="flex items-center gap-3 flex-wrap">
                <span class="badge-neon">
                  <span class="w-2 h-2 rounded-full bg-teal-400 animate-ping"></span>
                  AI Emergency Coordination Hub
                </span>
                <span class="text-xs font-mono text-slate-400">Patient ABHA: <strong class="text-teal-300 font-bold">${patient.abhaId}</strong></span>
              </div>

              <h1 class="text-3xl md:text-5xl font-black tracking-tight text-white leading-tight">
                Welcome, <span class="bg-gradient-to-r from-teal-400 via-emerald-300 to-white bg-clip-text text-transparent">${patient.fullName}</span>
              </h1>

              <p class="text-slate-300 text-sm md:text-base leading-relaxed max-w-2xl font-normal">
                Command center is synchronized with Gorakhpur blood centers (BRD Medical College, AIIMS, District Hospital) and local specialists.
              </p>

              <!-- Action Bar with high visibility -->
              <div class="flex flex-wrap gap-3.5 pt-2">
                <button id="hero-find-blood-btn" class="btn-neon-crimson px-6 py-3.5 rounded-2xl text-xs font-black flex items-center gap-2.5 animate-pulse-aura">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>
                  <span>EMERGENCY: FIND BLOOD NOW</span>
                </button>

                <button id="hero-schedule-rx-btn" class="btn-neon-teal px-6 py-3.5 rounded-2xl text-xs font-bold flex items-center gap-2">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                  Today's Medication Timetable
                </button>

                <button id="hero-view-passport-btn" class="px-5 py-3.5 bg-slate-800/80 hover:bg-slate-700/80 text-white border border-slate-700 rounded-2xl text-xs font-bold flex items-center gap-2 transition-all">
                  <svg class="w-4 h-4 text-teal-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                  Medical Health Passport & Vault
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Interactive Blood Compatibility Interactive Radar Bar -->
        <div class="glass-panel p-6 space-y-4">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-3">
            <div>
              <h3 class="text-sm font-extrabold text-white flex items-center gap-2">
                <span class="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span>
                Interactive ABO/Rh Clinical Compatibility Wheel
              </h3>
              <p class="text-xs text-slate-400">Click any blood group to test live donor/recipient compatibility rules.</p>
            </div>
            <span class="badge-neon text-[10px]">Instant Rule Visualizer</span>
          </div>

          <!-- Blood Group Clickable Buttons -->
          <div class="flex flex-wrap items-center gap-2">
            <span class="text-xs text-slate-400 font-bold mr-2">Select Blood Group:</span>
            ${['O+', 'O-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-'].map(bg => `
              <button 
                data-compat-btn="${bg}" 
                class="px-3.5 py-1.5 rounded-xl font-black text-xs transition-all ${
                  selectedCompatGroup === bg 
                    ? 'btn-neon-crimson scale-105' 
                    : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700'
                }"
              >
                ${bg}
              </button>
            `).join('')}
          </div>

          <!-- Dynamic Compatibility Result Panel -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div class="p-4 rounded-2xl bg-teal-500/10 border border-teal-500/30 space-y-2">
              <div class="text-xs font-extrabold text-teal-400 flex items-center gap-1.5">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"/></svg>
                Can Receive From (Safe Donors for ${selectedCompatGroup}):
              </div>
              <div class="flex flex-wrap gap-1.5">
                ${compatInfo.canReceiveFrom.map(g => `
                  <span class="px-2.5 py-1 rounded-lg bg-teal-500/20 text-teal-300 font-black text-xs border border-teal-500/40">${g}</span>
                `).join('')}
              </div>
              <div class="text-[11px] text-slate-400 font-medium pt-1">
                ${selectedCompatGroup === 'AB+' ? '🌟 Universal Recipient: Can receive blood from all blood groups!' : 'Only receive matched or universal donor units.'}
              </div>
            </div>

            <div class="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 space-y-2">
              <div class="text-xs font-extrabold text-red-400 flex items-center gap-1.5">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 10l7-7m0 0l7 7m-7-7v18"/></svg>
                Can Donate To (Recipients ${selectedCompatGroup} can save):
              </div>
              <div class="flex flex-wrap gap-1.5">
                ${compatInfo.canDonateTo.map(g => `
                  <span class="px-2.5 py-1 rounded-lg bg-red-500/20 text-red-300 font-black text-xs border border-red-500/40">${g}</span>
                `).join('')}
              </div>
              <div class="text-[11px] text-slate-400 font-medium pt-1">
                ${selectedCompatGroup === 'O-' ? '🌟 Universal Donor: Can donate blood to all blood groups in emergency!' : 'Compatible with matching Rh factors.'}
              </div>
            </div>
          </div>
        </div>

        <!-- 9 Core Responsive Mission Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

          <!-- Card 1: My Blood Group -->
          <div class="glass-panel p-6 flex flex-col justify-between group">
            <div>
              <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-black uppercase tracking-wider text-slate-400">1. Verified Blood ID</span>
                <span class="badge-neon">Rh+ Confirmed</span>
              </div>

              <div class="flex items-center gap-4 my-3">
                <div class="w-16 h-16 rounded-2xl bg-gradient-to-tr from-red-600 to-rose-700 text-white font-black text-3xl flex items-center justify-center shadow-lg shadow-red-600/30 group-hover:scale-105 transition-transform flex-shrink-0">
                  ${patient.bloodGroup}
                </div>
                <div>
                  <div class="text-lg font-black text-white">O-Positive</div>
                  <div class="text-xs text-slate-400 font-medium">Safe Recipient: <strong class="text-teal-400">O+, O-</strong></div>
                  <div class="text-[11px] text-emerald-400 font-bold mt-1">Can donate to: O+, A+, B+, AB+</div>
                </div>
              </div>
            </div>

            <div class="pt-4 border-t border-white/5 flex items-center justify-between">
              <span class="text-[11px] text-slate-400">ABO Clinical Rule</span>
              <button onclick="window.navigateTo('bloodFinder')" class="text-xs font-black text-red-400 hover:text-red-300 flex items-center gap-1 group-hover:translate-x-1 transition-all">
                Match Donors ➔
              </button>
            </div>
          </div>

          <!-- Card 2: Find Blood Now (Emergency Card with Radiant Pulse) -->
          <div class="p-6 rounded-3xl bg-gradient-to-br from-red-600 via-rose-700 to-red-900 border border-red-500/40 shadow-2xl flex flex-col justify-between relative overflow-hidden group">
            <div class="absolute -right-10 -bottom-10 w-40 h-40 bg-white/10 rounded-full blur-2xl pointer-events-none group-hover:scale-125 transition-transform"></div>
            
            <div>
              <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-black uppercase tracking-wider text-red-200">2. Emergency Dispatch</span>
                <span class="px-2.5 py-0.5 bg-white/20 rounded-full text-[10px] font-black backdrop-blur">24x7 SOS</span>
              </div>
              <h3 class="text-xl font-black mb-1 flex items-center gap-2 text-white">
                <span>Find Blood Now</span>
                <span class="w-2.5 h-2.5 rounded-full bg-white animate-ping"></span>
              </h3>
              <p class="text-xs text-red-100 leading-relaxed mb-4 font-medium">
                Broadcast emergency requisitions across BRD Medical College, AIIMS, District Hospital & verified donors.
              </p>
            </div>

            <button onclick="window.navigateTo('bloodFinder')" class="w-full py-3 bg-white text-red-700 hover:bg-red-50 rounded-2xl text-xs font-black shadow-lg transition-all flex items-center justify-center gap-2 group-hover:scale-[1.02]">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>
              Broadcast Blood Requisition
            </button>
          </div>

          <!-- Card 3: Register as Blood Donor -->
          <div class="glass-panel p-6 flex flex-col justify-between group">
            <div>
              <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-black uppercase tracking-wider text-slate-400">3. Life-Saving Network</span>
                <span class="badge-demo">Gorakhpur</span>
              </div>

              <div class="flex items-center gap-3.5 my-2">
                <div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 text-white flex items-center justify-center font-bold text-2xl shadow-lg shadow-orange-500/20 group-hover:scale-105 transition-transform flex-shrink-0">
                  ❤️
                </div>
                <div>
                  <h4 class="text-sm font-black text-white">Register as Blood Donor</h4>
                  <p class="text-xs text-slate-400 leading-relaxed mt-0.5 font-medium">Volunteer in Gorakhpur. Your phone number is strictly shielded with consent-based requests.</p>
                </div>
              </div>
            </div>

            <div class="pt-4 border-t border-white/5 flex items-center justify-between">
              <span class="text-[11px] text-slate-400">Privacy Shielded</span>
              <button onclick="window.navigateTo('donorNetwork')" class="text-xs font-black text-amber-400 hover:text-amber-300 flex items-center gap-1 group-hover:translate-x-1 transition-all">
                Register Today ➔
              </button>
            </div>
          </div>

          <!-- Card 4: My Medical Passport -->
          <div class="glass-panel p-6 flex flex-col justify-between group">
            <div>
              <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-black uppercase tracking-wider text-slate-400">4. Health ID Vault</span>
                <span class="badge-neon">EHR Synced</span>
              </div>

              <h4 class="text-sm font-black text-white mb-1">My Medical Passport</h4>
              
              <div class="text-xs text-slate-300 space-y-1.5 my-2.5 bg-slate-900/80 p-3.5 rounded-2xl border border-white/5">
                <div class="flex justify-between">
                  <span class="text-slate-400">Critical Allergies:</span>
                  <strong class="text-amber-400 font-bold">${patient.allergies.join(', ')}</strong>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Conditions:</span>
                  <strong class="text-slate-200 font-bold">${patient.chronicConditions.join(', ')}</strong>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Emergency Contact:</span>
                  <strong class="text-teal-400 font-bold">${patient.emergencyContacts[0].name}</strong>
                </div>
              </div>
            </div>

            <div class="pt-4 border-t border-white/5 flex items-center justify-between">
              <span class="text-[11px] text-slate-400">Paramedic QR Badge</span>
              <button onclick="window.navigateTo('passport')" class="text-xs font-black text-teal-400 hover:text-teal-300 flex items-center gap-1 group-hover:translate-x-1 transition-all">
                Open Vault ➔
              </button>
            </div>
          </div>

          <!-- Card 5: Today's Medicine Reminders -->
          <div class="glass-panel p-6 flex flex-col justify-between group">
            <div>
              <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-black uppercase tracking-wider text-slate-400">5. Medication Adherence</span>
                <span class="px-2.5 py-0.5 rounded-full text-xs font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  ${adherence}% Adherence
                </span>
              </div>

              <h4 class="text-sm font-black text-white mb-1">Today's Reminders</h4>

              ${nextReminder ? `
                <div class="p-3.5 bg-teal-500/10 border border-teal-500/30 rounded-2xl my-2 text-xs">
                  <div class="flex items-center justify-between mb-1">
                    <span class="font-black text-teal-300">⏰ ${nextReminder.timeSlot}</span>
                    <span class="status-pill status-${nextReminder.status.toLowerCase()} text-[10px]">${nextReminder.status}</span>
                  </div>
                  <div class="text-white font-bold text-xs">${nextReminder.medicineName}</div>
                </div>
              ` : `
                <div class="text-xs text-slate-400 py-3">All scheduled doses recorded!</div>
              `}
            </div>

            <div class="pt-4 border-t border-white/5 flex items-center justify-between">
              ${nextReminder && nextReminder.status === 'Pending' ? `
                <button data-action="quick-take" data-id="${nextReminder.id}" class="btn-neon-teal px-3.5 py-1.5 rounded-xl text-xs font-black flex items-center gap-1">
                  ✓ Mark Taken
                </button>
              ` : `
                <span class="text-[11px] text-slate-400">Schedule up to date</span>
              `}
              <button onclick="window.navigateTo('prescriptions')" class="text-xs font-black text-teal-400 hover:text-teal-300 flex items-center gap-1 group-hover:translate-x-1 transition-all">
                Full Schedule ➔
              </button>
            </div>
          </div>

          <!-- Card 6: Upcoming Appointment Requests -->
          <div class="glass-panel p-6 flex flex-col justify-between group">
            <div>
              <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-black uppercase tracking-wider text-slate-400">6. Doctor Appointments</span>
                <span class="text-xs font-bold text-slate-300 bg-slate-800 px-2.5 py-0.5 rounded-full">${appointments.length} Booked</span>
              </div>

              <h4 class="text-sm font-black text-white mb-1">Consultation Requests</h4>
              
              ${appointments.length > 0 ? `
                <div class="p-3.5 bg-slate-900/80 border border-white/5 rounded-2xl my-2 text-xs space-y-1">
                  <div class="flex items-center justify-between">
                    <strong class="text-white font-black">${appointments[0].doctorName}</strong>
                    <span class="status-pill status-${appointments[0].status.toLowerCase()} text-[10px]">${appointments[0].status}</span>
                  </div>
                  <div class="text-slate-400 font-medium">${appointments[0].specialty}</div>
                  <div class="text-[11px] text-teal-400 font-bold">🗓️ ${appointments[0].preferredDate} • ${appointments[0].preferredTime}</div>
                </div>
              ` : `
                <p class="text-xs text-slate-400 py-3">No active appointments requested yet.</p>
              `}
            </div>

            <div class="pt-4 border-t border-white/5 flex items-center justify-between">
              <span class="text-[11px] text-slate-400">Booking Status</span>
              <button onclick="window.navigateTo('specialists')" class="text-xs font-black text-teal-400 hover:text-teal-300 flex items-center gap-1 group-hover:translate-x-1 transition-all">
                Book Specialist ➔
              </button>
            </div>
          </div>

          <!-- Card 7: Recommended Specialists -->
          <div class="glass-panel p-6 flex flex-col justify-between group">
            <div>
              <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-black uppercase tracking-wider text-slate-400">7. Featured Doctors</span>
                <span class="badge-demo">Gorakhpur</span>
              </div>

              <h4 class="text-sm font-black text-white mb-2">Verified Specialists</h4>
              
              <div class="space-y-2 text-xs">
                <div class="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/60 hover:bg-slate-800/80 border border-white/5 cursor-pointer transition-colors" onclick="window.navigateTo('specialists')">
                  <div>
                    <span class="font-bold text-white block">Dr. Naveen Verma</span>
                    <span class="text-[10px] text-teal-400">Dermatology / Skin Care</span>
                  </div>
                  <span class="text-amber-400 text-xs font-black">⭐ 4.9</span>
                </div>
                <div class="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/60 hover:bg-slate-800/80 border border-white/5 cursor-pointer transition-colors" onclick="window.navigateTo('specialists')">
                  <div>
                    <span class="font-bold text-white block">Raj Eye Hospital</span>
                    <span class="text-[10px] text-teal-400">Eye Care / Ophthalmology</span>
                  </div>
                  <span class="text-amber-400 text-xs font-black">⭐ 4.8</span>
                </div>
                <div class="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/60 hover:bg-slate-800/80 border border-white/5 cursor-pointer transition-colors" onclick="window.navigateTo('specialists')">
                  <div>
                    <span class="font-bold text-white block">Dr. Aggarwal</span>
                    <span class="text-[10px] text-teal-400">Orthopedic / Bone Care (Buxipur)</span>
                  </div>
                  <span class="text-amber-400 text-xs font-black">⭐ 4.9</span>
                </div>
              </div>
            </div>

            <div class="pt-4 border-t border-white/5 flex items-center justify-between">
              <span class="text-[11px] text-slate-400">All 7 Specialties</span>
              <button onclick="window.navigateTo('specialists')" class="text-xs font-black text-teal-400 hover:text-teal-300 flex items-center gap-1 group-hover:translate-x-1 transition-all">
                Directory ➔
              </button>
            </div>
          </div>

          <!-- Card 8: Recent Blood Requests -->
          <div class="glass-panel p-6 flex flex-col justify-between group">
            <div>
              <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-black uppercase tracking-wider text-slate-400">8. Live Emergency Radar</span>
                <span class="badge-emergency">Active</span>
              </div>

              <h4 class="text-sm font-black text-white mb-1">Recent Blood Requisitions</h4>
              
              ${latestBloodReq ? `
                <div class="p-3.5 bg-red-500/10 border border-red-500/30 rounded-2xl my-2 text-xs space-y-1">
                  <div class="flex items-center justify-between">
                    <span class="font-black text-red-400 text-sm">${latestBloodReq.requiredBloodGroup} (${latestBloodReq.unitsRequired} Units)</span>
                    <span class="status-pill status-${latestBloodReq.status.toLowerCase().replace(/\s+/g, '-')} text-[10px]">${latestBloodReq.status}</span>
                  </div>
                  <div class="text-white font-bold">${latestBloodReq.patientName}</div>
                  <div class="text-[11px] text-slate-400 truncate">${latestBloodReq.hospitalName}</div>
                </div>
              ` : `
                <p class="text-xs text-slate-400 py-3">No active emergency blood requests.</p>
              `}
            </div>

            <div class="pt-4 border-t border-white/5 flex items-center justify-between">
              <span class="text-[11px] text-slate-400">Hospital Cross-match</span>
              <button onclick="window.navigateTo('bloodFinder')" class="text-xs font-black text-red-400 hover:text-red-300 flex items-center gap-1 group-hover:translate-x-1 transition-all">
                Trace Pipeline ➔
              </button>
            </div>
          </div>

          <!-- Card 9: Emergency Assistance Hotlines -->
          <div class="glass-panel p-6 flex flex-col justify-between group">
            <div>
              <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-black uppercase tracking-wider text-slate-400">9. Emergency Desk</span>
                <span class="px-2.5 py-0.5 rounded-full text-xs font-black bg-red-500/20 text-red-300 border border-red-500/40">24x7 Helpline</span>
              </div>

              <h4 class="text-sm font-black text-white mb-2">Emergency Hotlines</h4>
              
              <div class="grid grid-cols-2 gap-2.5 text-xs">
                <a href="tel:108" class="p-3 bg-red-500/15 hover:bg-red-500/25 border border-red-500/40 rounded-2xl text-center transition-all hover:scale-105">
                  <div class="text-[10px] text-red-300 font-bold uppercase">Ambulance</div>
                  <strong class="text-lg font-black text-white">108</strong>
                </a>
                <a href="tel:102" class="p-3 bg-red-500/15 hover:bg-red-500/25 border border-red-500/40 rounded-2xl text-center transition-all hover:scale-105">
                  <div class="text-[10px] text-red-300 font-bold uppercase">Maternal/Child</div>
                  <strong class="text-lg font-black text-white">102</strong>
                </a>
                <a href="tel:112" class="p-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-2xl text-center transition-all hover:scale-105">
                  <div class="text-[10px] text-slate-400 font-bold uppercase">Police / SOS</div>
                  <strong class="text-lg font-black text-white">112</strong>
                </a>
                <a href="tel:104" class="p-3 bg-teal-500/15 hover:bg-teal-500/25 border border-teal-500/40 rounded-2xl text-center transition-all hover:scale-105">
                  <div class="text-[10px] text-teal-300 font-bold uppercase">Blood Helpline</div>
                  <strong class="text-lg font-black text-white">104</strong>
                </a>
              </div>
            </div>

            <div class="pt-4 border-t border-white/5 text-center">
              <span class="text-[10px] text-slate-400 font-medium">Gorakhpur District Emergency Response Desk</span>
            </div>
          </div>

        </div>

      </div>
    `;

    attachEvents();
  }

  function attachEvents() {
    const findBloodBtn = container.querySelector('#hero-find-blood-btn');
    if (findBloodBtn) findBloodBtn.addEventListener('click', () => window.navigateTo?.('bloodFinder'));

    const viewPassportBtn = container.querySelector('#hero-view-passport-btn');
    if (viewPassportBtn) viewPassportBtn.addEventListener('click', () => window.navigateTo?.('passport'));

    const scheduleRxBtn = container.querySelector('#hero-schedule-rx-btn');
    if (scheduleRxBtn) scheduleRxBtn.addEventListener('click', () => window.navigateTo?.('prescriptions'));

    const guideBtn = container.querySelector('#open-demo-guide-btn');
    if (guideBtn) guideBtn.addEventListener('click', () => window.openDemoModal?.());

    // Compatibility group buttons
    container.querySelectorAll('[data-compat-btn]').forEach(btn => {
      btn.addEventListener('click', () => {
        selectedCompatGroup = btn.dataset.compatBtn;
        render();
      });
    });

    // Quick take button
    container.querySelectorAll('[data-action="quick-take"]').forEach(btn => {
      btn.addEventListener('click', () => {
        db.updateReminderStatus(btn.dataset.id, 'Taken');
        window.showToast?.('Medicine marked as Taken! Adherence score updated to 100%.', 'success');
        render();
      });
    });
  }

  // Initial render
  render();
}
