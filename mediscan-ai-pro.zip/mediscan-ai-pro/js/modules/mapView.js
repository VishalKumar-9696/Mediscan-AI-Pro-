/**
 * Module 6: Interactive Blood Finder Map (Leaflet & OpenStreetMap)
 * Team: The Code Burner | Maharana Pratap Institute of Technology, Gorakhpur
 */

import { db, calculateDistance } from '../db.js';

export function renderMapViewModule(container) {
  let mapInstance = null;
  let markersLayer = null;
  let radiusCircle = null;

  let selectedResourceType = 'All'; // 'All' | 'BloodBank' | 'Hospital' | 'Donor'
  let selectedBloodGroup = 'All';
  let searchRadiusKm = 10; // 1km to 30km

  // User reference coordinates in Gorakhpur
  const userCoords = { lat: 26.7588, lng: 83.3697, name: 'Current User Location (Golghar, Gorakhpur)' };

  function render() {
    container.innerHTML = `
      <div class="space-y-6 animate-fade-in">
        <!-- Page Header -->
        <div class="bg-gradient-to-r from-slate-900 via-slate-800 to-teal-950 p-6 md:p-8 rounded-2xl text-white shadow-elevated border border-slate-700/60 relative overflow-hidden">
          <div class="absolute -right-10 -bottom-10 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <div class="max-w-3xl">
            <div class="flex items-center gap-3 mb-3">
              <span class="bg-teal-500/20 text-teal-300 border border-teal-500/30 text-xs font-semibold px-3 py-1 rounded-full flex items-center gap-1.5">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/></svg>
                Leaflet & OpenStreetMap Engine
              </span>
              <span class="badge-demo">Simulated Demo Coordinates</span>
            </div>
            <h1 class="text-2xl md:text-3xl font-bold tracking-tight text-white mb-2">
              Interactive Blood & Hospital Geo-Radar
            </h1>
            <p class="text-slate-300 text-sm md:text-base leading-relaxed">
              Spatial visualizer mapping Gorakhpur blood banks, trauma hospitals, and voluntary donors with dynamic search radius filtering and instant requisition triggers.
            </p>
          </div>
        </div>

        <!-- Filter Control Bar -->
        <div class="premium-card p-6 space-y-4">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-5 items-center">
            <!-- Resource Type Filter -->
            <div>
              <label class="block text-[10px] font-extrabold uppercase tracking-wider text-slate-400 mb-1.5">Resource Filter</label>
              <select id="map-resource-type" class="w-full text-xs p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-bold">
                <option value="All" ${selectedResourceType === 'All' ? 'selected' : ''}>All Facilities & Donors</option>
                <option value="BloodBank" ${selectedResourceType === 'BloodBank' ? 'selected' : ''}>Blood Banks Only</option>
                <option value="Hospital" ${selectedResourceType === 'Hospital' ? 'selected' : ''}>Hospitals & Clinics</option>
                <option value="Donor" ${selectedResourceType === 'Donor' ? 'selected' : ''}>Consented Donors</option>
              </select>
            </div>

            <!-- Blood Group Filter -->
            <div>
              <label class="block text-[10px] font-extrabold uppercase tracking-wider text-slate-400 mb-1.5">Blood Group Match</label>
              <select id="map-blood-group" class="w-full text-xs p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-black text-red-600">
                <option value="All" ${selectedBloodGroup === 'All' ? 'selected' : ''}>All Blood Groups</option>
                <option value="O+" ${selectedBloodGroup === 'O+' ? 'selected' : ''}>O+ (Positive)</option>
                <option value="O-" ${selectedBloodGroup === 'O-' ? 'selected' : ''}>O- (Universal Donor)</option>
                <option value="A+" ${selectedBloodGroup === 'A+' ? 'selected' : ''}>A+ (Positive)</option>
                <option value="A-" ${selectedBloodGroup === 'A-' ? 'selected' : ''}>A- (Negative)</option>
                <option value="B+" ${selectedBloodGroup === 'B+' ? 'selected' : ''}>B+ (Positive)</option>
                <option value="B-" ${selectedBloodGroup === 'B-' ? 'selected' : ''}>B- (Negative)</option>
                <option value="AB+" ${selectedBloodGroup === 'AB+' ? 'selected' : ''}>AB+ (Positive)</option>
                <option value="AB-" ${selectedBloodGroup === 'AB-' ? 'selected' : ''}>AB- (Negative)</option>
              </select>
            </div>

            <!-- Search Radius Slider -->
            <div class="md:col-span-2">
              <div class="flex items-center justify-between text-xs mb-1.5">
                <span class="font-extrabold text-slate-800">Geographic Radar Radius:</span>
                <span class="font-mono font-black text-teal-700 bg-teal-50 px-2.5 py-0.5 rounded-full border border-teal-200" id="radius-val-label">${searchRadiusKm} km</span>
              </div>
              <input 
                type="range" 
                id="map-radius-slider" 
                min="1" 
                max="30" 
                step="1" 
                value="${searchRadiusKm}" 
                class="w-full accent-teal-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
              />
              <div class="flex justify-between text-[10px] text-slate-400 font-semibold mt-1">
                <span>1 km (Local Neighborhood)</span>
                <span>15 km (Gorakhpur City Core)</span>
                <span>30 km (District Perimeter)</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Leaflet Map Container & Legend -->
        <div class="relative bg-white rounded-3xl border border-slate-200/80 shadow-lg overflow-hidden p-2.5">
          <!-- Floating Legend -->
          <div class="absolute top-6 right-6 z-20 bg-white/95 backdrop-blur-md shadow-2xl border border-slate-200/90 rounded-2xl p-4 text-xs space-y-2 max-w-xs">
            <div class="font-black text-slate-900 text-[11px] uppercase tracking-wider mb-1">Radar Geo-Legend</div>
            <div class="flex items-center gap-2.5">
              <span class="w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white shadow-sm"></span>
              <span class="text-slate-700 font-semibold">Patient SOS Epicenter</span>
            </div>
            <div class="flex items-center gap-2.5">
              <span class="w-3.5 h-3.5 rounded-full bg-red-600 border-2 border-white shadow-sm"></span>
              <span class="text-slate-700 font-semibold">Regional Blood Banks</span>
            </div>
            <div class="flex items-center gap-2.5">
              <span class="w-3.5 h-3.5 rounded-full bg-blue-600 border-2 border-white shadow-sm"></span>
              <span class="text-slate-700 font-semibold">Hospitals & Trauma Wings</span>
            </div>
            <div class="flex items-center gap-2.5">
              <span class="w-3.5 h-3.5 rounded-full bg-orange-500 border-2 border-white shadow-sm"></span>
              <span class="text-slate-700 font-semibold">Consented Donors (Approx Area)</span>
            </div>
          </div>
              <span class="w-3 h-3 rounded-full bg-blue-600 border border-white"></span>
              <span class="text-slate-600">Hospitals & Clinics</span>
            </div>
            <div class="flex items-center gap-2">
              <span class="w-3 h-3 rounded-full bg-orange-500 border border-white"></span>
              <span class="text-slate-600">Donors (Approx. Locality)</span>
            </div>
          </div>

          <!-- Map DOM Node -->
          <div id="leaflet-map-element" style="height: 540px; width: 100%; border-radius: 0.75rem;"></div>
        </div>

        <!-- Safe Simulation Disclosure -->
        <div class="text-xs text-slate-400 text-center italic">
          * Notice: Geographic positions are calibrated based on Gorakhpur landmarks (BRD Medical College, AIIMS Gorakhpur, Golghar, Mohaddipur). Donor pins reflect approximate locality centers to safeguard privacy.
        </div>
      </div>
    `;

    setTimeout(initMap, 50);
    attachControls();
  }

  function initMap() {
    const mapDom = document.getElementById('leaflet-map-element');
    if (!mapDom) return;

    // Destroy previous instance if any
    if (mapInstance) {
      mapInstance.remove();
      mapInstance = null;
    }

    if (typeof L === 'undefined') {
      console.error('Leaflet library is not loaded');
      mapDom.innerHTML = `<div class="p-8 text-center text-red-500">Leaflet library is loading. Please check internet connection or reload page.</div>`;
      return;
    }

    // Centered on Gorakhpur
    mapInstance = L.map('leaflet-map-element').setView([userCoords.lat, userCoords.lng], 13);

    // OpenStreetMap standard tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap contributors | Mediscan AI Pro'
    }).addTo(mapInstance);

    markersLayer = L.layerGroup().addTo(mapInstance);

    renderMarkersAndRadius();
  }

  function renderMarkersAndRadius() {
    if (!mapInstance || !markersLayer) return;

    markersLayer.clearLayers();

    // 1. Draw User Location Marker
    const userMarkerHtml = `
      <div class="custom-leaflet-marker marker-user" style="width: 32px; height: 32px; font-size: 14px;">
        📍
      </div>
    `;
    const userIcon = L.divIcon({
      html: userMarkerHtml,
      className: '',
      iconSize: [32, 32],
      iconAnchor: [16, 16]
    });

    L.marker([userCoords.lat, userCoords.lng], { icon: userIcon })
      .addTo(markersLayer)
      .bindPopup(`
        <div class="p-2 text-xs">
          <strong class="text-teal-700 block text-sm">📍 ${userCoords.name}</strong>
          <span class="text-slate-500">Emergency search epicenter</span>
        </div>
      `);

    // 2. Draw Radius Circle
    if (radiusCircle) {
      mapInstance.removeLayer(radiusCircle);
    }
    radiusCircle = L.circle([userCoords.lat, userCoords.lng], {
      color: '#0d9488',
      fillColor: '#0d9488',
      fillOpacity: 0.1,
      radius: searchRadiusKm * 1000
    }).addTo(mapInstance);

    // 3. Add Blood Banks
    if (selectedResourceType === 'All' || selectedResourceType === 'BloodBank') {
      const bloodBanks = db.getBloodBanks();
      bloodBanks.forEach(bank => {
        const dist = calculateDistance(userCoords.lat, userCoords.lng, bank.coordinates.lat, bank.coordinates.lng);
        if (dist <= searchRadiusKm) {
          const bankIcon = L.divIcon({
            html: `<div class="custom-leaflet-marker marker-bloodbank" style="width: 30px; height: 30px; font-size: 12px;">🩸</div>`,
            className: '',
            iconSize: [30, 30],
            iconAnchor: [15, 15]
          });

          const countForSelected = selectedBloodGroup === 'All' 
            ? Object.values(bank.inventory).reduce((a, b) => a + b, 0)
            : (bank.inventory[selectedBloodGroup] || 0);

          L.marker([bank.coordinates.lat, bank.coordinates.lng], { icon: bankIcon })
            .addTo(markersLayer)
            .bindPopup(`
              <div class="p-2 text-xs space-y-1.5" style="min-width: 200px;">
                <div class="font-bold text-slate-900 text-sm">${bank.name}</div>
                <div class="text-[11px] text-slate-500">${bank.facilityType}</div>
                <div class="text-slate-700">📍 ~${dist} km from user</div>
                <div class="p-1.5 bg-red-50 border border-red-200 rounded font-bold text-red-800">
                  Reported Units (${selectedBloodGroup}): ${countForSelected}
                </div>
                <div class="text-[10px] text-slate-400">⏱️ Updated: Today</div>
                <button onclick="window.showToast('Requisition dispatched to ${bank.name}!', 'success')" class="w-full mt-1 py-1 bg-red-600 text-white rounded text-[11px] font-bold">
                  Requisition Blood
                </button>
              </div>
            `);
        }
      });
    }

    // 4. Add Hospitals & Clinics
    if (selectedResourceType === 'All' || selectedResourceType === 'Hospital') {
      const doctors = db.getDoctors();
      doctors.forEach(doc => {
        const dist = calculateDistance(userCoords.lat, userCoords.lng, doc.coordinates.lat, doc.coordinates.lng);
        if (dist <= searchRadiusKm) {
          const hospIcon = L.divIcon({
            html: `<div class="custom-leaflet-marker marker-hospital" style="width: 28px; height: 28px; font-size: 12px;">🏥</div>`,
            className: '',
            iconSize: [28, 28],
            iconAnchor: [14, 14]
          });

          L.marker([doc.coordinates.lat, doc.coordinates.lng], { icon: hospIcon })
            .addTo(markersLayer)
            .bindPopup(`
              <div class="p-2 text-xs space-y-1.5" style="min-width: 190px;">
                <div class="font-bold text-slate-900">${doc.name}</div>
                <div class="text-blue-600 font-semibold text-[11px]">${doc.specialty}</div>
                <div class="text-slate-500">${doc.location} (~${dist} km)</div>
                <span class="badge-demo text-[10px]">${doc.badge}</span>
                <button onclick="window.navigateTo('specialists')" class="w-full mt-1 py-1 bg-teal-600 text-white rounded text-[11px] font-bold">
                  View Specialist Profile
                </button>
              </div>
            `);
        }
      });
    }

    // 5. Add Donors
    if (selectedResourceType === 'All' || selectedResourceType === 'Donor') {
      const donors = db.getDonors();
      donors.forEach(donor => {
        if (selectedBloodGroup !== 'All' && donor.bloodGroup !== selectedBloodGroup) return;

        const dist = calculateDistance(userCoords.lat, userCoords.lng, donor.coordinates.lat, donor.coordinates.lng);
        if (dist <= searchRadiusKm) {
          const donorIcon = L.divIcon({
            html: `<div class="custom-leaflet-marker marker-donor" style="width: 26px; height: 26px; font-size: 11px;">❤️</div>`,
            className: '',
            iconSize: [26, 26],
            iconAnchor: [13, 13]
          });

          L.marker([donor.coordinates.lat, donor.coordinates.lng], { icon: donorIcon })
            .addTo(markersLayer)
            .bindPopup(`
              <div class="p-2 text-xs space-y-1" style="min-width: 180px;">
                <div class="font-bold text-slate-900">${donor.displayName}</div>
                <div class="text-red-700 font-black text-xs">Blood Group: ${donor.bloodGroup}</div>
                <div class="text-slate-500">📍 ${donor.locality} (~${dist} km)</div>
                <div class="text-[10px] text-emerald-600 font-semibold">Status: ${donor.availabilityStatus}</div>
                <button onclick="window.showToast('Donation request sent to ${donor.displayName}!', 'success')" class="w-full mt-1 py-1 bg-orange-600 text-white rounded text-[11px] font-bold">
                  Request Donor Contact
                </button>
              </div>
            `);
        }
      });
    }
  }

  function attachControls() {
    const resType = container.querySelector('#map-resource-type');
    if (resType) {
      resType.addEventListener('change', (e) => {
        selectedResourceType = e.target.value;
        renderMarkersAndRadius();
      });
    }

    const bgSelect = container.querySelector('#map-blood-group');
    if (bgSelect) {
      bgSelect.addEventListener('change', (e) => {
        selectedBloodGroup = e.target.value;
        renderMarkersAndRadius();
      });
    }

    const slider = container.querySelector('#map-radius-slider');
    const label = container.querySelector('#radius-val-label');
    if (slider && label) {
      slider.addEventListener('input', (e) => {
        searchRadiusKm = parseInt(e.target.value);
        label.textContent = `${searchRadiusKm} km`;
        renderMarkersAndRadius();
      });
    }
  }

  // Initial render
  render();
}
