/**
 * Module 2: Prescription Organizer & Medicine Reminder
 * Team: The Code Burner | Maharana Pratap Institute of Technology, Gorakhpur
 */

import { db } from '../db.js';

export function renderPrescriptionsModule(container) {
  let uploadedFile = null;
  let ocrDraftText = '';
  let activeTab = 'schedule'; // 'schedule' | 'upload' | 'medicines' | 'history'

  function render() {
    const prescriptions = db.getPrescriptions();
    const medicines = db.getMedicines();
    const todayReminders = db.getRemindersForToday();
    const adherence = db.calculateDailyAdherence();

    container.innerHTML = `
      <div class="space-y-8 animate-fade-in">
        <!-- Page Header -->
        <div class="bg-gradient-to-r from-slate-900 via-slate-800 to-teal-950 p-6 md:p-8 rounded-2xl text-white shadow-elevated border border-slate-700/60 relative overflow-hidden">
          <div class="absolute -right-10 -bottom-10 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <div class="max-w-3xl">
            <div class="flex items-center gap-3 mb-3">
              <span class="bg-teal-500/20 text-teal-300 border border-teal-500/30 text-xs font-semibold px-3 py-1 rounded-full flex items-center gap-1.5">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
                Rx Vault & Adherence Tracker
              </span>
              <span class="badge-verified">Active Passport Sync</span>
            </div>
            <h1 class="text-2xl md:text-3xl font-bold tracking-tight text-white mb-2">
              Prescription Organizer & Medicine Reminder
            </h1>
            <p class="text-slate-300 text-sm md:text-base leading-relaxed">
              Upload prescription documents (PDF, JPG, PNG) with OCR draft extraction, schedule daily dosages, track adherence percentage, and receive in-app alerts.
            </p>
          </div>
        </div>

        <!-- Safety Notice on Missed Doses & OCR Extraction -->
        <div class="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-xl text-xs text-amber-900 shadow-sm flex items-start gap-3">
          <svg class="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
          <div class="space-y-1">
            <p class="font-bold">Important Clinical Safety Advisory:</p>
            <p>
              • <strong>Missed Dose Protocol:</strong> If you miss a scheduled dose, follow your doctor's exact prescription or consult a qualified healthcare professional. <strong>Never take extra doses or double up</strong> to make up for a missed reminder.
            </p>
            <p>
              • <strong>OCR Verification:</strong> Any scanned text extracted from uploaded prescriptions is provided strictly as a rough draft for user review. Never assume OCR text or dosages are accurate without comparing against your physical prescription.
            </p>
          </div>
        </div>

        <!-- Adherence Progress & Quick Stats Banner -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-5">
          <div class="premium-card p-5 flex items-center gap-4">
            <div class="relative w-16 h-16 flex items-center justify-center flex-shrink-0">
              <svg class="w-16 h-16 transform -rotate-90">
                <circle cx="32" cy="32" r="26" stroke="#e2e8f0" stroke-width="6" fill="transparent"/>
                <circle cx="32" cy="32" r="26" stroke="${adherence >= 80 ? '#10b981' : adherence >= 50 ? '#f59e0b' : '#ef4444'}" stroke-width="6" fill="transparent" stroke-dasharray="163" stroke-dashoffset="${163 - (163 * adherence) / 100}" class="progress-ring-circle"/>
              </svg>
              <span class="absolute font-black text-sm text-slate-800">${adherence}%</span>
            </div>
            <div>
              <div class="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Daily Adherence</div>
              <div class="text-base font-extrabold text-slate-900">${adherence >= 80 ? 'Optimal (80%+)' : adherence >= 50 ? 'Moderate' : 'Attention Needed'}</div>
              <div class="text-[11px] text-teal-700 font-semibold">${todayReminders.filter(r => r.status === 'Taken').length} of ${todayReminders.length} doses taken</div>
            </div>
          </div>

          <div class="premium-card p-5 flex items-center justify-between">
            <div>
              <div class="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Active Medications</div>
              <div class="text-2xl font-black text-slate-900 mt-0.5">${medicines.length}</div>
              <div class="text-[11px] text-teal-600 font-bold">On prescribed cycle</div>
            </div>
            <div class="w-12 h-12 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center font-bold text-xl shadow-sm">
              💊
            </div>
          </div>

          <div class="premium-card p-5 flex items-center justify-between">
            <div>
              <div class="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Prescription Vault</div>
              <div class="text-2xl font-black text-slate-900 mt-0.5">${prescriptions.length}</div>
              <div class="text-[11px] text-slate-500 font-medium">Passport synced</div>
            </div>
            <div class="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xl shadow-sm">
              📋
            </div>
          </div>

          <div class="premium-card p-5 flex items-center justify-between">
            <div>
              <div class="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Reminder Engine</div>
              <div class="text-sm font-black text-emerald-700 mt-1 flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                Active In-App
              </div>
              <button id="toggle-browser-notif-btn" class="text-[11px] text-teal-600 font-bold hover:underline mt-0.5 block">
                Enable Browser Alerts
              </button>
            </div>
            <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xl shadow-sm">
              ⏰
            </div>
          </div>
        </div>

        <!-- Navigation Tabs -->
        <div class="flex border-b border-slate-200 gap-6 text-sm font-semibold">
          <button data-tab="schedule" class="pb-3 ${activeTab === 'schedule' ? 'text-teal-600 border-b-2 border-teal-600' : 'text-slate-500 hover:text-slate-800'} transition-colors flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            Today's Schedule & Reminders
          </button>
          <button data-tab="upload" class="pb-3 ${activeTab === 'upload' ? 'text-teal-600 border-b-2 border-teal-600' : 'text-slate-500 hover:text-slate-800'} transition-colors flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/></svg>
            Upload Prescription & OCR Draft
          </button>
          <button data-tab="medicines" class="pb-3 ${activeTab === 'medicines' ? 'text-teal-600 border-b-2 border-teal-600' : 'text-slate-500 hover:text-slate-800'} transition-colors flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
            Manage Medicines (${medicines.length})
          </button>
        </div>

        <!-- Tab 1: Today's Schedule & Reminders -->
        ${activeTab === 'schedule' ? `
          <div class="space-y-6">
            <div class="flex items-center justify-between">
              <div>
                <h3 class="text-base font-bold text-slate-900">Today's Dosage Timeline (8:00 AM • 2:00 PM • 8:00 PM)</h3>
                <p class="text-xs text-slate-500">Mark doses as taken, track adherence, or record skipped doses.</p>
              </div>
              <button id="add-manual-medicine-btn" class="px-3 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-colors">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                Add Medicine
              </button>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
              ${todayReminders.map(rem => renderReminderCard(rem)).join('')}
            </div>

            <!-- In-App Notification Toast Simulation Box -->
            <div class="bg-slate-900 text-white p-4 rounded-xl border border-slate-800 flex items-center justify-between shadow-lg">
              <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center flex-shrink-0 animate-pulse">
                  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
                </div>
                <div>
                  <div class="text-xs font-bold text-teal-300">Live Reminder Engine Active</div>
                  <div class="text-[11px] text-slate-300">In-app notifications trigger automatically on your scheduled medicine times while tab is open.</div>
                </div>
              </div>
              <button id="trigger-test-alarm-btn" class="px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold rounded-lg transition-colors whitespace-nowrap">
                Test Reminder Alarm
              </button>
            </div>
          </div>
        ` : ''}

        <!-- Tab 2: Upload Prescription & OCR Draft -->
        ${activeTab === 'upload' ? `
          <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Upload Box -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
                <svg class="w-5 h-5 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>
                Upload Prescription Document
              </h3>
              <p class="text-xs text-slate-500">Supports PDF, JPG, and PNG files. Uploaded documents are automatically secured into your Medical Health Passport vault.</p>

              <div id="drop-zone" class="border-2 border-dashed border-slate-300 hover:border-teal-500 rounded-xl p-8 text-center bg-slate-50/50 hover:bg-teal-50/30 transition-all cursor-pointer">
                <input type="file" id="prescription-file-input" accept=".pdf,image/png,image/jpeg" class="hidden" />
                <div class="w-12 h-12 rounded-full bg-teal-50 text-teal-600 flex items-center justify-center mx-auto mb-3">
                  <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/></svg>
                </div>
                <div class="text-sm font-bold text-slate-800 mb-1">Click to browse or drop prescription here</div>
                <div class="text-xs text-slate-400">PDF, PNG, JPG up to 15MB</div>
              </div>

              <!-- Quick Demo Prescription Buttons -->
              <div class="pt-2">
                <span class="text-xs font-semibold text-slate-600 block mb-2">Or load a sample Gorakhpur demo prescription:</span>
                <div class="flex flex-wrap gap-2">
                  <button id="load-sample-rx-1" class="px-3 py-1.5 bg-slate-100 hover:bg-teal-50 hover:text-teal-700 text-slate-700 border border-slate-200 rounded-lg text-xs font-medium transition-colors">
                    📄 Dr. Priya Pandey (Fever & Antibiotic Rx)
                  </button>
                  <button id="load-sample-rx-2" class="px-3 py-1.5 bg-slate-100 hover:bg-teal-50 hover:text-teal-700 text-slate-700 border border-slate-200 rounded-lg text-xs font-medium transition-colors">
                    📄 Dr. Aggarwal (Calcium & Bone Joint Rx)
                  </button>
                </div>
              </div>

              <!-- File Preview Area -->
              <div id="file-preview-area" class="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-3 ${uploadedFile ? '' : 'hidden'}">
                <div class="flex items-center justify-between">
                  <span class="text-xs font-bold text-slate-700 flex items-center gap-1.5" id="preview-file-name">
                    prescription_preview.png
                  </span>
                  <span class="badge-verified">Secured & Parsed</span>
                </div>
                <div class="h-44 bg-white rounded-lg border border-slate-200 flex items-center justify-center p-3 overflow-hidden" id="canvas-preview-container">
                  <div class="text-center text-slate-400 text-xs">
                    <svg class="w-8 h-8 mx-auto mb-1 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    Prescription Document Preview Ready
                  </div>
                </div>
              </div>
            </div>

            <!-- OCR Draft & Medicine Extraction Review -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div class="flex items-center justify-between">
                <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
                  <svg class="w-5 h-5 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                  OCR Draft Extraction (User Review Required)
                </h3>
                <span class="badge-demo">Draft Mode</span>
              </div>

              <div class="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900">
                <strong>Disclaimer:</strong> Optical Character Recognition (OCR) is assistive. Do not assume names or dosages are accurate. Always inspect and edit before adding to your reminder schedule.
              </div>

              <div>
                <label class="block text-xs font-semibold text-slate-700 mb-1">Extracted Raw Prescription Text</label>
                <textarea id="ocr-draft-input" rows="5" class="w-full text-xs font-mono p-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-teal-500">${ocrDraftText || 'Upload or click a sample prescription to extract draft text...'}</textarea>
              </div>

              <!-- Quick Add Extracted Medicines Form -->
              <div class="p-4 bg-teal-50/70 border border-teal-200 rounded-xl space-y-3">
                <div class="text-xs font-bold text-teal-900">Add Medicine From Verified Draft</div>
                <div class="grid grid-cols-2 gap-2 text-xs">
                  <input type="text" id="draft-med-name" placeholder="Medicine Name (e.g. Amoxicillin 500mg)" class="p-2 bg-white border border-slate-200 rounded-lg" />
                  <input type="text" id="draft-med-dosage" placeholder="Dosage (e.g. 1 Capsule)" class="p-2 bg-white border border-slate-200 rounded-lg" />
                  <select id="draft-med-freq" class="p-2 bg-white border border-slate-200 rounded-lg">
                    <option value="Twice daily">Twice daily (8 AM - 8 PM)</option>
                    <option value="Once daily">Once daily (2 PM)</option>
                    <option value="Three times daily">Three times daily (8 AM - 2 PM - 8 PM)</option>
                  </select>
                  <input type="text" id="draft-med-instructions" placeholder="Instructions (e.g. After meal)" class="p-2 bg-white border border-slate-200 rounded-lg" />
                </div>
                <button id="save-draft-medicine-btn" class="w-full py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold transition-colors shadow-sm">
                  Add to Active Medicine Reminders
                </button>
              </div>
            </div>
          </div>
        ` : ''}

        <!-- Tab 3: Manage Medicines -->
        ${activeTab === 'medicines' ? `
          <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
            <div class="flex items-center justify-between">
              <div>
                <h3 class="text-base font-bold text-slate-900">Current Prescribed Medicines</h3>
                <p class="text-xs text-slate-500">Edit, remove, or view details of your daily medication regimen.</p>
              </div>
              <button id="add-medicine-modal-trigger" class="px-3 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                Add New Medicine
              </button>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              ${medicines.map(med => `
                <div class="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:shadow-sm transition-all flex flex-col justify-between">
                  <div>
                    <div class="flex items-start justify-between mb-2">
                      <div>
                        <h4 class="text-sm font-bold text-slate-900">${med.name}</h4>
                        <span class="text-xs font-semibold text-teal-600">${med.dosage}</span>
                      </div>
                      <span class="text-[11px] font-semibold px-2 py-0.5 bg-teal-100 text-teal-800 rounded-full">
                        ${med.frequency}
                      </span>
                    </div>

                    <div class="text-xs text-slate-600 space-y-1 my-3 bg-white p-2.5 rounded-lg border border-slate-100">
                      <div><strong>Times:</strong> ${med.reminderTimes.join(', ')}</div>
                      <div><strong>Instructions:</strong> ${med.instructions}</div>
                      <div><strong>Duration:</strong> ${med.startDate} to ${med.endDate}</div>
                      ${med.notes ? `<div class="text-slate-500 italic mt-1">${med.notes}</div>` : ''}
                    </div>
                  </div>

                  <div class="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                    <button data-action="delete-med" data-id="${med.id}" class="text-xs text-rose-600 hover:text-rose-800 font-medium px-2 py-1 hover:bg-rose-50 rounded transition-colors">
                      Remove
                    </button>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}
      </div>
    `;

    attachEvents();
  }

  function renderReminderCard(rem) {
    const isTaken = rem.status === 'Taken';
    const isSkipped = rem.status === 'Skipped';
    const isMissed = rem.status === 'Missed';

    return `
      <div class="p-4 rounded-xl border ${
        isTaken ? 'bg-emerald-50/70 border-emerald-200' :
        isSkipped ? 'bg-slate-100 border-slate-200' :
        isMissed ? 'bg-rose-50 border-rose-200' :
        'bg-white border-slate-200 shadow-sm'
      } transition-all flex flex-col justify-between">
        <div>
          <div class="flex items-center justify-between mb-2">
            <span class="text-xs font-bold uppercase tracking-wider ${isTaken ? 'text-emerald-700' : 'text-slate-500'}">
              ⏰ ${rem.timeSlot}
            </span>
            <span class="status-pill ${
              isTaken ? 'status-completed' :
              isSkipped ? 'status-cancelled' :
              isMissed ? 'status-declined' :
              'status-submitted'
            }">
              ${rem.status}
            </span>
          </div>

          <h4 class="text-sm font-bold text-slate-900 mb-1">${rem.medicineName}</h4>
          <p class="text-xs text-slate-500 mb-3">Today's scheduled intake</p>
        </div>

        <div class="pt-3 border-t border-slate-100/80">
          ${rem.status === 'Pending' ? `
            <div class="grid grid-cols-2 gap-2">
              <button data-action="mark-taken" data-id="${rem.id}" class="py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-colors shadow-sm">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                Mark Taken
              </button>
              <button data-action="mark-skipped" data-id="${rem.id}" class="py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-colors">
                Skip
              </button>
            </div>
          ` : `
            <div class="flex items-center justify-between text-xs text-slate-500">
              <span>Recorded: ${rem.loggedAt ? new Date(rem.loggedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Today'}</span>
              <button data-action="reset-reminder" data-id="${rem.id}" class="text-teal-600 hover:underline text-[11px]">Undo</button>
            </div>
          `}
        </div>
      </div>
    `;
  }

  function attachEvents() {
    // Tab switching
    container.querySelectorAll('[data-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        activeTab = btn.dataset.tab;
        render();
      });
    });

    // Reminder actions
    container.querySelectorAll('[data-action="mark-taken"]').forEach(btn => {
      btn.addEventListener('click', () => {
        db.updateReminderStatus(btn.dataset.id, 'Taken');
        window.showToast?.('Medicine marked as Taken! Adherence score updated.', 'success');
        render();
      });
    });

    container.querySelectorAll('[data-action="mark-skipped"]').forEach(btn => {
      btn.addEventListener('click', () => {
        db.updateReminderStatus(btn.dataset.id, 'Skipped');
        window.showToast?.('Dose skipped. Remember not to double the next dose.', 'info');
        render();
      });
    });

    container.querySelectorAll('[data-action="reset-reminder"]').forEach(btn => {
      btn.addEventListener('click', () => {
        db.updateReminderStatus(btn.dataset.id, 'Pending');
        render();
      });
    });

    // Delete medicine
    container.querySelectorAll('[data-action="delete-med"]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (confirm('Are you sure you want to remove this medicine?')) {
          db.deleteMedicine(btn.dataset.id);
          window.showToast?.('Medicine removed from schedule.', 'info');
          render();
        }
      });
    });

    // Add manual medicine trigger
    const addMedBtn = container.querySelector('#add-manual-medicine-btn');
    if (addMedBtn) addMedBtn.addEventListener('click', showAddMedicineModal);

    const addMedTrigger = container.querySelector('#add-medicine-modal-trigger');
    if (addMedTrigger) addMedTrigger.addEventListener('click', showAddMedicineModal);

    // Browser Notification toggle
    const notifBtn = container.querySelector('#toggle-browser-notif-btn');
    if (notifBtn) {
      notifBtn.addEventListener('click', () => {
        if ('Notification' in window) {
          Notification.requestPermission().then(perm => {
            if (perm === 'granted') {
              window.showToast?.('Browser notifications permitted! Alerts will trigger on time.', 'success');
              new Notification('Mediscan AI Pro', { body: 'Medicine reminder notifications are now active!' });
            } else {
              window.showToast?.('Browser notifications declined. In-app alerts remain active.', 'info');
            }
          });
        } else {
          window.showToast?.('Browser does not support notifications. Using in-app alerts.', 'info');
        }
      });
    }

    // Test alarm button
    const testAlarmBtn = container.querySelector('#trigger-test-alarm-btn');
    if (testAlarmBtn) {
      testAlarmBtn.addEventListener('click', () => {
        window.showToast?.('⏰ ALARM: Time to take Medicine A (Amoxicillin 500mg) - 1 Capsule after food!', 'warning');
      });
    }

    // File upload triggers
    const dropZone = container.querySelector('#drop-zone');
    const fileInput = container.querySelector('#prescription-file-input');

    if (dropZone && fileInput) {
      dropZone.addEventListener('click', () => fileInput.click());
      fileInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files[0]) {
          handlePrescriptionUpload(e.target.files[0]);
        }
      });
    }

    // Sample prescription loaders
    const sample1 = container.querySelector('#load-sample-rx-1');
    if (sample1) {
      sample1.addEventListener('click', () => {
        ocrDraftText = `DR. PRIYA PANDEY (MBBS, MD - General Medicine)\nGorakhpur Family Care, Asuran Chowk, Gorakhpur\nDate: 2026-09-12\n\nPatient: Rajesh Sharma | Age: 34\nDiagnosis: Acute Pharyngitis & Mild Fever\n\nRx:\n1. Amoxicillin 500mg Capsules - 1 cap twice daily (8 AM & 8 PM) x 5 days\n2. Paracetamol 650mg Tabs - 1 tab SOS (After food)\n3. Vitamin C & Zinc - 1 tab once daily (2 PM) x 14 days\n\nAdvice: Drink warm water, avoid cold exposure. Review in 5 days.`;
        uploadedFile = { name: 'dr_priya_pandey_prescription.png' };
        
        // Auto fill draft form
        const draftName = container.querySelector('#draft-med-name');
        const draftDosage = container.querySelector('#draft-med-dosage');
        const draftFreq = container.querySelector('#draft-med-freq');
        const draftInst = container.querySelector('#draft-med-instructions');
        if (draftName) draftName.value = 'Amoxicillin 500mg';
        if (draftDosage) draftDosage.value = '1 Capsule';
        if (draftFreq) draftFreq.value = 'Twice daily';
        if (draftInst) draftInst.value = 'After meal with water';

        render();
        window.showToast?.('Sample prescription loaded & OCR draft generated for review.', 'success');
      });
    }

    const sample2 = container.querySelector('#load-sample-rx-2');
    if (sample2) {
      sample2.addEventListener('click', () => {
        ocrDraftText = `DR. AGGARWAL (MS Orthopedics)\nBuxipur Main Road, Gorakhpur\nDate: 2026-09-12\n\nPatient: Rajesh Sharma | Age: 34\nDiagnosis: Post-injury joint soreness\n\nRx:\n1. Calcium + Vitamin D3 Tablets - 1 tab once daily at 2:00 PM\n2. Aceclofenac 100mg - 1 tab twice daily (8 AM / 8 PM) after meals\n\nFollow physical therapy exercises.`;
        uploadedFile = { name: 'dr_aggarwal_ortho_prescription.png' };

        const draftName = container.querySelector('#draft-med-name');
        const draftDosage = container.querySelector('#draft-med-dosage');
        const draftFreq = container.querySelector('#draft-med-freq');
        const draftInst = container.querySelector('#draft-med-instructions');
        if (draftName) draftName.value = 'Calcium + Vit D3';
        if (draftDosage) draftDosage.value = '1 Tablet';
        if (draftFreq) draftFreq.value = 'Once daily';
        if (draftInst) draftInst.value = 'After lunch at 2 PM';

        render();
        window.showToast?.('Sample prescription loaded & OCR draft generated for review.', 'success');
      });
    }

    // Save draft medicine
    const saveDraftBtn = container.querySelector('#save-draft-medicine-btn');
    if (saveDraftBtn) {
      saveDraftBtn.addEventListener('click', () => {
        const name = container.querySelector('#draft-med-name')?.value;
        const dosage = container.querySelector('#draft-med-dosage')?.value;
        const freq = container.querySelector('#draft-med-freq')?.value;
        const inst = container.querySelector('#draft-med-instructions')?.value;

        if (!name || !dosage) {
          alert('Please verify and enter medicine name and dosage.');
          return;
        }

        const times = freq === 'Once daily' ? ['14:00'] : ['08:00', '20:00'];

        db.addMedicine({
          name: name,
          dosage: dosage,
          frequency: freq,
          startDate: new Date().toISOString().split('T')[0],
          endDate: '2026-09-22',
          reminderTimes: times,
          instructions: inst || 'After meal',
          notes: 'Added via OCR verified draft'
        });

        // Also add prescription entry to DB
        db.addPrescription({
          title: 'Prescription Upload (' + name + ')',
          doctorName: 'Gorakhpur Doctor',
          clinicName: 'Verified Clinic',
          date: new Date().toISOString().split('T')[0],
          fileName: uploadedFile ? uploadedFile.name : 'scanned_rx.png',
          ocrExtractedDraft: ocrDraftText
        });

        window.showToast?.(`Medicine "${name}" added to schedule and prescription saved to Medical Passport!`, 'success');
        activeTab = 'schedule';
        render();
      });
    }
  }

  function handlePrescriptionUpload(file) {
    uploadedFile = file;
    ocrDraftText = `DRAFT OCR SCAN: ${file.name}\nExtracted from document:\nRx:\n1. Paracetamol 650mg - 1 tab SOS\n2. Multivitamin & Minerals - 1 tab daily at 2:00 PM\n3. Review after 7 days\n[Draft extracted text — user verification required]`;
    window.showToast?.('Prescription uploaded! Review OCR draft below.', 'success');
    render();
  }

  function showAddMedicineModal() {
    const modalContent = `
      <form id="medicine-manual-form" class="space-y-4">
        <div>
          <label class="block text-xs font-semibold text-slate-700 mb-1">Medicine Name *</label>
          <input type="text" id="manual-med-name" placeholder="e.g. Medicine A (Amoxicillin)" required class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:bg-white" />
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-xs font-semibold text-slate-700 mb-1">Dosage as Prescribed *</label>
            <input type="text" id="manual-med-dosage" placeholder="e.g. 1 Tablet / 500mg" required class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:bg-white" />
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-700 mb-1">Frequency *</label>
            <select id="manual-med-freq" class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:bg-white">
              <option value="Twice daily">Twice daily (8:00 AM & 8:00 PM)</option>
              <option value="Once daily">Once daily (2:00 PM)</option>
              <option value="Three times daily">Three times daily (8 AM, 2 PM, 8 PM)</option>
              <option value="Every 8 hours">Every 8 hours</option>
            </select>
          </div>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-xs font-semibold text-slate-700 mb-1">Start Date</label>
            <input type="date" id="manual-med-start" value="${new Date().toISOString().split('T')[0]}" class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:bg-white" />
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-700 mb-1">End Date</label>
            <input type="date" id="manual-med-end" value="2026-09-20" class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:bg-white" />
          </div>
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-700 mb-1">Specific Reminder Times</label>
          <div class="flex items-center gap-3 text-xs text-slate-700">
            <label class="flex items-center gap-1.5"><input type="checkbox" id="time-8am" checked /> 8:00 AM</label>
            <label class="flex items-center gap-1.5"><input type="checkbox" id="time-2pm" /> 2:00 PM</label>
            <label class="flex items-center gap-1.5"><input type="checkbox" id="time-8pm" checked /> 8:00 PM</label>
          </div>
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-700 mb-1">Instructions</label>
          <input type="text" id="manual-med-inst" placeholder="e.g. After meal with warm water" class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:bg-white" />
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-700 mb-1">Doctor's Notes</label>
          <textarea id="manual-med-notes" rows="2" placeholder="Any special precautions or instructions..." class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 focus:bg-white"></textarea>
        </div>
      </form>
    `;

    window.openModal?.('Add Medicine Reminder', modalContent, [
      { label: 'Cancel', action: 'close', className: 'bg-slate-200 hover:bg-slate-300 text-slate-700' },
      {
        label: 'Save & Schedule Reminder',
        action: () => {
          const name = document.getElementById('manual-med-name')?.value;
          const dosage = document.getElementById('manual-med-dosage')?.value;
          const freq = document.getElementById('manual-med-freq')?.value;
          const start = document.getElementById('manual-med-start')?.value;
          const end = document.getElementById('manual-med-end')?.value;
          const inst = document.getElementById('manual-med-inst')?.value;
          const notes = document.getElementById('manual-med-notes')?.value;

          if (!name || !dosage) {
            alert('Please provide medicine name and dosage.');
            return false;
          }

          const times = [];
          if (document.getElementById('time-8am')?.checked) times.push('08:00');
          if (document.getElementById('time-2pm')?.checked) times.push('14:00');
          if (document.getElementById('time-8pm')?.checked) times.push('20:00');
          if (!times.length) times.push('08:00');

          db.addMedicine({
            name,
            dosage,
            frequency: freq,
            startDate: start,
            endDate: end,
            reminderTimes: times,
            instructions: inst,
            notes
          });

          window.closeModal?.();
          window.showToast?.(`Medicine "${name}" scheduled successfully!`, 'success');
          render();
        },
        className: 'bg-teal-600 hover:bg-teal-700 text-white'
      }
    ]);
  }

  // Initial render
  render();
}
