/**
 * Module 7: Patient Medical Health Passport Integration
 * Team: The Code Burner | Maharana Pratap Institute of Technology, Gorakhpur
 */

import { db } from '../db.js';

export function renderPassportModule(container) {
  let activeSection = 'profile'; // 'profile' | 'documents' | 'timeline' | 'emergency-qr'

  function render() {
    const patient = db.getPatientProfile();
    const documents = db.getMedicalDocuments();
    const appointments = db.getAppointments();
    const bloodRequests = db.getBloodRequests();
    const medicines = db.getMedicines();

    // Construct unified activity timeline
    const timeline = [];

    // Add appointments
    appointments.forEach(apt => {
      timeline.push({
        title: `Appointment: ${apt.doctorName} (${apt.specialty})`,
        date: apt.createdAt || apt.preferredDate,
        type: 'appointment',
        status: apt.status,
        icon: 'calendar',
        details: `Scheduled for ${apt.preferredDate} at ${apt.preferredTime}. Symptoms: ${apt.symptoms || 'General consult'}`
      });
    });

    // Add blood requests
    bloodRequests.forEach(req => {
      timeline.push({
        title: `Emergency Blood Request: ${req.requiredBloodGroup} (${req.unitsRequired} Units)`,
        date: req.createdAt,
        type: 'emergency',
        status: req.status,
        icon: 'heart',
        details: `Dispatched for ${req.patientName} at ${req.hospitalName}.`
      });
    });

    // Add documents
    documents.forEach(doc => {
      timeline.push({
        title: `Document Upload: ${doc.title}`,
        date: doc.date,
        type: 'document',
        status: 'Archived',
        icon: 'file-text',
        details: `${doc.facility} • ${doc.summary}`
      });
    });

    // Sort timeline descending
    timeline.sort((a, b) => new Date(b.date) - new Date(a.date));

    container.innerHTML = `
      <div class="space-y-8 animate-fade-in">
        <!-- Page Header -->
        <div class="bg-gradient-to-r from-slate-900 via-slate-800 to-teal-950 p-6 md:p-8 rounded-2xl text-white shadow-elevated border border-slate-700/60 relative overflow-hidden">
          <div class="absolute -right-10 -bottom-10 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <div class="max-w-3xl">
            <div class="flex items-center gap-3 mb-3">
              <span class="bg-teal-500/20 text-teal-300 border border-teal-500/30 text-xs font-semibold px-3 py-1 rounded-full flex items-center gap-1.5">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                National Health ID & EHR Vault
              </span>
              <span class="badge-verified">End-to-End Encrypted</span>
            </div>
            <h1 class="text-2xl md:text-3xl font-bold tracking-tight text-white mb-2">
              Patient Medical Health Passport
            </h1>
            <p class="text-slate-300 text-sm md:text-base leading-relaxed">
              Your consolidated, privacy-protected personal health record. Centralize verified medical reports, prescription documents, emergency contacts, chronic conditions, and emergency QR scan access.
            </p>
          </div>
        </div>

        <!-- Privacy Assurance Banner -->
        <div class="bg-teal-50 border-l-4 border-teal-600 p-4 rounded-xl text-xs text-teal-950 shadow-sm flex items-start gap-3">
          <svg class="w-5 h-5 text-teal-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
          <div>
            <p class="font-bold text-teal-900 mb-0.5">Strict Confidentiality & Authorization Guard:</p>
            <p class="leading-relaxed">
              "Medical documents and health histories are private and never exposed to the public donor or blood-bank directories. Accessible exclusively by authenticated patients and authorized hospital personnel with emergency credential override."
            </p>
          </div>
        </div>

        <!-- Section Tabs -->
        <div class="flex border-b border-slate-200 gap-6 text-sm font-semibold">
          <button data-sec="profile" class="pb-3 ${activeSection === 'profile' ? 'text-teal-600 border-b-2 border-teal-600' : 'text-slate-500 hover:text-slate-800'} transition-colors flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
            Patient Health Profile
          </button>
          <button data-sec="documents" class="pb-3 ${activeSection === 'documents' ? 'text-teal-600 border-b-2 border-teal-600' : 'text-slate-500 hover:text-slate-800'} transition-colors flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
            Document Vault (${documents.length})
          </button>
          <button data-sec="timeline" class="pb-3 ${activeSection === 'timeline' ? 'text-teal-600 border-b-2 border-teal-600' : 'text-slate-500 hover:text-slate-800'} transition-colors flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            Activity Timeline (${timeline.length})
          </button>
          <button data-sec="emergency-qr" class="pb-3 ${activeSection === 'emergency-qr' ? 'text-teal-600 border-b-2 border-teal-600' : 'text-slate-500 hover:text-slate-800'} transition-colors flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/></svg>
            Paramedic Emergency QR
          </button>
        </div>

        <!-- Section 1: Patient Profile -->
        ${activeSection === 'profile' ? `
          <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Left: Card Overview -->
            <div class="premium-card p-6 flex flex-col justify-between">
              <div>
                <div class="flex items-center gap-4 mb-4">
                  <div class="w-16 h-16 rounded-2xl bg-gradient-to-tr from-teal-500 to-emerald-400 text-white flex items-center justify-center font-black text-2xl shadow-lg shadow-teal-500/25">
                    ${patient.fullName.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h3 class="text-lg font-black text-slate-900">${patient.fullName}</h3>
                    <p class="text-xs text-slate-500 font-medium">${patient.age} yrs • ${patient.gender}</p>
                    <span class="badge-verified mt-1">National ABHA Linked</span>
                  </div>
                </div>

                <div class="space-y-2.5 text-xs text-slate-700 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  <div class="flex justify-between py-1 border-b border-slate-200/80">
                    <span class="text-slate-400 font-semibold">ABHA Number:</span>
                    <strong class="font-mono text-teal-800 font-bold">${patient.abhaId}</strong>
                  </div>
                  <div class="flex justify-between py-1 border-b border-slate-200/80">
                    <span class="text-slate-400 font-semibold">Registered Phone:</span>
                    <strong class="text-slate-900 font-bold">${patient.phone}</strong>
                  </div>
                  <div class="flex justify-between py-1 border-b border-slate-200/80">
                    <span class="text-slate-400 font-semibold">Primary Locality:</span>
                    <strong class="text-slate-900 font-bold">${patient.address}</strong>
                  </div>
                  <div class="flex justify-between py-1">
                    <span class="text-slate-400 font-semibold">Active Regimen:</span>
                    <strong class="text-teal-700 font-bold">${medicines.length} Medicines Prescribed</strong>
                  </div>
                </div>
              </div>

              <div class="pt-4 mt-4 border-t border-slate-100">
                <button id="edit-patient-profile-btn" class="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-all shadow-sm">
                  Update Health Profile
                </button>
              </div>
            </div>

            <!-- Middle: Blood Group & Emergency Health Metrics -->
            <div class="premium-card p-6 space-y-4">
              <div class="flex items-center justify-between">
                <h4 class="text-sm font-extrabold text-slate-900">Critical Medical Baseline</h4>
                <span class="badge-emergency">Emergency Vital</span>
              </div>

              <div class="p-4 rounded-xl bg-gradient-to-br from-red-500 to-rose-600 text-white shadow-md flex items-center justify-between">
                <div>
                  <div class="text-xs text-red-100 uppercase font-semibold">Verified Blood Group</div>
                  <div class="text-3xl font-black mt-1">${patient.bloodGroup}</div>
                  <div class="text-[11px] text-red-100 mt-1">Rh Positive • Can receive from O+, O-</div>
                </div>
                <div class="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center text-xl">
                  🩸
                </div>
              </div>

              <!-- Known Allergies -->
              <div class="p-3.5 bg-amber-50 rounded-xl border border-amber-200 space-y-1.5">
                <div class="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                  <svg class="w-4 h-4 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                  Drug Allergies (CRITICAL)
                </div>
                <div class="flex flex-wrap gap-1.5">
                  ${patient.allergies.map(all => `
                    <span class="px-2 py-0.5 bg-amber-200 text-amber-900 rounded text-xs font-bold">${all}</span>
                  `).join('')}
                </div>
              </div>

              <!-- Chronic Conditions -->
              <div class="p-3.5 bg-blue-50 rounded-xl border border-blue-200 space-y-1.5">
                <div class="text-xs font-bold text-blue-900">Chronic Conditions</div>
                <div class="flex flex-wrap gap-1.5">
                  ${patient.chronicConditions.map(cc => `
                    <span class="px-2 py-0.5 bg-blue-200 text-blue-900 rounded text-xs font-semibold">${cc}</span>
                  `).join('')}
                </div>
              </div>
            </div>

            <!-- Right: Emergency Contacts -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div class="flex items-center justify-between">
                <h4 class="text-sm font-bold text-slate-900">Emergency Contacts</h4>
                <button id="add-emergency-contact-btn" class="text-xs text-teal-600 font-semibold hover:underline">+ Add</button>
              </div>

              <div class="space-y-3">
                ${patient.emergencyContacts.map(ec => `
                  <div class="p-3 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between">
                    <div>
                      <div class="text-xs font-bold text-slate-900">${ec.name}</div>
                      <div class="text-[11px] text-slate-500">${ec.relation}</div>
                      <div class="text-xs font-mono font-bold text-teal-700 mt-1">${ec.phone}</div>
                    </div>
                    <a href="tel:${ec.phone}" class="w-8 h-8 rounded-lg bg-teal-100 text-teal-700 flex items-center justify-center hover:bg-teal-200 transition-colors">
                      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                    </a>
                  </div>
                `).join('')}
              </div>

              <div class="pt-2">
                <button id="open-emergency-sos-btn" class="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-sm">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
                  Instant Paramedic QR Scan Card
                </button>
              </div>
            </div>
          </div>
        ` : ''}

        <!-- Section 2: Document Vault -->
        ${activeSection === 'documents' ? `
          <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            <div class="flex items-center justify-between">
              <div>
                <h3 class="text-base font-bold text-slate-900">Archived Health Documents & Reports</h3>
                <p class="text-xs text-slate-500">Encrypted prescriptions, diagnostic lab panels, and discharge summaries.</p>
              </div>
              <button id="upload-new-vault-doc-btn" class="px-3 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                Upload Medical Document
              </button>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
              ${documents.map(doc => `
                <div class="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:shadow-md transition-all flex flex-col justify-between">
                  <div>
                    <div class="flex items-start justify-between gap-2 mb-2">
                      <span class="px-2 py-0.5 rounded text-[10px] font-bold ${
                        doc.category === 'Prescription' ? 'bg-teal-100 text-teal-800' :
                        doc.category === 'Lab Report' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'
                      }">
                        ${doc.category}
                      </span>
                      <span class="text-[11px] text-slate-400 font-mono">${doc.date}</span>
                    </div>

                    <h4 class="text-xs font-bold text-slate-900 mb-1 line-clamp-1">${doc.title}</h4>
                    <p class="text-[11px] text-slate-500 mb-2">${doc.facility}</p>
                    <p class="text-xs text-slate-600 bg-white p-2.5 rounded-lg border border-slate-100 line-clamp-2">${doc.summary}</p>
                  </div>

                  <div class="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between">
                    <span class="text-[10px] text-emerald-700 font-semibold">🔒 Private</span>
                    <button data-action="view-doc" data-title="${doc.title}" data-summary="${doc.summary}" data-date="${doc.date}" data-facility="${doc.facility}" class="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-semibold">
                      View Preview
                    </button>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

        <!-- Section 3: Activity Timeline -->
        ${activeSection === 'timeline' ? `
          <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            <div>
              <h3 class="text-base font-bold text-slate-900">Unified Medical Activity Stream</h3>
              <p class="text-xs text-slate-500">Chronological history combining prescriptions, taken doses, specialist appointments, and blood requests.</p>
            </div>

            <div class="relative pl-6 border-l-2 border-slate-200 space-y-6">
              ${timeline.map(item => `
                <div class="relative">
                  <div class="absolute -left-[31px] top-0 w-4 h-4 rounded-full border-2 border-white ${
                    item.type === 'emergency' ? 'bg-red-600 ring-2 ring-red-200' :
                    item.type === 'appointment' ? 'bg-teal-600 ring-2 ring-teal-200' : 'bg-blue-600 ring-2 ring-blue-200'
                  }"></div>
                  <div class="p-4 rounded-xl border border-slate-200 bg-slate-50">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-1">
                      <h4 class="text-xs font-bold text-slate-900">${item.title}</h4>
                      <span class="text-[10px] text-slate-400 font-mono">${new Date(item.date).toLocaleDateString()}</span>
                    </div>
                    <p class="text-xs text-slate-600">${item.details}</p>
                    <div class="mt-2">
                      <span class="status-pill status-${item.status.toLowerCase().replace(/\s+/g, '-')} text-[10px]">
                        ${item.status}
                      </span>
                    </div>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

        <!-- Section 4: Paramedic Emergency QR -->
        ${activeSection === 'emergency-qr' ? `
          <div class="max-w-xl mx-auto bg-white p-6 md:p-8 rounded-2xl border border-slate-200 shadow-sm text-center space-y-6">
            <div>
              <span class="badge-emergency">Offline First Emergency Badge</span>
              <h3 class="text-lg font-bold text-slate-900 mt-2">Emergency Paramedic Rapid Scan</h3>
              <p class="text-xs text-slate-500 mt-1">First responders can scan this encrypted QR code to instantly access critical allergies, blood group, and emergency contact details without requiring phone unlock.</p>
            </div>

            <!-- Render QR simulation -->
            <div class="p-6 bg-slate-50 rounded-2xl border border-slate-200 inline-block shadow-inner">
              <div class="w-48 h-48 bg-white border-2 border-slate-900 p-2 mx-auto rounded-xl flex items-center justify-center">
                <!-- SVG simulated QR code matrix -->
                <svg class="w-full h-full text-slate-900" viewBox="0 0 100 100" fill="currentColor">
                  <path d="M0 0h30v30H0zm5 5v20h20V5zm5 5h10v10H10zM70 0h30v30H70zm5 5v20h20V5zm5 5h10v10H80zM0 70h30v30H0zm5 5v20h20V75zm5 5h10v10H10zM40 10h10v10H40zm0 20h10v10H40zm10 10h10v10H50zm-10 10h10v10H40zm20 0h10v10H60zm10-20h10v10H70zm10 20h10v10H80zm-40 20h10v10H40zm20 0h10v10H60zm10 10h10v10H70zm10 10h10v10H80z"/>
                </svg>
              </div>
              <div class="text-[11px] font-mono font-bold text-slate-700 mt-3">ID: ${patient.abhaId}</div>
            </div>

            <div class="p-4 bg-red-50 border border-red-200 rounded-xl text-xs text-left space-y-2">
              <div class="font-bold text-red-900">Paramedic Instant Medical Summary:</div>
              <div class="text-slate-700"><strong>Patient:</strong> ${patient.fullName} (Age: ${patient.age}, Male)</div>
              <div class="text-slate-700"><strong>Blood Group:</strong> <span class="font-bold text-red-700">${patient.bloodGroup}</span></div>
              <div class="text-slate-700"><strong>Drug Allergies:</strong> <span class="font-bold text-amber-800">${patient.allergies.join(', ')}</span></div>
              <div class="text-slate-700"><strong>Emergency Contact:</strong> ${patient.emergencyContacts[0].name} (${patient.emergencyContacts[0].phone})</div>
            </div>

            <button onclick="window.print()" class="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold transition-colors">
              🖨️ Print Paramedic Emergency Wallet Card
            </button>
          </div>
        ` : ''}
      </div>
    `;

    attachEvents();
  }

  function attachEvents() {
    container.querySelectorAll('[data-sec]').forEach(btn => {
      btn.addEventListener('click', () => {
        activeSection = btn.dataset.sec;
        render();
      });
    });

    // View document preview modal
    container.querySelectorAll('[data-action="view-doc"]').forEach(btn => {
      btn.addEventListener('click', () => {
        window.openModal?.(btn.dataset.title, `
          <div class="space-y-4">
            <div class="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1">
              <div><strong>Issuing Center:</strong> ${btn.dataset.facility}</div>
              <div><strong>Recorded Date:</strong> ${btn.dataset.date}</div>
            </div>
            <div class="p-4 bg-white border border-slate-200 rounded-xl text-xs text-slate-700 leading-relaxed font-mono">
              ${btn.dataset.summary}
            </div>
            <div class="text-[11px] text-slate-400 italic">
              * Document stored with patient cryptographic signature.
            </div>
          </div>
        `, [
          { label: 'Close', action: 'close', className: 'bg-slate-200 text-slate-700' },
          { label: 'Download Copy (Simulated)', action: () => { window.showToast?.('Medical document downloaded safely.', 'success'); window.closeModal?.(); }, className: 'bg-teal-600 text-white' }
        ]);
      });
    });

    // Open emergency SOS card
    const sosBtn = container.querySelector('#open-emergency-sos-btn');
    if (sosBtn) {
      sosBtn.addEventListener('click', () => {
        activeSection = 'emergency-qr';
        render();
      });
    }

    // Upload new vault doc
    const uploadVaultBtn = container.querySelector('#upload-new-vault-doc-btn');
    if (uploadVaultBtn) {
      uploadVaultBtn.addEventListener('click', () => {
        window.openModal?.('Upload Medical Document to Vault', `
          <form id="vault-upload-form" class="space-y-3">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Document Title *</label>
              <input type="text" id="vault-title" placeholder="e.g. Chest X-Ray Report" required class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg" />
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                <select id="vault-cat" class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                  <option value="Lab Report">Lab Report</option>
                  <option value="Prescription">Prescription</option>
                  <option value="Discharge Summary">Discharge Summary</option>
                  <option value="Immunization">Immunization Record</option>
                </select>
              </div>
              <div>
                <label class="block text-xs font-semibold text-slate-700 mb-1">Facility / Hospital</label>
                <input type="text" id="vault-facility" value="BRD Medical College, Gorakhpur" class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg" />
              </div>
            </div>
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Summary / Clinical Notes</label>
              <textarea id="vault-summary" rows="2" class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg" placeholder="Summary findings..."></textarea>
            </div>
          </form>
        `, [
          { label: 'Cancel', action: 'close', className: 'bg-slate-200 text-slate-700' },
          {
            label: 'Save into Vault',
            action: () => {
              const title = document.getElementById('vault-title')?.value;
              const cat = document.getElementById('vault-cat')?.value;
              const facility = document.getElementById('vault-facility')?.value;
              const summary = document.getElementById('vault-summary')?.value;

              if (!title) {
                alert('Please provide document title.');
                return false;
              }

              db.addMedicalDocument({
                title,
                category: cat,
                facility,
                summary
              });

              window.closeModal?.();
              window.showToast?.(`Document "${title}" saved to Medical Passport!`, 'success');
              render();
            },
            className: 'bg-teal-600 text-white'
          }
        ]);
      });
    }
  }

  // Initial render
  render();
}
