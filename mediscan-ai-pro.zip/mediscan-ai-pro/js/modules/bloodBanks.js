/**
 * Module 5: Blood Bank Management & Staff Portal
 * Team: The Code Burner | Maharana Pratap Institute of Technology, Gorakhpur
 */

import { db } from '../db.js';

export function renderBloodBanksModule(container) {
  let selectedBloodGroup = 'All';

  function render() {
    const currentUser = db.getCurrentUser();
    const bloodBanks = db.getBloodBanks();
    const isStaffOrAdmin = currentUser.role === 'Blood Bank Staff' || currentUser.role === 'Admin';
    const activeBank = bloodBanks.find(b => b.id === currentUser.activeBloodBankId) || bloodBanks[0];

    const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

    container.innerHTML = `
      <div class="space-y-8 animate-fade-in">
        <!-- Page Header -->
        <div class="bg-gradient-to-r from-slate-900 via-slate-800 to-red-950 p-6 md:p-8 rounded-2xl text-white shadow-elevated border border-slate-700/60 relative overflow-hidden">
          <div class="absolute -right-10 -bottom-10 w-64 h-64 bg-red-600/10 rounded-full blur-3xl pointer-events-none"></div>
          <div class="max-w-3xl">
            <div class="flex items-center gap-3 mb-3">
              <span class="bg-red-500/20 text-red-300 border border-red-500/30 text-xs font-semibold px-3 py-1 rounded-full flex items-center gap-1.5">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                Licensed Regional Facilities • Gorakhpur
              </span>
              <span class="badge-demo">Demo Inventory Records</span>
            </div>
            <h1 class="text-2xl md:text-3xl font-bold tracking-tight text-white mb-2">
              Blood Bank Centers & Inventory Management
            </h1>
            <p class="text-slate-300 text-sm md:text-base leading-relaxed">
              Explore reported unit reserves across authorized Gorakhpur blood banks. Authorized staff can adjust live inventory counts, review stock adequacy alerts, and process emergency allocation requisitions.
            </p>
          </div>
        </div>

        <!-- Role Access Status Banner -->
        <div class="p-4 rounded-xl border ${
          isStaffOrAdmin ? 'bg-teal-50 border-teal-200 text-teal-900' : 'bg-slate-100 border-slate-200 text-slate-700'
        } flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-sm">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded-lg ${isStaffOrAdmin ? 'bg-teal-600 text-white' : 'bg-slate-300 text-slate-700'} flex items-center justify-center font-bold flex-shrink-0">
              ${isStaffOrAdmin ? '🛡️' : '👤'}
            </div>
            <div>
              <div class="font-bold">Active Persona Mode: <span class="text-teal-700">${currentUser.role}</span></div>
              <div class="text-slate-500 text-[11px]">
                ${isStaffOrAdmin 
                  ? 'Inventory editing and stock update operations are UNLOCKED for you.' 
                  : 'Viewing in Patient/Requester mode (read-only inventory). Switch to "Blood Bank Staff" in top bar to edit.'}
              </div>
            </div>
          </div>

          ${!isStaffOrAdmin ? `
            <button id="quick-switch-staff-btn" class="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-lg transition-colors whitespace-nowrap shadow-sm">
              Switch to Staff Mode
            </button>
          ` : `
            <span class="badge-verified">Authorized Staff Level</span>
          `}
        </div>

        <!-- Authorized Staff Inventory Manager Section (Visible when role is Staff or Admin) -->
        ${isStaffOrAdmin ? `
          <div class="bg-white p-6 rounded-2xl border-2 border-teal-500/40 shadow-sm space-y-4">
            <div class="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
                  <span class="w-3 h-3 bg-teal-600 rounded-full"></span>
                  Staff Inventory Update Panel • ${activeBank.name}
                </h3>
                <p class="text-xs text-slate-500">Authorized personnel only: update verified available PRBC units per blood group.</p>
              </div>
              <span class="text-xs font-mono font-bold text-teal-700 bg-teal-50 px-2 py-1 rounded border border-teal-200">
                Facility ID: ${activeBank.id}
              </span>
            </div>

            <!-- Inventory Quick Editor Grid -->
            <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
              ${bloodGroups.map(bg => {
                const currentUnits = activeBank.inventory[bg] || 0;
                return `
                  <div class="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center space-y-2">
                    <div class="font-black text-sm text-red-700">${bg}</div>
                    <div class="text-lg font-bold text-slate-800" id="unit-val-${bg}">${currentUnits}</div>
                    <div class="flex items-center justify-center gap-1">
                      <button data-action="dec-unit" data-bank="${activeBank.id}" data-bg="${bg}" class="w-6 h-6 rounded bg-white border border-slate-300 hover:bg-slate-100 text-xs font-bold">-</button>
                      <button data-action="inc-unit" data-bank="${activeBank.id}" data-bg="${bg}" class="w-6 h-6 rounded bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold">+</button>
                    </div>
                  </div>
                `;
              }).join('')}
            </div>

            <div class="text-[11px] text-slate-400 italic">
              * Changes made here are saved directly to the shared persistent database and immediately reflect on the Blood Finder and Map view.
            </div>
          </div>
        ` : ''}

        <!-- Blood Group Filter Bar -->
        <div class="flex items-center justify-between">
          <div class="text-xs font-bold uppercase tracking-wider text-slate-500">Filter Facilities by Blood Group:</div>
          <div class="flex flex-wrap gap-1.5">
            <button data-filter-bg="All" class="px-2.5 py-1 rounded text-xs font-semibold ${selectedBloodGroup === 'All' ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-700'}">All</button>
            ${bloodGroups.map(bg => `
              <button data-filter-bg="${bg}" class="px-2.5 py-1 rounded text-xs font-semibold ${selectedBloodGroup === bg ? 'bg-red-600 text-white' : 'bg-white border border-slate-200 text-slate-700'}">${bg}</button>
            `).join('')}
          </div>
        </div>

        <!-- Blood Banks Listing Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          ${bloodBanks.map(bank => renderBloodBankCard(bank, isStaffOrAdmin, selectedBloodGroup)).join('')}
        </div>
      </div>
    `;

    attachEvents();
  }

  function renderBloodBankCard(bank, isStaffOrAdmin, filterGroup) {
    const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
    const totalUnits = Object.values(bank.inventory).reduce((acc, v) => acc + v, 0);

    return `
      <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4">
        <div>
          <div class="flex items-start justify-between gap-2 mb-2">
            <div>
              <h4 class="text-base font-bold text-slate-900">${bank.name}</h4>
              <p class="text-xs text-slate-500">${bank.facilityType}</p>
            </div>
            <span class="badge-demo text-[10px]">Demo Listing</span>
          </div>

          <p class="text-xs text-slate-600 flex items-center gap-1.5 mb-3">
            <svg class="w-3.5 h-3.5 text-slate-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            ${bank.address}
          </p>

          <div class="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-xl border border-slate-100 mb-4">
            <div>
              <span class="text-slate-400 block text-[10px]">Contact Helpline:</span>
              <strong class="text-slate-800">${bank.contactPhone}</strong>
            </div>
            <div>
              <span class="text-slate-400 block text-[10px]">Total Reserves:</span>
              <strong class="text-emerald-700">${totalUnits} Units Reported</strong>
            </div>
          </div>

          <!-- Inventory Pill Matrix -->
          <div>
            <div class="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">Reported Units by Blood Group:</div>
            <div class="grid grid-cols-4 gap-2">
              ${bloodGroups.map(bg => {
                const count = bank.inventory[bg] || 0;
                const isSelectedFilter = filterGroup === bg;
                return `
                  <div class="p-2 rounded-lg border text-center ${
                    isSelectedFilter 
                      ? 'bg-red-50 border-red-300 ring-2 ring-red-400' 
                      : 'bg-white border-slate-200'
                  }">
                    <div class="text-[11px] font-bold text-slate-700">${bg}</div>
                    <div class="text-xs font-black ${count > 5 ? 'text-emerald-600' : count > 0 ? 'text-amber-600' : 'text-rose-600'}">${count} u</div>
                  </div>
                `;
              }).join('')}
            </div>
          </div>
        </div>

        <div class="pt-4 border-t border-slate-100 flex items-center justify-between">
          <span class="text-[11px] text-slate-400">⏱️ Updated: Today</span>
          <div class="flex gap-2">
            <button data-action="call-facility" data-name="${bank.name}" data-phone="${bank.contactPhone}" class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold">
              Call Desk
            </button>
            <button data-action="request-facility" data-id="${bank.id}" data-name="${bank.name}" class="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold shadow-sm">
              Requisition Blood
            </button>
          </div>
        </div>
      </div>
    `;
  }

  function attachEvents() {
    // Blood group filter
    container.querySelectorAll('[data-filter-bg]').forEach(btn => {
      btn.addEventListener('click', () => {
        selectedBloodGroup = btn.dataset.filterBg;
        render();
      });
    });

    // Quick switch to staff mode
    const switchBtn = container.querySelector('#quick-switch-staff-btn');
    if (switchBtn) {
      switchBtn.addEventListener('click', () => {
        db.setCurrentRole('Blood Bank Staff');
        window.updateRoleSelectorUI?.('Blood Bank Staff');
        window.showToast?.('Switched to Blood Bank Staff mode! Inventory editor is now active.', 'success');
        render();
      });
    }

    // Inventory increment / decrement
    container.querySelectorAll('[data-action="inc-unit"]').forEach(btn => {
      btn.addEventListener('click', () => {
        const bankId = btn.dataset.bank;
        const bg = btn.dataset.bg;
        const bank = db.getBloodBanks().find(b => b.id === bankId);
        if (bank) {
          const current = bank.inventory[bg] || 0;
          db.updateBloodBankInventory(bankId, bg, current + 1);
          render();
        }
      });
    });

    container.querySelectorAll('[data-action="dec-unit"]').forEach(btn => {
      btn.addEventListener('click', () => {
        const bankId = btn.dataset.bank;
        const bg = btn.dataset.bg;
        const bank = db.getBloodBanks().find(b => b.id === bankId);
        if (bank) {
          const current = bank.inventory[bg] || 0;
          db.updateBloodBankInventory(bankId, bg, Math.max(0, current - 1));
          render();
        }
      });
    });

    // Call facility
    container.querySelectorAll('[data-action="call-facility"]').forEach(btn => {
      btn.addEventListener('click', () => {
        window.openModal?.(`Helpline • ${btn.dataset.name}`, `
          <div class="space-y-3">
            <p class="text-xs text-slate-600">Simulating emergency facility desk call:</p>
            <div class="p-4 bg-slate-100 rounded-xl text-center">
              <div class="text-xs text-slate-400">Desk Phone</div>
              <div class="text-lg font-mono font-bold text-slate-800 mt-1">${btn.dataset.phone}</div>
            </div>
          </div>
        `, [{ label: 'Close', action: 'close', className: 'bg-slate-200 text-slate-700' }]);
      });
    });

    // Requisition action
    container.querySelectorAll('[data-action="request-facility"]').forEach(btn => {
      btn.addEventListener('click', () => {
        window.showToast?.(`Requisition sent to ${btn.dataset.name}!`, 'success');
      });
    });
  }

  // Initial render
  render();
}
