/**
 * Module 1: Best Doctors & Healthcare Specialists (Modern UI Edition)
 * Team: The Code Burner | Maharana Pratap Institute of Technology, Gorakhpur
 */

import { db } from '../db.js';

export function renderSpecialistsModule(container) {
  let selectedCategory = 'All';
  let searchQuery = '';
  let selectedLocation = 'All';

  const categories = [
    { name: 'All', icon: 'stethoscope', count: 7, label: 'All Specialties' },
    { name: 'Dermatologist', icon: 'sparkles', count: 1, label: 'Skin & Dermatology' },
    { name: 'Ophthalmologist', icon: 'eye', count: 1, label: 'Eye Care / Vision' },
    { name: 'Orthopedic', icon: 'bone', count: 1, label: 'Bone & Joints' },
    { name: 'Nutritionist', icon: 'apple', count: 1, label: 'Diet & Nutrition' },
    { name: 'Cardiologist', icon: 'heart-pulse', count: 1, label: 'Heart & Vascular' },
    { name: 'General Physician', icon: 'activity', count: 1, label: 'Family & Internal Medicine' },
    { name: 'Pediatrician', icon: 'baby', count: 1, label: 'Child Health' }
  ];

  function getCategoryIconSvg(icon) {
    switch (icon) {
      case 'sparkles':
        return `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/></svg>`;
      case 'eye':
        return `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>`;
      case 'bone':
        return `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11a2 2 0 01-2 2h-2v4l3 3-1.5 1.5L13 18.5V13h-2v5.5l-3.5 3L6 20l3-3v-4H7a2 2 0 01-2-2V9a2 2 0 012-2h2V3l-3-3 1.5-1.5L11 2v5h2V2l3.5-3.5L18 0l-3 3v4h2a2 2 0 012 2v2z"/></svg>`;
      case 'apple':
        return `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 2a4 4 0 00-4 4c0 .73.2 1.41.54 2H8a5 5 0 00-5 5c0 4.42 4.03 8 9 8s9-3.58 9-8a5 5 0 00-5-5h-.54A4 4 0 0012 2z"/></svg>`;
      case 'heart-pulse':
        return `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>`;
      case 'baby':
        return `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`;
      default:
        return `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>`;
    }
  }

  function render() {
    const doctors = db.getDoctors({
      category: selectedCategory,
      query: searchQuery,
      location: selectedLocation
    });

    const appointments = db.getAppointments();

    container.innerHTML = `
      <div class="space-y-8 animate-fade-in text-slate-100">
        
        <!-- Header Banner -->
        <div class="glass-panel p-6 md:p-8 relative overflow-hidden border border-teal-500/20">
          <div class="absolute -right-16 -top-16 w-80 h-80 bg-teal-500/15 rounded-full blur-3xl pointer-events-none"></div>
          
          <div class="relative z-10 max-w-3xl space-y-2">
            <div class="flex items-center gap-3">
              <span class="badge-neon">
                <span class="w-2 h-2 rounded-full bg-teal-400 animate-ping"></span>
                Specialist Directory • Gorakhpur
              </span>
              <span class="badge-demo">Demo Listing Prototype</span>
            </div>
            
            <h1 class="text-2xl md:text-4xl font-black tracking-tight text-white">
              Best Doctors & Healthcare Specialists
            </h1>
            
            <p class="text-slate-300 text-xs md:text-sm leading-relaxed max-w-2xl font-normal">
              Find verified medical specialists, private clinics, and apex hospitals across Gorakhpur. View specialty profiles, check OPD availability, and book demo consultation slots.
            </p>
          </div>
        </div>

        <!-- Specialty Selection Cards Grid -->
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <h2 class="text-sm font-extrabold text-white flex items-center gap-2">
              <span class="w-2.5 h-2.5 bg-teal-400 rounded-full animate-pulse"></span>
              Select Medical Specialty
            </h2>
            <span class="text-xs text-slate-400 font-semibold">Click category to filter instantly</span>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            ${categories.map(cat => {
              const isActive = selectedCategory.toLowerCase() === cat.name.toLowerCase();
              return `
                <button 
                  data-category="${cat.name}" 
                  class="specialty-card p-4 rounded-2xl border text-left transition-all duration-200 flex flex-col justify-between ${
                    isActive 
                      ? 'bg-gradient-to-br from-teal-500 to-teal-700 text-white border-teal-400 shadow-xl shadow-teal-500/30 transform -translate-y-1' 
                      : 'bg-slate-900/80 hover:bg-slate-800/80 border-white/5 text-slate-300 hover:border-teal-500/40 hover:shadow-lg'
                  }"
                >
                  <div class="mb-2.5 ${isActive ? 'text-white' : 'text-teal-400'}">
                    ${getCategoryIconSvg(cat.icon)}
                  </div>
                  <div>
                    <div class="text-xs font-black leading-tight line-clamp-1">${cat.name}</div>
                    <div class="text-[10px] font-semibold mt-0.5 ${isActive ? 'text-teal-100' : 'text-slate-500'}">${cat.count} Listed</div>
                  </div>
                </button>
              `;
            }).join('')}
          </div>
        </div>

        <!-- Quick Locality Filter Chips Bar -->
        <div class="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <span class="text-slate-400 font-bold text-[11px] whitespace-nowrap">Popular Gorakhpur Areas:</span>
          ${['All', 'Golghar', 'Buxipur', 'Sadar', 'Medical College', 'Mohaddipur'].map(loc => `
            <button 
              data-loc-chip="${loc}" 
              class="px-3 py-1 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all ${
                selectedLocation === loc 
                  ? 'btn-neon-teal' 
                  : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-white/5'
              }"
            >
              📍 ${loc === 'All' ? 'All Gorakhpur' : loc}
            </button>
          `).join('')}
        </div>

        <!-- Search & Filter Controls Panel -->
        <div class="glass-panel p-4 flex flex-col sm:flex-row gap-3 items-center">
          <div class="relative flex-1 w-full">
            <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            </span>
            <input 
              type="text" 
              id="search-doctor-input" 
              placeholder="Search by doctor or hospital (e.g. Dr. Naveen Verma, Raj Eye Hospital, Dr. Aggarwal, Diet)..." 
              value="${searchQuery}"
              class="w-full pl-10 pr-4 py-2.5 bg-slate-900/90 border border-white/10 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
            />
          </div>

          <div class="w-full sm:w-64">
            <select id="location-filter-select" class="w-full py-2.5 px-3.5 bg-slate-900/90 border border-white/10 rounded-xl text-xs text-teal-300 font-bold focus:outline-none focus:ring-2 focus:ring-teal-500">
              <option value="All" ${selectedLocation === 'All' ? 'selected' : ''}>All Locations in Gorakhpur</option>
              <option value="Gorakhpur" ${selectedLocation === 'Gorakhpur' ? 'selected' : ''}>Central Gorakhpur</option>
              <option value="Buxipur" ${selectedLocation === 'Buxipur' ? 'selected' : ''}>Buxipur, Gorakhpur</option>
              <option value="Sadar" ${selectedLocation === 'Sadar' ? 'selected' : ''}>Sadar, Gorakhpur</option>
              <option value="Golghar" ${selectedLocation === 'Golghar' ? 'selected' : ''}>Golghar, Gorakhpur</option>
              <option value="Medical College" ${selectedLocation === 'Medical College' ? 'selected' : ''}>Medical College Road</option>
              <option value="Mohaddipur" ${selectedLocation === 'Mohaddipur' ? 'selected' : ''}>Mohaddipur, Gorakhpur</option>
            </select>
          </div>

          ${(selectedCategory !== 'All' || searchQuery || selectedLocation !== 'All') ? `
            <button id="reset-filters-btn" class="text-xs font-bold text-teal-400 hover:text-teal-300 px-3.5 py-2 border border-teal-500/30 rounded-xl bg-teal-500/10 hover:bg-teal-500/20 transition-colors whitespace-nowrap">
              Reset Filters
            </button>
          ` : ''}
        </div>

        <!-- Doctors / Hospitals Directory Grid -->
        <div class="space-y-4">
          <div class="flex items-center justify-between">
            <div class="text-xs font-bold text-slate-400">
              Showing <span class="text-teal-400 font-black">${doctors.length}</span> verified Gorakhpur listings
            </div>
            <div class="badge-demo text-[10px]">
              Demo credentials — Real personal numbers shielded
            </div>
          </div>

          ${doctors.length === 0 ? `
            <div class="glass-panel p-12 text-center border-dashed border-slate-700">
              <div class="w-16 h-16 bg-slate-800/80 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              </div>
              <h3 class="text-base font-bold text-white mb-1">No specialists match your criteria</h3>
              <p class="text-xs text-slate-400 max-w-sm mx-auto mb-5">Try resetting your filters or searching for Gorakhpur specialists like Dr. Verma, Dr. Aggarwal, or Raj Eye Hospital.</p>
              <button id="empty-reset-btn" class="btn-neon-teal px-4 py-2 rounded-xl text-xs font-bold">
                Clear Filters
              </button>
            </div>
          ` : `
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              ${doctors.map(doc => renderDoctorCard(doc)).join('')}
            </div>
          `}
        </div>

        <!-- Appointment Requests Tracker Section -->
        <div class="glass-panel p-6 space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <h3 class="text-sm font-black text-white flex items-center gap-2">
                <svg class="w-5 h-5 text-teal-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                My Appointment Requests & Consultation Tracker
              </h3>
              <p class="text-xs text-slate-400 mt-0.5">Workflow: Requested ➔ Accepted / Declined ➔ Completed / Cancelled</p>
            </div>
            <span class="badge-neon">
              ${appointments.length} Records
            </span>
          </div>

          ${appointments.length === 0 ? `
            <p class="text-xs text-slate-400 py-6 text-center">No appointment requests yet. Click "Book Slot" on any doctor card above to submit a demo booking.</p>
          ` : `
            <div class="divide-y divide-white/5 overflow-x-auto">
              <table class="w-full text-left text-xs text-slate-300">
                <thead>
                  <tr class="text-slate-400 font-bold uppercase text-[10px] tracking-wider border-b border-white/5 pb-2">
                    <th class="py-3 px-3">Doctor / Hospital</th>
                    <th class="py-3 px-3">Specialty</th>
                    <th class="py-3 px-3">Date & Slot</th>
                    <th class="py-3 px-3">Symptoms</th>
                    <th class="py-3 px-3">Status</th>
                    <th class="py-3 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-white/5">
                  ${appointments.map(apt => `
                    <tr class="hover:bg-slate-800/40 transition-colors">
                      <td class="py-3 px-3 font-bold text-white">${apt.doctorName}</td>
                      <td class="py-3 px-3 text-teal-400">${apt.specialty}</td>
                      <td class="py-3 px-3 text-slate-300 font-mono">${apt.preferredDate} • ${apt.preferredTime}</td>
                      <td class="py-3 px-3 text-slate-400 max-w-xs truncate">${apt.symptoms || 'General consult'}</td>
                      <td class="py-3 px-3">
                        <span class="status-pill status-${apt.status.toLowerCase()}">
                          ${apt.status}
                        </span>
                      </td>
                      <td class="py-3 px-3 text-right">
                        <div class="flex items-center justify-end gap-1.5">
                          ${apt.status === 'Requested' ? `
                            <button data-action="accept-apt" data-id="${apt.id}" class="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-lg hover:bg-emerald-500/30 text-[11px] font-bold">Accept (Demo)</button>
                            <button data-action="decline-apt" data-id="${apt.id}" class="px-2.5 py-1 bg-rose-500/20 text-rose-300 border border-rose-500/40 rounded-lg hover:bg-rose-500/30 text-[11px] font-bold">Decline</button>
                          ` : ''}
                          ${apt.status === 'Accepted' ? `
                            <button data-action="complete-apt" data-id="${apt.id}" class="px-2.5 py-1 bg-teal-500/20 text-teal-300 border border-teal-500/40 rounded-lg hover:bg-teal-500/30 text-[11px] font-bold">Mark Done</button>
                            <button data-action="cancel-apt" data-id="${apt.id}" class="px-2.5 py-1 bg-slate-800 text-slate-400 rounded-lg hover:bg-slate-700 text-[11px] font-bold">Cancel</button>
                          ` : ''}
                          ${['Completed', 'Cancelled', 'Declined'].includes(apt.status) ? `
                            <span class="text-slate-500 text-[11px] italic">Archived</span>
                          ` : ''}
                        </div>
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          `}
        </div>

      </div>
    `;

    attachEvents();
  }

  function renderDoctorCard(doc) {
    return `
      <div class="glass-panel p-6 flex flex-col justify-between relative group hover:border-teal-500/50">
        <div>
          <div class="flex items-start justify-between gap-3 mb-3.5">
            <div class="flex items-center gap-3.5">
              <div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-teal-500 to-teal-700 text-white flex items-center justify-center font-black text-xl shadow-lg shadow-teal-500/25 flex-shrink-0 group-hover:scale-105 transition-transform">
                ${doc.name.substring(0, 2).toUpperCase()}
              </div>
              <div>
                <h4 class="text-sm font-extrabold text-white group-hover:text-teal-400 transition-colors line-clamp-1">
                  ${doc.name}
                </h4>
                <p class="text-xs font-bold text-teal-400 mt-0.5">${doc.specialty}</p>
                <div class="flex items-center gap-2 mt-0.5">
                  <span class="text-[11px] text-slate-400">${doc.type} • ${doc.experience || 'Experienced'}</span>
                  <span class="text-amber-400 text-xs font-black">⭐ 4.9</span>
                </div>
              </div>
            </div>
          </div>

          <div class="mb-3.5 flex items-center gap-2 flex-wrap">
            <span class="badge-demo">
              <svg class="w-3 h-3 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
              ${doc.badge}
            </span>
            <span class="badge-neon text-[10px]">Gorakhpur OPD</span>
          </div>

          <p class="text-xs text-slate-300 line-clamp-2 mb-3.5 leading-relaxed font-normal">
            ${doc.bio}
          </p>

          <div class="space-y-2 text-xs text-slate-300 mb-4 bg-slate-900/80 p-3 rounded-2xl border border-white/5">
            <div class="flex items-center gap-2">
              <svg class="w-3.5 h-3.5 text-teal-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
              <span class="truncate font-semibold text-white">${doc.address}</span>
            </div>
            <div class="flex items-center gap-2">
              <svg class="w-3.5 h-3.5 text-amber-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              <span>Available: <strong class="text-teal-300">${doc.availableDays.join(', ')}</strong></span>
            </div>
          </div>
        </div>

        <div class="grid grid-cols-3 gap-2 pt-3 border-t border-white/5">
          <button 
            data-action="contact-doc" 
            data-id="${doc.id}" 
            class="px-2 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all"
          >
            <svg class="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
            Contact
          </button>
          <button 
            data-action="directions-doc" 
            data-id="${doc.id}" 
            class="px-2 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all"
          >
            <svg class="w-3.5 h-3.5 text-teal-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/></svg>
            Route
          </button>
          <button 
            data-action="request-apt" 
            data-id="${doc.id}" 
            class="btn-neon-teal px-2 py-2 rounded-xl text-xs font-black flex items-center justify-center gap-1"
          >
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            Book Slot
          </button>
        </div>
      </div>
    `;
  }

  function attachEvents() {
    container.querySelectorAll('.specialty-card').forEach(btn => {
      btn.addEventListener('click', () => {
        selectedCategory = btn.dataset.category;
        render();
      });
    });

    container.querySelectorAll('[data-loc-chip]').forEach(btn => {
      btn.addEventListener('click', () => {
        selectedLocation = btn.dataset.locChip;
        render();
      });
    });

    const searchInput = container.querySelector('#search-doctor-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        searchQuery = e.target.value;
        render();
        const newInp = container.querySelector('#search-doctor-input');
        if (newInp) {
          newInp.focus();
          newInp.setSelectionRange(newInp.value.length, newInp.value.length);
        }
      });
    }

    const locSelect = container.querySelector('#location-filter-select');
    if (locSelect) {
      locSelect.addEventListener('change', (e) => {
        selectedLocation = e.target.value;
        render();
      });
    }

    const resetBtn = container.querySelector('#reset-filters-btn');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        selectedCategory = 'All';
        searchQuery = '';
        selectedLocation = 'All';
        render();
      });
    }

    const emptyResetBtn = container.querySelector('#empty-reset-btn');
    if (emptyResetBtn) {
      emptyResetBtn.addEventListener('click', () => {
        selectedCategory = 'All';
        searchQuery = '';
        selectedLocation = 'All';
        render();
      });
    }

    container.querySelectorAll('[data-action="contact-doc"]').forEach(btn => {
      btn.addEventListener('click', () => {
        const doc = db.getDoctorById(btn.dataset.id);
        if (doc) showContactModal(doc);
      });
    });

    container.querySelectorAll('[data-action="directions-doc"]').forEach(btn => {
      btn.addEventListener('click', () => {
        const doc = db.getDoctorById(btn.dataset.id);
        if (doc) showDirectionsModal(doc);
      });
    });

    container.querySelectorAll('[data-action="request-apt"]').forEach(btn => {
      btn.addEventListener('click', () => {
        const doc = db.getDoctorById(btn.dataset.id);
        if (doc) showAppointmentModal(doc);
      });
    });

    container.querySelectorAll('[data-action="accept-apt"]').forEach(btn => {
      btn.addEventListener('click', () => {
        db.updateAppointmentStatus(btn.dataset.id, 'Accepted');
        window.showToast?.('Appointment Accepted! Doctor slot confirmed in demo.', 'success');
        render();
      });
    });

    container.querySelectorAll('[data-action="decline-apt"]').forEach(btn => {
      btn.addEventListener('click', () => {
        db.updateAppointmentStatus(btn.dataset.id, 'Declined');
        window.showToast?.('Appointment Declined in demo.', 'info');
        render();
      });
    });

    container.querySelectorAll('[data-action="complete-apt"]').forEach(btn => {
      btn.addEventListener('click', () => {
        db.updateAppointmentStatus(btn.dataset.id, 'Completed');
        window.showToast?.('Appointment marked as Completed.', 'success');
        render();
      });
    });

    container.querySelectorAll('[data-action="cancel-apt"]').forEach(btn => {
      btn.addEventListener('click', () => {
        db.updateAppointmentStatus(btn.dataset.id, 'Cancelled');
        window.showToast?.('Appointment Cancelled.', 'info');
        render();
      });
    });
  }

  function showContactModal(doc) {
    const modalContent = `
      <div class="space-y-4 text-slate-800">
        <div class="flex items-center gap-3">
          <div class="w-12 h-12 bg-teal-100 text-teal-700 rounded-2xl flex items-center justify-center font-black text-lg">
            ${doc.name.substring(0, 2)}
          </div>
          <div>
            <h4 class="font-extrabold text-slate-900">${doc.name}</h4>
            <p class="text-xs text-teal-600 font-bold">${doc.specialty}</p>
            <p class="text-xs text-slate-500">${doc.location}</p>
          </div>
        </div>

        <div class="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 leading-relaxed font-medium">
          <strong>Privacy Notice:</strong> Unverified demo listing. Direct contact phone numbers are shielded. Please use in-app appointment booking.
        </div>

        <div class="space-y-2 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200">
          <div class="flex justify-between py-1 border-b border-slate-200">
            <span class="text-slate-500 font-medium">Address:</span>
            <span class="font-bold text-slate-800">${doc.address}</span>
          </div>
          <div class="flex justify-between py-1 border-b border-slate-200">
            <span class="text-slate-500 font-medium">OPD Days:</span>
            <span class="font-bold text-teal-700">${doc.availableDays.join(', ')}</span>
          </div>
          <div class="flex justify-between py-1">
            <span class="text-slate-500 font-medium">Verification Status:</span>
            <span class="badge-demo">${doc.badge}</span>
          </div>
        </div>
      </div>
    `;

    window.openModal?.(`Contact • ${doc.name}`, modalContent, [
      { label: 'Close', action: 'close', className: 'bg-slate-200 text-slate-700' },
      { 
        label: 'Book Consultation Slot', 
        action: () => {
          window.closeModal?.();
          showAppointmentModal(doc);
        }, 
        className: 'btn-neon-teal' 
      }
    ]);
  }

  function showDirectionsModal(doc) {
    const modalContent = `
      <div class="space-y-4 text-slate-800">
        <div class="p-3 bg-teal-50 border border-teal-200 rounded-xl text-xs text-teal-950 font-medium">
          <strong>Route Preview:</strong> Navigating from Golghar, Gorakhpur to <strong>${doc.address}</strong>.
        </div>
        <div class="p-4 bg-slate-900 text-white rounded-2xl text-xs space-y-3 font-mono">
          <div class="flex items-center gap-2 text-teal-400">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/></svg>
            Destination: ${doc.name} (${doc.location})
          </div>
          <p class="text-slate-300 font-sans">
            Estimated Travel: ~8–12 mins via Civil Lines / Park Road (Simulated distance: 2.8 km).
          </p>
          <div class="p-2.5 bg-slate-800 rounded-lg text-slate-400 text-[11px] font-sans">
            Coordinates: ${doc.coordinates.lat.toFixed(4)}° N, ${doc.coordinates.lng.toFixed(4)}° E
          </div>
        </div>
      </div>
    `;

    window.openModal?.(`Directions to ${doc.name}`, modalContent, [
      { label: 'Close', action: 'close', className: 'bg-slate-200 text-slate-700' },
      { 
        label: 'View on Interactive Radar Map', 
        action: () => {
          window.closeModal?.();
          window.navigateTo?.('map');
        }, 
        className: 'btn-neon-teal' 
      }
    ]);
  }

  function showAppointmentModal(doc) {
    const patient = db.getPatientProfile();
    const modalContent = `
      <form id="appointment-form" class="space-y-4 text-slate-800">
        <div class="p-3 bg-teal-50 border border-teal-200 rounded-xl text-xs text-teal-950">
          Booking appointment with <strong>${doc.name}</strong> (${doc.specialty}) at ${doc.location}.
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">Patient Name *</label>
            <input type="text" id="apt-patient-name" value="${patient.fullName}" required class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">Contact Phone *</label>
            <input type="tel" id="apt-patient-phone" value="${patient.phone}" required class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold" />
          </div>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">Preferred Date *</label>
            <input type="date" id="apt-date" value="2026-09-16" required class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">Preferred Time Slot *</label>
            <select id="apt-time" class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-teal-700">
              <option value="10:00 AM">10:00 AM - Morning OPD</option>
              <option value="11:30 AM">11:30 AM - Morning OPD</option>
              <option value="02:00 PM">02:00 PM - Afternoon OPD</option>
              <option value="04:30 PM">04:30 PM - Evening OPD</option>
              <option value="06:00 PM">06:00 PM - Evening OPD</option>
            </select>
          </div>
        </div>

        <div>
          <label class="block text-xs font-bold text-slate-700 mb-1">Symptoms or Reason for Visit</label>
          <textarea id="apt-symptoms" rows="3" placeholder="Describe symptoms or reasons for consultation..." class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl"></textarea>
        </div>

        <div class="text-[11px] text-slate-500 italic">
          * Demo status initializes as "Requested". You can transition it to Accepted / Completed in the tracker.
        </div>
      </form>
    `;

    window.openModal?.(`Book Slot • ${doc.name}`, modalContent, [
      { label: 'Cancel', action: 'close', className: 'bg-slate-200 text-slate-700' },
      { 
        label: 'Confirm Appointment Request', 
        action: () => {
          const name = document.getElementById('apt-patient-name')?.value;
          const phone = document.getElementById('apt-patient-phone')?.value;
          const date = document.getElementById('apt-date')?.value;
          const time = document.getElementById('apt-time')?.value;
          const symptoms = document.getElementById('apt-symptoms')?.value;

          if (!name || !date) {
            alert('Please enter patient name and preferred date');
            return false;
          }

          db.createAppointment({
            doctorId: doc.id,
            doctorName: doc.name,
            specialty: doc.specialty,
            patientName: name,
            patientPhone: phone,
            preferredDate: date,
            preferredTime: time,
            symptoms: symptoms
          });

          window.closeModal?.();
          window.showToast?.(`Appointment requested with ${doc.name}!`, 'success');
          render();
        }, 
        className: 'btn-neon-teal' 
      }
    ]);
  }

  // Initial render
  render();
}
