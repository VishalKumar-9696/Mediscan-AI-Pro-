/**
 * Module 4: Blood Donor Registration & Donor Network
 * Team: The Code Burner | Maharana Pratap Institute of Technology, Gorakhpur
 */

import { db, isBloodCompatible } from '../db.js';

export function renderDonorNetworkModule(container) {
  let activeTab = 'find-donors'; // 'find-donors' | 'register-donor' | 'donor-dashboard'
  let selectedBloodGroup = 'All';
  let selectedAvailability = 'All';
  let searchQuery = '';

  function render() {
    const currentUser = db.getCurrentUser();
    const donors = db.getDonors({
      bloodGroup: selectedBloodGroup,
      availability: selectedAvailability
    }).filter(d => {
      if (!searchQuery) return true;
      const q = searchQuery.toLowerCase();
      return d.displayName.toLowerCase().includes(q) || d.locality.toLowerCase().includes(q);
    });

    const activeDonor = db.getDonors().find(d => d.id === currentUser.activeDonorId) || db.getDonors()[0];
    const incomingRequests = db.getDonationRequests(activeDonor?.id);

    container.innerHTML = `
      <div class="space-y-8 animate-fade-in">
        <!-- Page Header -->
        <div class="bg-gradient-to-r from-slate-900 via-slate-800 to-orange-950 p-6 md:p-8 rounded-2xl text-white shadow-elevated border border-slate-700/60 relative overflow-hidden">
          <div class="absolute -right-10 -bottom-10 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <div class="max-w-3xl">
            <div class="flex items-center gap-3 mb-3">
              <span class="bg-orange-500/20 text-orange-300 border border-orange-500/30 text-xs font-semibold px-3 py-1 rounded-full flex items-center gap-1.5">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
                Community Blood Donor Network
              </span>
              <span class="badge-verified">Consent-Protected Privacy</span>
            </div>
            <h1 class="text-2xl md:text-3xl font-bold tracking-tight text-white mb-2">
              Blood Donor Registration & Network
            </h1>
            <p class="text-slate-300 text-sm md:text-base leading-relaxed">
              Register as a voluntary life-saving blood donor, manage your availability status, or discover consented donors across Gorakhpur with privacy-first contact protocols.
            </p>
          </div>
        </div>

        <!-- Medical Screening & Legal Consent Advisory -->
        <div class="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-xl text-xs text-amber-900 shadow-sm flex items-start gap-3">
          <svg class="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          <div>
            <p class="font-bold mb-0.5">Medical Screening & Safety Safeguard Notice:</p>
            <p class="leading-relaxed">
              Registration on Mediscan AI Pro does not guarantee medical eligibility to donate. Every voluntary donor must undergo mandatory physical examination, hemoglobin screening (minimum 12.5 g/dL), and transfusion transmissible infections (TTI) testing at the licensed blood bank before donation. Exact phone numbers and addresses are strictly shielded.
            </p>
          </div>
        </div>

        <!-- Module Navigation Tabs -->
        <div class="flex border-b border-slate-200 gap-6 text-sm font-semibold">
          <button data-tab="find-donors" class="pb-3 ${activeTab === 'find-donors' ? 'text-orange-600 border-b-2 border-orange-600' : 'text-slate-500 hover:text-slate-800'} transition-colors flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            Find Registered Donors (${donors.length})
          </button>
          <button data-tab="register-donor" class="pb-3 ${activeTab === 'register-donor' ? 'text-orange-600 border-b-2 border-orange-600' : 'text-slate-500 hover:text-slate-800'} transition-colors flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/></svg>
            Register as a Blood Donor
          </button>
          <button data-tab="donor-dashboard" class="pb-3 ${activeTab === 'donor-dashboard' ? 'text-orange-600 border-b-2 border-orange-600' : 'text-slate-500 hover:text-slate-800'} transition-colors flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            My Donor Dashboard (${incomingRequests.length} Requests)
          </button>
        </div>

        <!-- Tab 1: Find Donors -->
        ${activeTab === 'find-donors' ? `
          <div class="space-y-6">
            <!-- Search & Filters -->
            <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-3 items-center">
              <div class="relative flex-1 w-full">
                <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                </span>
                <input 
                  type="text" 
                  id="donor-search-input" 
                  placeholder="Search by donor ID, locality (e.g., Mohaddipur, Golghar, Betiahata)..." 
                  value="${searchQuery}"
                  class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:bg-white focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div class="w-full md:w-48">
                <select id="filter-blood-group" class="w-full py-2.5 px-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:bg-white focus:ring-2 focus:ring-orange-500 font-semibold">
                  <option value="All" ${selectedBloodGroup === 'All' ? 'selected' : ''}>All Blood Groups</option>
                  <option value="O+" ${selectedBloodGroup === 'O+' ? 'selected' : ''}>O+ (Positive)</option>
                  <option value="O-" ${selectedBloodGroup === 'O-' ? 'selected' : ''}>O- (Universal Donor)</option>
                  <option value="A+" ${selectedBloodGroup === 'A+' ? 'selected' : ''}>A+ (Positive)</option>
                  <option value="A-" ${selectedBloodGroup === 'A-' ? 'selected' : ''}>A- (Negative)</option>
                  <option value="B+" ${selectedBloodGroup === 'B+' ? 'selected' : ''}>B+ (Positive)</option>
                  <option value="B-" ${selectedBloodGroup === 'B-' ? 'selected' : ''}>B- (Negative)</option>
                  <option value="AB+" ${selectedBloodGroup === 'AB+' ? 'selected' : ''}>AB+ (Positive)</option>
                  <option value="AB-" ${selectedBloodGroup === 'AB-' ? 'selected' : ''}>AB- (Negative)</option>
                </select>
              </div>

              <div class="w-full md:w-44">
                <select id="filter-availability" class="w-full py-2.5 px-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:bg-white focus:ring-2 focus:ring-orange-500">
                  <option value="All" ${selectedAvailability === 'All' ? 'selected' : ''}>All Statuses</option>
                  <option value="Available" ${selectedAvailability === 'Available' ? 'selected' : ''}>Available Now</option>
                  <option value="Busy" ${selectedAvailability === 'Busy' ? 'selected' : ''}>Currently Busy</option>
                  <option value="Cooldown" ${selectedAvailability === 'Cooldown' ? 'selected' : ''}>In 90-Day Cooldown</option>
                </select>
              </div>
            </div>

            <!-- Donor Cards Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              ${donors.map(donor => `
                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
                  <div>
                    <div class="flex items-start justify-between mb-3">
                      <div class="flex items-center gap-2.5">
                        <div class="w-10 h-10 rounded-full bg-orange-100 text-orange-700 flex items-center justify-center font-bold text-sm">
                          ${donor.displayName.substring(0, 1)}
                        </div>
                        <div>
                          <h4 class="text-xs font-bold text-slate-900">${donor.displayName}</h4>
                          <p class="text-[11px] text-slate-400">Verified Donor ID</p>
                        </div>
                      </div>
                      <span class="px-2.5 py-1 rounded text-xs font-black bg-red-100 text-red-800 border border-red-200">
                        ${donor.bloodGroup}
                      </span>
                    </div>

                    <div class="space-y-1.5 text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-100 mb-4">
                      <div class="flex items-center justify-between">
                        <span class="text-slate-400">Locality:</span>
                        <span class="font-medium text-slate-800">${donor.locality}</span>
                      </div>
                      <div class="flex items-center justify-between">
                        <span class="text-slate-400">Status:</span>
                        <span class="inline-flex items-center gap-1 font-semibold ${donor.availabilityStatus === 'Available' ? 'text-emerald-700' : 'text-amber-700'}">
                          <span class="w-1.5 h-1.5 rounded-full ${donor.availabilityStatus === 'Available' ? 'bg-emerald-500' : 'bg-amber-500'}"></span>
                          ${donor.availabilityStatus}
                        </span>
                      </div>
                      <div class="flex items-center justify-between">
                        <span class="text-slate-400">Last Donation:</span>
                        <span class="text-slate-700">${donor.lastDonationDate || 'First time donor'}</span>
                      </div>
                      <div class="flex items-center justify-between">
                        <span class="text-slate-400">Total Donated:</span>
                        <span class="font-semibold text-slate-800">${donor.totalDonations} Times</span>
                      </div>
                    </div>
                  </div>

                  <div class="pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400">Protected Contact</span>
                    <button data-action="request-single-donor" data-id="${donor.id}" data-name="${donor.displayName}" class="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors">
                      Send Donation Request
                    </button>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

        <!-- Tab 2: Register as a Blood Donor -->
        ${activeTab === 'register-donor' ? `
          <div class="max-w-2xl mx-auto bg-white p-6 md:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            <div>
              <h3 class="text-lg font-bold text-slate-900">Voluntary Blood Donor Registration</h3>
              <p class="text-xs text-slate-500 mt-1">Join the Gorakhpur life-saving network. Your identity is pseudonymized and phone number is never shown publicly.</p>
            </div>

            <form id="donor-registration-form" class="space-y-4">
              <div>
                <label class="block text-xs font-semibold text-slate-700 mb-1">Full Name *</label>
                <input type="text" id="reg-donor-name" value="${currentUser.name}" required class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:bg-white" />
              </div>

              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label class="block text-xs font-semibold text-slate-700 mb-1">Blood Group *</label>
                  <select id="reg-donor-bg" required class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-bold text-red-700 focus:ring-2 focus:ring-orange-500 focus:bg-white">
                    <option value="O+">O+ (Positive)</option>
                    <option value="O-">O- (Universal Donor)</option>
                    <option value="A+">A+ (Positive)</option>
                    <option value="A-">A- (Negative)</option>
                    <option value="B+">B+ (Positive)</option>
                    <option value="B-">B- (Negative)</option>
                    <option value="AB+">AB+ (Universal Recipient)</option>
                    <option value="AB-">AB- (Negative)</option>
                  </select>
                </div>

                <div>
                  <label class="block text-xs font-semibold text-slate-700 mb-1">City / Locality (Gorakhpur) *</label>
                  <select id="reg-donor-locality" required class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:bg-white">
                    <option value="Mohaddipur, Gorakhpur">Mohaddipur, Gorakhpur</option>
                    <option value="Golghar, Gorakhpur">Golghar, Gorakhpur</option>
                    <option value="Betiahata, Gorakhpur">Betiahata, Gorakhpur</option>
                    <option value="Medical College Road, Gorakhpur">Medical College Road, Gorakhpur</option>
                    <option value="Rapti Nagar, Gorakhpur">Rapti Nagar, Gorakhpur</option>
                    <option value="Buxipur, Gorakhpur">Buxipur, Gorakhpur</option>
                    <option value="Asuran Chowk, Gorakhpur">Asuran Chowk, Gorakhpur</option>
                    <option value="Rustampur, Gorakhpur">Rustampur, Gorakhpur</option>
                  </select>
                </div>
              </div>

              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label class="block text-xs font-semibold text-slate-700 mb-1">Preferred Contact Method</label>
                  <select id="reg-donor-contact" class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500">
                    <option value="In-App Request">In-App Consent Request (Recommended)</option>
                    <option value="SMS Notification">SMS Notification</option>
                    <option value="WhatsApp Alert">WhatsApp Alert</option>
                  </select>
                </div>

                <div>
                  <label class="block text-xs font-semibold text-slate-700 mb-1">Initial Availability</label>
                  <select id="reg-donor-avail" class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500">
                    <option value="Available">Available for Emergency Calls</option>
                    <option value="Busy">Busy / On Call</option>
                    <option value="Cooldown">Recent Donation Cooldown</option>
                  </select>
                </div>
              </div>

              <div>
                <label class="block text-xs font-semibold text-slate-700 mb-1">Last Blood Donation Date (Optional)</label>
                <input type="date" id="reg-donor-last-date" class="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:bg-white" />
              </div>

              <div class="space-y-3 pt-2 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <label class="flex items-start gap-2.5 cursor-pointer">
                  <input type="checkbox" id="reg-consent-notify" checked required class="mt-0.5 rounded text-orange-600 focus:ring-orange-500" />
                  <span class="text-xs text-slate-700">
                    <strong>Emergency Alerts Consent:</strong> I agree to receive emergency blood requests matched to my blood group in the Gorakhpur region.
                  </span>
                </label>

                <label class="flex items-start gap-2.5 cursor-pointer">
                  <input type="checkbox" id="reg-consent-privacy" checked required class="mt-0.5 rounded text-orange-600 focus:ring-orange-500" />
                  <span class="text-xs text-slate-700">
                    <strong>Privacy & Identity Protection:</strong> I consent to display my anonymized donor profile (first name + ID) and locality on the donor finder.
                  </span>
                </label>
              </div>

              <button type="submit" class="w-full py-3 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold transition-all shadow-md">
                Complete Donor Registration
              </button>
            </form>
          </div>
        ` : ''}

        <!-- Tab 3: Donor Dashboard -->
        ${activeTab === 'donor-dashboard' ? `
          <div class="space-y-6">
            <!-- Active Donor Profile Summary Card -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div class="flex items-center gap-4">
                <div class="w-16 h-16 rounded-2xl bg-orange-100 text-orange-700 font-black text-2xl flex items-center justify-center">
                  ${activeDonor ? activeDonor.bloodGroup : 'O+'}
                </div>
                <div>
                  <div class="flex items-center gap-2">
                    <h3 class="text-base font-bold text-slate-900">${activeDonor ? activeDonor.displayName : 'Amit K. (DON-801)'}</h3>
                    <span class="badge-verified">Active Donor</span>
                  </div>
                  <p class="text-xs text-slate-500">📍 ${activeDonor ? activeDonor.locality : 'Mohaddipur, Gorakhpur'} • Total Donations: ${activeDonor ? activeDonor.totalDonations : 4}</p>
                </div>
              </div>

              <!-- Quick Availability Toggle -->
              <div class="flex items-center gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span class="text-xs font-bold text-slate-700">My Availability:</span>
                <button id="toggle-avail-btn" class="px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeDonor?.availabilityStatus === 'Available' 
                    ? 'bg-emerald-600 text-white shadow-sm' 
                    : 'bg-slate-200 text-slate-700'
                }">
                  ${activeDonor?.availabilityStatus === 'Available' ? '● Available' : '○ Busy'}
                </button>
              </div>
            </div>

            <!-- Incoming Donation Requests -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div class="flex items-center justify-between pb-3 border-b border-slate-100">
                <div>
                  <h4 class="text-sm font-bold text-slate-900">Incoming Blood Donation Requests</h4>
                  <p class="text-xs text-slate-500">Consent-based request workflow: Accept / Decline emergency requests.</p>
                </div>
                <span class="text-xs font-semibold px-2.5 py-1 bg-orange-100 text-orange-800 rounded-full">
                  ${incomingRequests.length} Pending Actions
                </span>
              </div>

              ${incomingRequests.length === 0 ? `
                <div class="p-8 text-center text-xs text-slate-400">
                  No active donation requests waiting for your response.
                </div>
              ` : `
                <div class="space-y-3">
                  ${incomingRequests.map(req => `
                    <div class="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <div class="flex items-center gap-2">
                          <span class="text-xs font-bold text-slate-900">Request for ${req.patientName}</span>
                          <span class="px-2 py-0.5 bg-red-100 text-red-800 font-bold rounded text-[11px]">${req.bloodGroup}</span>
                        </div>
                        <p class="text-xs text-slate-500 mt-1">Hospital: <strong>${req.hospital}</strong> • Units: ${req.units}</p>
                      </div>

                      <div class="flex items-center gap-2">
                        ${req.status === 'Pending' ? `
                          <button data-action="accept-don-req" data-id="${req.id}" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-sm">
                            Accept Request
                          </button>
                          <button data-action="decline-don-req" data-id="${req.id}" class="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-semibold">
                            Decline
                          </button>
                        ` : `
                          <span class="status-pill status-${req.status.toLowerCase()}">
                            ${req.status}
                          </span>
                        `}
                      </div>
                    </div>
                  `).join('')}
                </div>
              `}
            </div>
          </div>
        ` : ''}
      </div>
    `;

    attachEvents();
  }

  function attachEvents() {
    // Tabs
    container.querySelectorAll('[data-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        activeTab = btn.dataset.tab;
        render();
      });
    });

    // Search filter
    const searchInp = container.querySelector('#donor-search-input');
    if (searchInp) {
      searchInp.addEventListener('input', (e) => {
        searchQuery = e.target.value;
        render();
        const newInp = container.querySelector('#donor-search-input');
        if (newInp) {
          newInp.focus();
          newInp.setSelectionRange(newInp.value.length, newInp.value.length);
        }
      });
    }

    // Filter blood group
    const bgFilter = container.querySelector('#filter-blood-group');
    if (bgFilter) {
      bgFilter.addEventListener('change', (e) => {
        selectedBloodGroup = e.target.value;
        render();
      });
    }

    // Filter availability
    const availFilter = container.querySelector('#filter-availability');
    if (availFilter) {
      availFilter.addEventListener('change', (e) => {
        selectedAvailability = e.target.value;
        render();
      });
    }

    // Registration Form submit
    const regForm = container.querySelector('#donor-registration-form');
    if (regForm) {
      regForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = container.querySelector('#reg-donor-name').value;
        const bloodGroup = container.querySelector('#reg-donor-bg').value;
        const locality = container.querySelector('#reg-donor-locality').value;
        const preferredContact = container.querySelector('#reg-donor-contact').value;
        const availabilityStatus = container.querySelector('#reg-donor-avail').value;
        const lastDonationDate = container.querySelector('#reg-donor-last-date').value;

        const newDonor = db.addDonor({
          name,
          bloodGroup,
          locality,
          preferredContact,
          availabilityStatus,
          lastDonationDate
        });

        window.showToast?.(`Thank you! You are registered as donor ${newDonor.displayName}.`, 'success');
        activeTab = 'find-donors';
        render();
      });
    }

    // Single donor request button
    container.querySelectorAll('[data-action="request-single-donor"]').forEach(btn => {
      btn.addEventListener('click', () => {
        window.showToast?.(`Donation request dispatched to ${btn.dataset.name}! They will review and accept in app.`, 'success');
      });
    });

    // Toggle availability
    const toggleBtn = container.querySelector('#toggle-avail-btn');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', () => {
        const currentUser = db.getCurrentUser();
        const activeDonor = db.getDonors().find(d => d.id === currentUser.activeDonorId) || db.getDonors()[0];
        if (activeDonor) {
          const newStatus = activeDonor.availabilityStatus === 'Available' ? 'Busy' : 'Available';
          db.updateDonorAvailability(activeDonor.id, newStatus);
          window.showToast?.(`Availability changed to: ${newStatus}`, 'info');
          render();
        }
      });
    }

    // Accept / Decline donation request
    container.querySelectorAll('[data-action="accept-don-req"]').forEach(btn => {
      btn.addEventListener('click', () => {
        db.respondToDonationRequest(btn.dataset.id, 'Accepted');
        window.showToast?.('You accepted the blood donation request! Hospital confirmation is now pending.', 'success');
        render();
      });
    });

    container.querySelectorAll('[data-action="decline-don-req"]').forEach(btn => {
      btn.addEventListener('click', () => {
        db.respondToDonationRequest(btn.dataset.id, 'Declined');
        window.showToast?.('Donation request declined.', 'info');
        render();
      });
    });
  }

  // Initial render
  render();
}
